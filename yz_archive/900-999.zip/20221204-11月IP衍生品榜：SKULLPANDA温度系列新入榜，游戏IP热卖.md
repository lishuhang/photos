# 11月IP衍生品榜：SKULLPANDA温度系列新入榜，游戏IP热卖

> 公众号: 娱乐资本论
> 发布时间: 2022-12-04
> 原文链接: https://mp.weixin.qq.com/s/K9FgVoPjfgLUC3CPd9v3Vg

---

![](https://mmbiz.qpic.cn/mmbiz_png/jNZszpkibXx9fK5DxyTD7AyeFpFRtOjibtXBxHxv9ibzVMWibiaric81WOFUJLW0R1iabhKNBDSeVExetG9DF1zviaEjew/640?wx_fmt=png)

**作者｜兔棉花**

第四季度接近尾声，各上市玩具及潮玩公司相继发力，为年终的销量额努力。加之临近圣诞，泡泡玛特、迪士尼、TOPTOY等大型潮玩公司陆续推出节日相关的盲盒手办新系列。今天让我们盘点一下11月的文创衍生品及潮玩产品的销售数据。

![](https://mmbiz.qpic.cn/mmbiz_png/jNZszpkibXx8r0eeusveAtyj98pKeBEz7tMuAmiadsyvAk4l30TZvmgP03RGX0iaosuL5yVawsdblYqeWUcOTHYoQ/640?wx_fmt=png)**盲盒与手办模型：温度系列第一，影视周边手办热销**

首先来看近期天猫盲盒与手办热销榜。

![](https://mmbiz.qpic.cn/mmbiz_png/CkgDGce9CLmMaHMK1b4Of04K6xjMQurDlx4f01wdlrgML3dicnibkQUCPOdcEv0ISqKWo3CntnL1JEiaNuNRhLzUw/640?wx_fmt=png)

泡泡玛特的SKULLPANDA温度系列超越食梦动物系列位居本周盲盒热销榜第一，月销达到了6万+。余下第二到八名，分别是SKULLPANDA食梦动物系列、三丽鸥酷洛米扑克王国盲盒、奇妙萌可玩具惊喜镜系列、璃月篇“战场英姿”主题系列、萌力星球野萌君坐享奇程系列、THE MONSTERS LABUBU一起圣诞系列、Pochacco上学很有趣盲盒摆件帕恰狗、草莓熊盲盒毛绒玩偶公仔挂件和布鲁克积木盲盒手办。

在这周的手办热销中，上榜产品多为影视和游戏周边手办。

![](https://mmbiz.qpic.cn/mmbiz_png/CkgDGce9CLmMaHMK1b4Of04K6xjMQurDpWTibtKs5wy58jGcISibRjGNmgUiaGb3hr6lDC828Rl8YVYib2YHg4caJw/640?wx_fmt=png)

本周手办热销榜单的前三位分别为朔夜观星兰夜行歌手办、JUUs时间Q版系列和漫威漫画装甲死侍1：6比例合金手办，月销分别为4000+、500+和100+。

![](https://mmbiz.qpic.cn/mmbiz_png/jNZszpkibXx8r0eeusveAtyj98pKeBEz7ejDSZf97dAE3mMYqSpwDp0blV0YsOONibSOjLz8EycRV8uxj7xc8QIg/640?wx_fmt=png)**IP衍生品：经典老店坚挺，动漫IP火热**

IP衍生品的店铺方面，首先来看漫画衍生品。模玩熊蝉联第一，其店内除特摄周边、机甲模型热销外，日漫IP《灵能百分百》《海贼王》及游戏IP《偶像梦幻祭》等周边产品依旧为热销产品。

![](https://mmbiz.qpic.cn/mmbiz_png/CkgDGce9CLmMaHMK1b4Of04K6xjMQurDlzibPGccFichEP8twWgsGeKico28VcJic4RFx110YY7DjeGiblMc8pRicAiaA/640?wx_fmt=png)

在IP价值店铺热卖榜上，old先和坛九的店超越碧蓝航线官方周边店依旧位居榜首，其他位于前十的店铺分别为南派泛娱正版周边、碧蓝航线官方周边店、快看自营商店、罗小黑的小黑店、偷玩、战双帕弥什官方店、霹雳国际品牌馆、peropero小卖部和Onmyoji阴阳师主题店。

![](https://mmbiz.qpic.cn/mmbiz_png/CkgDGce9CLmMaHMK1b4Of04K6xjMQurDwpDp7P9nz2uJRxDjHNAC4snJVdGIRh9IEVLGPcAztueE8YWCEKXQVQ/640?wx_fmt=png)

前十店铺的热销产品IP主要来自游戏IP《碧蓝航线》《阴阳师》《战舰少女R》，漫画IP《天官赐福》，小说《盗墓笔记》等。

在国创衍生品店铺热卖榜前五中，销量最高的国产IP衍生品依旧来自《天官赐福》《魔道祖师》《穿书自救指南》等。

![](https://mmbiz.qpic.cn/mmbiz_png/CkgDGce9CLmMaHMK1b4Of04K6xjMQurDfLoT2hZYGDSXXS3pYHFPzWAgaQGYP8gejQxMEbBlg5sTaGTfZ6picUA/640?wx_fmt=png)

![](https://mmbiz.qpic.cn/mmbiz_png/jNZszpkibXx8r0eeusveAtyj98pKeBEz7gMbSIRF8ujdpJibC3CLgiaEEY6kJq4YuKUC4cv1ZG4kjEVEHhs35Zn3Q/640?wx_fmt=png)**更多文创产品：龙魂人形社、Hexagram六芒星入榜，MINIDOLL蝉联第一**

本月，淘宝神店榜中的棉花娃娃店铺热卖榜，排名前十如下：

![](https://mmbiz.qpic.cn/mmbiz_png/CkgDGce9CLmMaHMK1b4Of04K6xjMQurD3vbBE6icsdqQCjlfq7EsaL90tSMsyTRMHsAbUWoBwq3apg2icd8hKxgg/640?wx_fmt=png)

MiniDoll、毛绒玩具批零、是胡萝卜呀、omodoki、草莓宇宙娃屋、妙妙娃衣小屋、Mito么么杂货铺、萌乐漫旅、花田衣橱原创设计、吹泡克林TrippleCream。其中，吹泡克林TrippleCream为本月唯一新入榜店铺。

再来看汉服、Lolita和JK制服店铺热卖榜。

古韵汉服店铺热卖榜中，十三余蝉联榜首，店铺粉丝累计达到426万，近30日收藏再创新高，为15.5万。织造司、七月夕、钟灵记和枫竹列第二至第五位。本月古韵汉服店铺热卖榜相比上月无新入榜店铺。

![](https://mmbiz.qpic.cn/mmbiz_png/CkgDGce9CLmMaHMK1b4Of04K6xjMQurD7t7lY4oibEozKiatHQIdGlctQftlfVt3Hhy2gr3fCQn2ia796SWUWBtSg/640?wx_fmt=png)

Lolita店铺热卖榜上，古典玩偶Classical Puppet婚纱定制超越古典玩偶Puppets and Doll官方位居榜首，店铺粉丝数累计达到72.2万，近30日收藏数为1.8万。第二至第五位分别是告白气球家、NDC玻璃纸之夜原创设计、十二月暖暖和仲夏物语原创设计。

![](https://mmbiz.qpic.cn/mmbiz_png/CkgDGce9CLmMaHMK1b4Of04K6xjMQurDL2wC6LqjtAkkYRibuvsKQ0KtLKPjPCF6a7RnMb2eXYYsRwUrA47I6kg/640?wx_fmt=png)

JK制服店铺热卖榜中，KYOUKO梗豆物语蝉联第一，店铺粉丝量累计达到331万，近30日收藏数为9.6万。

![](https://mmbiz.qpic.cn/mmbiz_png/CkgDGce9CLmMaHMK1b4Of04K6xjMQurDzTA17q1MSZicg4AQNKIJVPH6wUQv6BNIgbW9iaKcpyLEtP3eFKw0k7tw/640?wx_fmt=png)

本月，在淘宝神店榜的BJD玩偶店铺热卖榜，排在前十的分别是：Ringdoll戒之人形、三万院长swdollBJD娃娃、charmdoll、龙魂人形社、西西娃屋BJD娃娃店铺、IMOMODOLL、AS天使工房总店、GEM贵族娃娃DollZone和Guard Love守护爱。

![](https://mmbiz.qpic.cn/mmbiz_png/CkgDGce9CLmMaHMK1b4Of04K6xjMQurDm4TaXLquia9n5Dd43Wmooe8licN6YB5o01UrJBG8UeSfYFHibcVsXdtLQ/640?wx_fmt=png)

‍

‍
