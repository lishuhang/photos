# 北影节招募｜B站、腾讯广告、AIGC…影视行业如何探索营销新生态？

> 公众号: 娱乐资本论
> 发布时间: ref: <Node>
> 原文链接: https://mp.weixin.qq.com/s/nKmO0GSX2lA3SavKmQGnbQ

---

![图片](http://mmbiz.qpic.cn/mmbiz_png/jNZszpkibXx9fK5DxyTD7AyeFpFRtOjibtXBxHxv9ibzVMWibiaric81WOFUJLW0R1iabhKNBDSeVExetG9DF1zviaEjew/640?wx_fmt=png&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)

中国电影市场营销面临一场转型升级？

AI赋能之下，电影营销将迎来怎样的新浪潮？

随着2023年春节档的高调回归，国内电影市场强势复苏。在互联网飞速发展的三年，国内电影营销模式也经历了淬炼和进化，在春节档期间赢得了亮眼的成绩。

互联网时代让电影营销宣传手段更具有实效性和多样性，它的信息承载力远超传统媒介。短视频、直播、二创等形式催生出许多线上新玩法，视听冲击可以更直观的刺激观众感知，在降低成本的同时增加有效转化。2023年春节档几部热映电影， 如《流浪地球2》等再度证明，在专业化、规范化、多元化的营销体系运作下，结合新媒体背景“互联网+电影”的产业形态，使国产电影在后疫情时代再次焕发出新的生机。

未来，国内影视营销如何进⼀步发展突破，又会面临哪些困境？

**4月25日（星期二）上午**，娱乐资本论应北京国际电影节组委会邀请，在**郎园STATION·中央车站橙色空间**承办主题论坛**“新媒体时代电影营销的创新与迭代”**。本次活动将聚焦新媒体时代下，国产电影营销体系的创新与迭代，邀请B站、腾讯广告等在电影营销领域有成熟经验，操盘过成功案例的行业代表、制片人、新媒体平台等，分享他们对国产电影营销新赛道的观察与思考，探讨国内电影产业加速复苏及新媒体行业飞速发展给营销环境带来的机遇与挑战。

**详细议程及报名方式见长图，后台审核通过后即可参会。****想要参会的小伙伴，赶快扫码报名吧↓↓**

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)