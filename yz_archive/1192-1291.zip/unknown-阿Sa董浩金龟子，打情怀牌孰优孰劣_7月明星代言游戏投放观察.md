# 阿Sa董浩金龟子，打情怀牌孰优孰劣|7月明星代言游戏投放观察

> 公众号: 娱乐资本论
> 发布时间: 
> 原文链接: https://mp.weixin.qq.com/s/FkCn33dBXA2FwXIwKmfmhQ

---

![图片](http://mmbiz.qpic.cn/mmbiz_gif/CkgDGce9CLmwVNApqSQKoJnPQFMUzzCDmGl1btzbN2iaRqB5wIaQyrLsfvG2GoK6VIgykaNGsLjMbMt6C1VY87Q/640?wx_fmt=gif&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)

**作者|雪夜枫鳞**

今年暑期档，和上个月预言家预测的一样，各大厂商纷纷把重心重新放回到新游的推广上。随着版号恢复发放的常态化，越来越多的新游戏来到玩家面前，买量市场的投放达到高潮。

从具体数字来看，7月份投放情况实现了指数级增长，日均投放素材数为246,673组，与6月份的183,140组相比增长了34.7%，保持了暑期游戏投放的热度。尤其是《暗黑破坏神：不朽》、《英雄联盟电竞经理》和《奥比岛》等游戏的上线，进一步推动了游戏市场的良性发展。

根据Dataeye数据显示，7月的投放游戏中，现代题材游戏占据主流，投放游戏数量为5993款，相比6月超出了近2000款。仙侠题材和传奇类游戏继续分列二三位。在投放平台上，穿山甲联盟继续占据第一名，今日头条排名第二，抖音反超优量广告达到了第三名。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

预言家游报7月明星代言投放观察挑选了3款重点的游戏，两款本月上线的新游戏和一款老游戏。两款新游戏都是知名IP，在玩家的心中拥有一定的知名度。而《原始传奇》这款老游戏，迎来了他们的两周年庆典。

《原始传奇》上线的两年间，代言人的选择一直是谈玩游戏工作重心所在，毕竟游戏需要吸引主要目标群体——中年男性用户。从早期的冯小刚，到后来的迪丽热巴，《原始传奇》坚持的都是这一路线。上周，《原始传奇》官宣了新代言人江疏影，并拍摄了一系列有关江疏影的视频素材。

去年《摩尔庄园》大获成功之后，另外一款95后的童年记忆《奥比岛》手游今年也正式上线。作为一款主打童年记忆的游戏，把玩家们拉回那个童年时代显得尤为重要。其实在游戏上线之前，雷霆游戏特意邀请金龟子和董浩为游戏演唱了主题曲，同时也推出了苏醒的版本。主打情怀牌成为了《奥比岛》的宣传推广策略。

《魔力宝贝》系列也是一个拥有较长历史的网游IP，近年来推出了多部手游产品，《魔力宝贝：旅人》则是最新的一部。和《奥比岛》的推广思路相似，《魔力宝贝：旅人》找来了蔡卓妍阿Sa作为代言人，化身时光女神，希望能够借助近期《乘风破浪的姐姐3》的人气提升游戏知名度。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**《原始传奇》：贪玩形成代言人方法论，江疏影女神人设仍好用**

传奇类游戏已经成为游戏圈最为热衷邀请代言人的品类之一。男性要求知名度高，且较为成熟。女性则一般为女神人设，受到主流用户的欢迎。事实上，《原始传奇》之前的代言人冯小刚和迪丽热巴都是采用类似的路数，并取得了一定的成功。于是，他们沿袭了类似的代言人思路，找来了江疏影。

根据热云数据显示，《原始传奇》7月的买量投放主要集中在月末2周年庆典前后。7月31日达到顶峰，单日投放素材数高达1091组。虽然和其他传奇游戏投放力度无法相提并论，但《原始传奇》还是通过代言人进一步提升了游戏的知名度。

两周年庆典当天，《原始传奇》公布了一系列游戏相关消息。除了江疏影成为游戏的代言人之外，他们还公布了游戏内金镶玉非遗合作项目，并邀请了知名歌手周晓鸥现场演唱了游戏战歌《相信自己》。

《原始传奇》的投放素材主要围绕新任代言人江疏影展开。江疏影拍摄的视频素材中，主要强调了《原始传奇》的1.76版本，与电脑上的版本几乎没有区别，原汁原味。而在另外一些素材中，江疏影用12秒左右的时间介绍了《原始传奇》，并和那些无意中划到广告的用户们进行了一次互动。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

另一方面，《原始传奇》也在积极拓展其他领域的合作。7月29日，《原始传奇》官宣了与代言人古天乐主演的电影《明日战记》实现联动，具体联动形式还没有对外公开。

全方位立体式的明星投放和推广，为《原始传奇》带来了诸多新用户。根据七麦数据显示，从6月底开始，《原始传奇》单日App Store的下载量就在不断提升。7月30日单日新增下载突破4400次，《原始传奇》还有进一步提升的空间。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**《奥比岛：梦想国度》：两版主题曲，董浩金龟子把大朋友带回童年**

主打未成年人的游戏，一般不会邀请太多的代言人。但如果产品定位发生了变化，希望能够招揽一些成年受众时，邀请一些代言人，唤醒受众的情怀就非常有必要了。《奥比岛》的明星代言人思路就是如此。

根据热云数据显示，7月12日上线开始，《奥比岛：梦想国度》就进行了较大规模的投放。7月26日，投放的力度逐渐加大。一直到7月31日，《奥比岛：梦想国度》单日投放素材数达到了2798，对于这种儿童游戏已经属于一个比较高水平的投放力度。

游戏上线之前，《奥比岛：梦想国度》放出了两个版本的主题曲《种愿望》，一个版本由苏醒演唱，另一个则是由知名少儿节目主持人董浩和刘纯燕演唱。其中，官方主要推广的是董浩和刘纯燕合唱的版本，尤其是在B站，收获了37.7万播放，955条评论，很多评论都表示童年回来了。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

相反在投放侧，《奥比岛：梦想国度》并没有进行类似的推广策略，而是把宣传的重点放回到游戏的身上。童年专属记忆、适合女生游玩以及领取礼包码是游戏的主要宣传关键词。

截至目前为止，《奥比岛：梦想国度》在App Store免费榜上排名第10，畅销榜上排名第31.由此可见，《奥比岛：梦想国度》情怀牌已经奏效，积攒了大量的用户，下一步游戏制作方需要思考，如何将用户基数转化成收益。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**《魔力宝贝：旅人》：阿Sa主打80后，情怀换不来收入**

MMORPG是手游领域经久不衰的游戏类型。虽然，过去一段时间以来许多新的游戏类型涌入手游市场，但MMORPG仍然是产量最高的游戏类型。《魔力宝贝》作为一款经典的MMORPG游戏，曾经是一代人的网游记忆。现在，《魔力宝贝》IP推出新的手游作品，主打情怀也是顺理成章的。

作为拿到Square Enix官方授权的20周年重制版本，《魔力宝贝：旅人》7月29日上线后随即进行了大规模投放，投放素材数为629组。7月31日投放量372组素材，但到了8月就没有继续进行大规模投放。

众所周知，《魔力宝贝》是80后一代人的网游记忆，而蔡卓妍所在的组合Twins也在80后心目中拥有极强的号召力，两者的受众年龄层是完全重合的。

观察《魔力宝贝：旅人》的投放素材不难看出，明星代言人蔡卓妍成为了宣传的重点，最为重要的一条素材就是阿Sa邀请勇者们去可以容纳五万人的法兰王国抓神宠。另外一些素材中，阿Sa把玩着《魔力宝贝》IP的手办，着力突出游戏20周年的的情怀感。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

根据七麦数据显示，受制于游戏本身素质，《魔力宝贝：旅人》在App Store免费榜排名第32名，畅销榜排名第17，整体成绩比较一般。如果想要让IP重新活化，在受众中的印象重新活络起来，《魔力宝贝：旅人》还有许多工作要做。

**栏目简介：**

预言家游报参考热云数据相关数据，分析热门游戏产品明星代言人投放情况，分析方向主要为产品投放素材、创意组数的累计统计和月度单位时间投放趋势以及投放媒体、流量平台的数据占比，还有热门文案参考，这些数据可为明星经纪挑选游戏代言给予一些指导和帮助。

热云数据相关咨询请联系，点点：13581745497

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)