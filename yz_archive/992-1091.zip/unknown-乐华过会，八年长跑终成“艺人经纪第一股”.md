# 乐华过会，八年长跑终成“艺人经纪第一股”

> 公众号: 娱乐资本论
> 发布时间: 
> 原文链接: https://mp.weixin.qq.com/s/kd59qcIwp7DOsFJV8bmdOw

---

![图片](http://mmbiz.qpic.cn/mmbiz_gif/bXYBmumSooBmDa2AKYWOrhLQpkiaGmWibJ16dtEwnOdAdqOa9CAuSq8vulGViaYhMumjBp748l3IYlcCxArJssC9A/640?wx_fmt=gif&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)

**作者｜Cloud**

今天（2022年8月7日），乐华娱乐正式通过港交所聆讯，在八年内第四次冲击资本市场，终于有望成为“艺人经纪第一股”，创始人杜华在朋友圈感慨道：

**“从无到有，从个人梦想到企业目标，谢谢每一位支持我们的你，没有你们就没有今天的我们。”**

![图片](http://mmbiz.qpic.cn/mmbiz_jpg/jNZszpkibXxibJx7MHv0hrbDzYFfDvW5XdoVsSz4IEmr4ewbiaGcSA3gs7gSiaMr3PqNnH2bD1Hc3IRgUCS6gGd9pA/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=1)

5个月前，乐华娱乐向港交所递交招股书，让王一博、孟美岐、李汶翰、A-SOUL等艺人的收入第一次暴露在公众面前，从数据来看，杜华口中的“你”，无疑就是这些“核心资产”和他们数量庞大的粉丝，乐华娱乐的业绩表现，也长期和他们绑定在一起。

近日在接受新浪财经采访时，杜华表示公司“**大部分自主培养的艺人都已在续约**”，尽管三个月前A-SOUL曾出现争议事件（[虚拟偶像真相：打工人血泪，粉丝们梦碎，资本方困局](https://mp.weixin.qq.com/s?__biz=MzA5NjcxNTIyNg==&mid=2650705752&idx=1&sn=ff6ac38c3f72d18905b774f3b97992f9&scene=21#wechat_redirect)），杜华仍对旗下虚拟偶像业务充满信心，经历了成员变动的A-SOUL仍在活动中，在多方推动下，VR演唱会等活动也在规划中，这项一年收入同比增长近80%的业务，极有可能成为乐华娱乐未来的“**第二曲线**”。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

图源：IC photo

2015年，乐华娱乐挂牌新三板，号称"艺人经纪第一股"，2018年从新三板退市；2016年，乐华以18.98亿估值试图借壳上市，但并未完成利润要求，借壳宣告终止；2018年，《偶像练习生》和《创造101》开播，乐华同年4月开始接受上市辅导，但随着选秀被叫停，2021年6月乐华娱乐A股上市的愿望再次落空。

2022年1月，"杜华退出乐华娱乐股东行列"上热搜，公司控股主体转为注册在香港的YH Entertainment Group（HK）Limited，该公司100%持股杜华等高管新转入的主体天津乐华，这一举动被视为乐华娱乐冲刺港交所的前奏。

这一次，乐华交出了连续三年收入和利润双增长的成绩单，实现盈利达7.46亿人民币，其中2021年艺人管理收入占比高达91%。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

数据来源：乐华娱乐招股书

同时结合招股书合理推测，从2019年到2021年，王一博收入从3227万飙升至1.3亿，并在去年达到3亿，成为了当前乐华娱乐的“王牌”。

**显而易见，站在耽改停摆、选秀叫停和限娱令的三重门前，注册在开曼群岛，试图在香港上市的乐华娱乐打造"帝国"的梦想，仍然和王一博等顶流艺人紧紧绑定在一起。**

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**大厂参投，明星仅有韩庚持股，  
杜华独掌半壁江山**

据招股书披露，乐华娱乐的业务由艺人管理、音乐IP制作与运营和泛娱乐三个板块构成，娱乐资本论观察到，这三项业务均与互联网大厂构成紧密关联。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

上市主体乐华娱乐有限公司的持股架构中，包括东阳阿里巴巴影业和量子跃动（字节跳动的全资子公司）两家大厂，不仅对乐华进行股权投资，也为其艺人提供平台和技术支持。

前者持股15%，并投资了同样占股15%的华人文化集团，旗下优酷平台与乐华艺人韩庚、王一博合作的《这！就是街舞》已经播出四季；

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

后者与乐华娱乐合作推出的虚拟偶像组合A-SOUL于2020年在B站出道，在饱受"资本入侵二次元"的争议之后，凭借成熟偶像的业务能力和远高于同行的技术呈现水平，获得风评反转，帮助乐华的泛娱乐业务增长79.6%，增收超过1600万元，高于公司2017年上半年的利润总和。到了2021年，以A-SOUL为主的泛娱乐业务则为乐华带来3790万元。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

据娱乐资本论推测，另外两家大厂则以更隐秘的"供应商A"和"客户A"身份出现在招股书中。

"供应商A"被描述为"总部位于中国的科技和社交媒体集团，于2010年成立，主要专注于内容制作及视频流媒体"，乐华在2019年为其付出了超过4200万的营业成本，占全年总成本超过12%。**这一年，爱奇艺《青春有你》第一季开播，出道团体UNINE中乐华艺人李汶翰、胡春杨独占两席。**

"客户A"则是"于1997年成立，主要专注于提供音乐流媒体服务"的中国集团，2019年为乐华带来超5300万元收入，占总收入比重达8.3%。**同年，《陈情令》在腾讯视频独播，成为现象级爆款，主演王一博的单曲《无感》在QQ音乐卖出超1700万份。**

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

图源：乐华娱乐招股书

被外界反复猜测身份的孙一丁，除了众所周知的前国美高管、前瑞思英语CEO以外，在招股书中则被定义为与杜华"作为配偶同居"的一致行动人，两人通过个人持股和公司主体代持，持有上市主体48.2%的股份。

而一直被包装成"乐华老板之一"的艺人韩庚，则仅借由持股"西藏华果果"间接分蛋糕，据娱乐资本论计算，其占股比例仅为2.47%左右，不及"担任本公司若干子公司的监事"的王欢（6.02%），仅高于公司新三板挂牌时入场的独立第三方股东肖飞（0.03%）和方韶军（0.18%）。

在经营层面，作为一家以艺人管理为绝对主营业务的公司，乐华娱乐试图通过艺人经纪市场占比1.5%的"第一股"身份，巩固自己作为赛道领跑者的"人设"，并在招股书中不具名地列举了另外四家公司作为对照。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

图源：乐华娱乐招股书

娱乐资本论结合公开数据推测，这四家公司很有可能分别为嘉行传媒、开心麻花、泰洋川禾和天娱传媒，按招股书里面的说法，艺人方面的收入分别为7.5亿、7亿、6.5亿、3.4亿。

当然，这四家公司的演员经纪逻辑与"练习生-偶像"的经纪公司运营逻辑存在较大差异，但正如嘉行重度捆绑杨幂、迪丽热巴；开心麻花主依靠沈腾、马丽；天娱深度绑定华晨宇一样，乐华也有着自己的“重点依赖艺人”。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**王一博一年赚3个亿，成乐华“吸金牛”**

据乐华披露，目前公司拥有58名签约艺人和80名训练生，三年内公司分别为他们支出了2.4亿、3.18亿和5.29亿人民币的管理成本，占总成本比例连年递增，2021年达到76.9%。

这群艺人中，王一博是乐华近两年的重点“现金牛”。在乐华娱乐长达445页的招股书中，王一博的名字出现了18次。

**供应商列表中，从2020年开始，排名前五的供应商均为"签约艺人控制的企业"，综合各项数据，娱乐资本论推测供应商B、D、E、F，很有可能分别为王一博、韩庚、范丞丞和孟美岐各自所在的公司主体。**

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**也就是说，在《陈情令》大火的2019年，乐华为"供应商B"（合理推测为王一博获取个人分成的公司）付出了3227万；2020这一数字飙升至1.3亿，占总经营成本的31.1%；2021年这个数字超过3亿，占比高达43.9%。**

**这背后，既是王一博个人越赚越多、吸金能力不断飙升的佐证，也存在乐华在其火后，重新调整分成比例的可能。**娱乐资本论从行业中了解，大量艺人经纪公司艺人与公司的分成模式为5:5或4:6（艺人拿6成），而部分头部艺人的议价权较高，可以达到2:8甚至1:9。

在招股书业务介绍中，乐华称自己与艺人签约的时长为5至15年，并有到期自动续约1至5年的机制。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

上下滑动查看更多；图源招股书

**这些来自于艺人经纪的收入，占据了乐华娱乐总收入的91%。**这也对应了招股书中的风险因素：

**"倘我们未能维持与艺人及训练生的关系或扩大我们签约的艺人及训练生的数目，我们的业务、财务状况及经营业绩或受重大不利影响。"**

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**造星高速被封，成果复制存疑**

2021年5月，监管连出重拳叫停选秀节目，关闭了刚刚开辟还未成形的练习生"飞升"通道，再加上耽改受限，乐华手中被验证过打造爆款的两张王牌被锁死。

但在韩国的布局和成名艺人储备为乐华提供了"避风港"，在招股书中，乐华多次提到了其在韩国的布局，相关字样出现149次。

除了在韩国招募练习生，招股书中涉及的LEE Sang Kyu和JUNG Hae Chang分别为专业的音乐制作人和孵化了After School和SEVENTEEN等组合的Pledis Entertainment 前负责人。

EVERGLOW作为乐华旗下原生韩国出道的女子组合，由一位中国成员和五位韩国成员组成。在偶像工业成熟，竞争激烈的韩国，出道至今发布三张迷你专辑，获得两次打歌舞台一位，但与同为五代女团的aespa和ITZY存在较大差距。

乐华刚刚推出的七人男团TEMPEST则全部由越南和韩国籍艺人组成，这只"去中国化"的团体在招股书发布一周前刚刚出道，目前仅发布一支单曲，后续发展尚未可知。

2020年参加《青春有你》第二季，总排名前9之外并未成团的金子涵，年底与乐华旗下的六位练习生组成女团NAME出道，杜华与王一博等乐华艺人发博为其宣传。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

在招股书中，虽然艺人收入分成占总成本的比重连年递增，但乐华披露的艺人宣传成本近三年均维持在10%左右，音乐内容制作成本则经历了从7.7%到9.7%，再到6.6%的波动，这项业务对收入的贡献也随之降低到2021年的6.1%。

相比之下，仅占总成本1.2%且连年比重下降的泛娱乐业务，借由虚拟偶像团体A-SOUL的热度取得了较为高效的增长，乐华也在前者在二次元圈层引爆热度之后迅速推出了男性形象的"量子少年"。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

图源：乐华娱乐招股书

娱乐资本论注意到，连续三年实现盈利增长的乐华娱乐，2020至2021年税后年内总和利润超6.27亿元人民币。在此基础上，公司分别向股东分派股息2亿和4亿人民币，两次派息分别发生在2020年10月和2022年3月，即乐华A股上市辅导期间，和本次向港交所递交招股书之前。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

图源：乐华娱乐招股书

乐华娱乐在选秀严重受限的情况下，仍能通过港交所聆讯，其对自身造血能力和艺人吸金能力的强大自信没有落空，乐华和杜华的“乘风破浪”来到了新的阶段，“艺人经纪第一股”能否持续制造顶流，并在虚拟偶像和元宇宙赛道制造新的娱乐帝国，值得期待。

近一个月内，分别来自电影、电视、艺人经纪赛道的博纳、柠萌和乐华相继传来资本市场过会喜讯，在漫长的冬夜里，三家赛道头部公司，率先为全行业点亮了黎明的曙光。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)