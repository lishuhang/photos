# 买NBA，引MCN，支付宝能否站上短视频的牌桌？

> 公众号: 娱乐资本论
> 发布时间: ref: <Node>
> 原文链接: https://mp.weixin.qq.com/s/qZoMQe-6ZLr0EYsftOjlxA

---

![图片](http://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd488dqSKT01NQhGtVG3ZNPxvQNiaoUvE0dqwHmpyyTgAuO3xpHZEiaYZVMayjhHKiaYWr2ib5K3NmK7Sw/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)**作者 | 西西弗**

张鹏是重庆一名量化交易员。为了打造个人IP，他在多个第三方互联网平台上都开设了短视频账号“小凡投基金”。不过，其中粉丝增长最快、流量最大的是支付宝生活号。

从今年2月开始发力，两三个月下来，“小凡投基金”在支付宝上已经有2.5万粉丝。

按理说，这样的涨粉速度不算慢，但“小凡投基金”在支付宝内容生态内也只能算中腰部账号。真正的头部大号，粉丝已经突破100多万。

![图片](http://mmbiz.qpic.cn/mmbiz_png/HKEDX7MqXK3NP2wZ0DibJm1Vvz1HMB0D6RZpiciaDIpRXjiapomrt2UibABlCD0U1WdGL3tuEOSFfS9rZZKg7sNOFsw/640?wx_fmt=png&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=1)

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

或许很多人还不知道，支付宝除了领能量、喂鸡、还自行车、看基金、买保险、签到、缴电费以外，竟然还可以刷短视频。

今年初，支付宝宣布与NBA达成合作后，很多人才发现，原来支付宝在发力做视频内容。NBA只是支付宝的内容板块之一，更多的短视频和直播内容其实是集中在支付宝生活号。

生活号自从2015年就上线，一开始只是图文内容。从去年7月份开始，生活号才开始发力短视频和直播。通过MCN激励计划，大量招募泛财经、民生、休闲3类优质内容账号。单MCN引入100个账号的，单月激励上限额为10万元。

最近，支付宝首页新增“看一看”的内测入口，用户点击后会跳转到生活频道播放视频。支付宝生活号运营负责人透露，过去半年生活号入驻账号数增长超10倍，日均作品上传量涨幅超过300%。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

支付宝做内容的意图很容易理解，毕竟，所有互联网平台都在通过内容拉长用户停留时间。但支付宝本质上还是一款支付工具，短视频和直播内容真能达到平台预想的效果么？到底什么样的用户会选择在支付宝上看短视频？

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)**头部账号粉丝已过百万，理财类短视频内容繁荣**

支付宝并不是张鹏做基金短视频账号的第一个平台。他的第一个平台是抖音。        

去年上半年，用了3个月的时间，张鹏就在抖音上积累了将近3万粉丝。不过，抖音上无法直接购买基金，基金类内容吸引的用户必然要引导至站外交易。        

但从去年二季度开始，抖音严格禁止站外引流和站外成交，尤其重点整治了一批财经类账号。随着平台治理趋严，张鹏的“小凡投基金”也在抖音停更了。         

好在，从去年年中开始，支付宝也开始发力短视频内容。张鹏就在第一批基金达人受邀之列。在张鹏看来，做金融类短视频内容，还是在支付宝这样合规的平台更安全一些。      

“其他平台做金融理财短视频，除非是做的比较早的，已经成了大号，才会有流量，否则新的金融理财类账号都会被限流，甚至会被直接封杀。”      

目前，包括雪球、京东金融、天天基金等几家互联网第三方平台都有各自的短视频内容孵化计划，但相比之下支付宝走得更快。      

在支付宝生活号的内容生态中，基金、银行、保险、理财等泛财经类的金融账号相当繁荣。包括博时基金、中信银行等主流金融机构都入驻了生活号，而且，生活号中已经出现了粉丝超过百万的头部大号。比如，小高理财。

“小高理财”的背后是一位基金操盘手，在抖音上的同名账号只有十几万粉丝，但在支付宝上却有132.6万粉丝。“我2016年就注册了生活号，2022年，平台管理员打电话找到我，商量创作一些短视频方面的内容。” “小高理财”创作人表示。

对于用户来说，支付宝原本就提供各种理财服务，在这样的平台上看理财金融类内容，场景恰好匹配。

而且，在平台的背书下，支付宝上的理财类博主身份更具备真实性。

比如，当创作者理财分超过800的时候，头像下方会显示理财分超过800。据了解，支付宝总资产达到31.8万才能达到这个标准。而理财分是支付宝为用户提供的一项理财“体验”服务，分数越高，代表理财方式越合理，配置越科学。

在创作者的主页上，除了内容动态、直播、问答的按钮以外，还有“实盘”按钮。用户可以清晰看到短视频创作人在支付宝上的基金持仓。比如，小高理财在支付宝上的实盘为152.47万。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

“支付宝有专门的运营团队，创作人可以直接跟运营沟通，其他平台还没有这么方便。”张鹏表示。

在支付宝上，“小凡投基金”曾经是排名在100名以内的财经类账号。

一开始，支付宝用打分的方式对账号进行现金奖励。每个月，支付宝会根据账号的阅读量、阅读时间、粉丝评论等多个维度进行综合打分，并将选取综合得分前300名进行奖励。10名每个账号奖励1万，11-50名，每个账号奖励6000；51-150名，每个账号奖励3000；150-300名，奖励1000。

在这样的规则下，“小凡投基金”每个月的综合得分都能排到全域前100名，并且拿到3000-6000元的现金奖励。    

为了鼓励达人发布更多内容，支付宝目前改变了奖励规则，由之前的综合打分改为按照CPM计费，完全按照流量高低拿奖励。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)**休闲生活类内容特色明显，以代运营为主**

在观察多个用户的支付宝页面之后，我们发现，支付宝平台会按照针对不同用户，推送有针对性的内容。

比如在支付宝上买过基金、理财产品的用户，更容易刷到一些泛财经内容，而没有任何理财行为的用户，则会更多刷到生活类内容。    

事实上，生活类内容，已经是支付宝上第二大短视频内容品类，包括衣食住行、运动、科普、萌宠、旅游、健身、亲子家具等细分内容垂类，和支付宝的消费属性关联度高，人群普适性强。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

相比抖音、快手等纯内容类短视频平台，支付宝生活类短视频内容2022年才在支付宝首页全量上线，起步较晚，在用户心智方面并不占优势。

因此，支付宝并不是生活类博主们发布内容的主要渠道，而生活类账号也多选择以代运营的方式在支付宝上发布内容。

“我们核心肯定还是双微加抖快，支付宝算是中等权重吧。比大鱼号、搜狐号这些老牌的账号权重高一点。我们内容同步全网分发的时候，会更新在支付宝上，有时候是支付宝生活号按照协议自动抓取。”支付宝上某影视大号的运营负责人表示。

包括上游新闻在内的一些媒体账号也是类似的情况，甚至一些商家号也是如此，比如聊城滨河动物园。

“我们门票采取包销的方式合作。线上票务部分，全部包给了美团旗下的美策票务2023年一季度300万。线下的票务包销给了票付通。所有宣传，也都由他们来做，我们什么都不用管。像支付宝上这些短视频宣传也不是我们做的。”聊城滨河动物园相关负责人向剁椒TMT表示。

另一位宠物博主表示，他们的主要运营平台是抖音，支付宝上包给了专门的代运营公司，每个月有一笔分发收入。

为了引入更多短视频账号，支付宝从去年7月发起了一项内容激励计划，要求MCN引入并完成绑定的具备含泛财经、民生、休闲3类内容生产能力的达人账号数量大于等于5，同时对于引入达人账号总量大于30的MCN，要求这三类内容生产能力的达人账号数量占总引入达人总量不低于40%。

贝壳视频就是生活号上头部的短视频服务商。从2022年底，贝壳视频就与支付宝生活号合作，还做了集五福的短视频内容传播。 

“各大平台都在做自己的内容生态，特别是没有自己内容场的平台。就像支付宝、美团、拼多多这种平台，他们的痛点在于内容生态搭建。在过去的几个月中，我们帮助生活号引入了3000多个账号。”贝壳视频相关负责人表示。

基本上，各家平台都会有相关的生活类短视频内容，但每家平台又有各自的特色。

比如多多视频上的账号主体多是品牌和店铺，发布的内容以卖货为主，通常带有强推销性，强调价格便宜，部分短视频账号的内容甚至直接是直播带货中的切片。

即便是生活类内容，多多视频也以生活场景中推销商品为主。随机挑选一条短视频文案感受一下——“要不是为了过夏天，我是不会喝黑咖啡的，但是自从发现了它，配料表干净，关键不到40块钱就能买70条。”

而淘宝逛逛这样平台上的短视频内容风格则更偏向于小红书，彰显高品质的生活方式。

从达人的账号名称上就可以看出来一些内容特色规律，比如宝宝姐爱化妆，萱萱爱美食，詹小小夏天瘦了等。这些账号发布的短视频内容更倾向于，春天要出去郊游，穿美美的衣服，化淡淡的妆，拍各种大片……

有时候淘宝逛逛的博主还会以明星为例，剖析一些明星的穿搭，生活特点，以此来向用户传递一种高品质生活的心智理念。

支付宝生活号上的生活类短视频内容也做出了自己的特色。

在支付宝生活号上，账号内容主体除了一般的生活类达人以外，还有很多实体服务类账号。比如动物园账号、景区账号、厨具账号、影视城账号，而这些账号的内容以轻松搞笑为主，几乎没有商品推销的痕迹。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)**支付宝短视频内容的机会与未来**

虽然上线时间短，但支付宝生活号的内容数据并不低。有些短视频点赞量高达几万，播放量可达到上百万；直播方面的数据更值得关注，有些金融类基金直播间观看人数超过10万，甚至20万。         

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

也许你会好奇，作为一款支付工具，谁会在支付宝上刷短视频，又怎么会有这么大的流量呢？

这要得益于支付宝庞大的用户量。根据支付宝官方宣布，2022年，平台用户量已经超过10亿。即便是只有5%的用户愿意停留在支付宝上看短视频，那也有5000万。

有用户直接在短视频评论区留言，我竟然在支付宝上刷短视频刷了半个小时。博主回应他的留言说，没错，就是支付宝。

相比微信，这两年，支付宝的数据不容乐观。不管是市场占有率，还是APP的打开次数，支付宝都被微信压了一头。短视频的加入从某种程度上确实拉长了用户停留时间，这是当下支付宝应对竞品的一大筹码。

不过，业内对支付宝做短视频的未来前途评价褒贬不一。

有业内人士认为，支付宝在金融理财类内容领域比抖快平台更有优势，从这点突破，支付宝的短视频内容生态是有机会的，可能会做出一些超越目前短视频平台的新内容生态，并笼络一批玩儿金融的高净值人群。

3月底，证券行业传出消息，行业三方导流新规或即将重启，目前券商数字金融部等部门已开始向蚂蚁财富、腾讯自选股、京东金融等互联网平台询价。

其中支付宝APP“股票”模块，在“首页”、“自选”、“市场”三大模块基础上，新增了“券商直达”模块，为安信证券、国信证券、兴业证券、中信建投证券、财通证券等券商提供股票开户导流服务。

“支付宝加入券商导流大战，可能会使得整个导流格局产生很大变化。”有券商相关人士表示。

但不管是擅长的理财金融类内容，还是大力引进的生活类内容，支付宝在打通内容生态方面都存在一定障碍。

张鹏就存在一些困惑。他发布的短视频主要涉及两种内容。一种是向大家展示基金的买点和卖点，以彰显自身在量化基金交易方面的成功，还有一种是具体的底层操作逻辑。

“很明显，用户们更喜欢看我展示买点和买点这些漂亮的节点，后面真正的金融知识可能需要系统学习。但真正愿意花时间通过短视频和直播去学习的人不多。也许对于金融知识内容来说，用户从短视频获取信息的效率远不如文字信息那么高。像小高理财也是以图文内容为主，而不是以短视频为主。”

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

恶劣天气，本图为AI制作，创意by娱乐资本论

张鹏担心，在短视频中一直向用户展示他的买点和卖点，容易让用户产生审美疲劳，进而出现脱粉现象，终究还是差异化的内容才能给用户带来新鲜感。

高峰也有自己的困惑。有用户给他反馈，他的短视频紧跟大盘走势，很有时效，但是一般都在上班时间发出来。“打工人在上班期间没法刷短视频，容易被领导抓住。图文没有声音，看起来更方便。所以，我也改成了图文为主，短视频为辅。”

一方面是财经金融类内容存在信息获取方式的矛盾，另一方面，生活类账号方面商业化方式也不多。

目前，在生活号短视频左下方有些短视频可以挂小程序链接。比如，好知价的小程序就经常出现在支付宝短视频内容中。其他的商业化方式，目前还比较少。         

有人问，支付宝这么大的流量，为什么就不能卖货呢？

一位新消费品牌创始人在一场直播连麦中称，没有人知道在支付宝上怎么卖货，当下的内容才刚刚崛起，用户属性也摸不准。

未来，可能只有进一步深入商业化，才能让这些已经入驻支付宝的博主们真正扎根在平台上，实现长期经营。

**话题互动：**

**你在支付宝刷视频吗？**

**推荐阅读**

[![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247577344&idx=1&sn=2c4e5d29b48e8987db9bde04a72387af&chksm=c058badbf72f33cdac93908a072ed55bc32d2b9175855ccffcd442e7f32a4d764036c60846f2&scene=21#wechat_redirect)

[![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247576834&idx=1&sn=44fd12eb81602abf1c3a01ee1dff0057&chksm=c058b8d9f72f31cf0e4c0dd0f2c4f9f0641bf989131966067bb318d76d51fd6d60b9e842b0da&scene=21#wechat_redirect)

**选秀节目消亡后，秀人和公司如何求生？**

**点击观看**

**↓↓↓**

**如需商务合作后台回复【商务】**

**如有转载需求后台回复【转载】**

**更多文娱产业背后的经济逻辑，来关注↓↓↓**