# 在闲鱼翻倍换“旧”的FREITAG，智商税or真香？
> 公众号: 娱乐资本论
> 发布时间: 2023年07月13日 14:47
> 原文链接: https://mp.weixin.qq.com/s/8UiTwJrifO2xtn0O8VBOEA
---

![](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd5XKRkVpVVL3eMHVjGS5HhMeg5rpc668WmmWricLTCiafUgPxWosYTxLGOfabn3UwsqrMp3JNtqXHGQ/640?wx_fmt=png)

**文|廿四**

两千块钱买一个脏兮兮、还有臭臭卡车皮味道，但是独一无二的轻奢包，你愿意吗？

一家来自于瑞士的包袋配饰品牌 FREITAG，为了买到它家的包，国内外的潮人可是跑断了腿。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK06X3mW3dTUU9ZW1NqZ9uWulm0RgsF5UIu51yic5Pn2ql0wt54LSYichaiaXjkkJsZGMMwG1c6wlTxmw/640?wx_fmt=png)

最近，剁主竟然在闲鱼发现了FREITAG的社交圈，越来越多早已不是小众时尚的年轻打工人、学生开始入坑，甚至成为铁粉，衍生出更多的“F门人”。

“安利给大家一个不怎么花钱，背腻了又能换不同花色背的方式：闲鱼。入坑五年来，我换了七八个包，不喜欢的就挂在闲鱼上等有一个有缘买家，然后淘新一个有眼缘的包，钱也没有多花。”“F门人”Jack告诉剁主，遇到纯黑、字母、工业绿、玫红等比较稀有的颜色实在喜欢，加价他也可以接受。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK06X3mW3dTUU9ZW1NqZ9uWuLwkwOl8UFnKR1z54l5dDrWAibzJY56dT6fhQ8lsdO2FD70DiaNeWV43g/640?wx_fmt=png)

甚至对有些“F门人”来说，背得越旧、越有痕迹的FREITAG包越有魅力，也更值得溢价买。

被勾起好奇心的剁主从各方了解到，成立之初，FREITAG就出售了一个独一无二的包包品牌概念“环保可循环”，所有的包用破卡车布制作，设计师会在不同的布上选择不一样的位置进行裁剪，所以，每只包带的图案永远不会撞，款式的每一个配色都会被拍照记录在案，以防撞同款，破坏包包本身的独特。

言下之意，每个包包都是“绝世孤品”。包包配色的系列也从不必遵循时尚圈的当季流行色，全来自于欧洲高速公路上奔驰着的卡车配色。正是这种特色独行的风格，FREITAG吸引了全球的潮人跟随。

对Jack来说，买之前，他觉得品牌“推崇环保”都是噱头和智商税，用的材料并不值钱，甚至可以说是废物利用，不应该卖得很便宜吗？买之后却“真香”，开始沉迷于收集各种各样颜色的图案和配色。

值得注意的是，之前大家遇到“F门人”的场景更多的是健身房、咖啡馆和设计师、亚人们的肩上，这段时间，城市漫游（city walk）爆火之后，年轻人背FREITAG得越来越多，成为骑行、散步时的穿搭必备。

由卡车篷布制作而成的小众破包袋，也没找明星带货，怎么就成了如今年轻人备受追捧的轻奢潮牌？

![](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd5XKRkVpVVL3eMHVjGS5HhM96SMCp5nUGM0eX9wb6oNE6mVwhKHO97icYHNGdKnKqziaQ16151htNgw/640?wx_fmt=png)

**怎么就成了F门信徒？**

“谁种草FREITAG是因为环保啊，最开始肯定是因为好看和实用、耐用，防水油布随便丢在地方都不心疼，是篷布，下雨天还能套在头上用来避雨！”

这是初代粉丝小八入F门的理由，她最喜欢的一款是奶白加灰调色的F14，打工人必备，不仅有扩容，内袋有分隔，外部拉链还能收纳常用物件，尤其是装笔记本电脑不成问题，不会折角，也不怕下雨淋湿。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK06X3mW3dTUU9ZW1NqZ9uWuEIIENhicibicjwqT3jic0vkDdL49bDcnFn0Qy8rYVFFIPGXfOibIKXIAQYg/640?wx_fmt=png)

大部分人入手的第一个FREITAG，通常都是邮差包。F40尺寸最小，适合装纸巾、耳机，F41是用户购买最多的尺寸，适合女生逛街时候背；F11、F14、F13三款则是邮差包的经典款，在造型上大同小异，尺寸略有不同，能容纳ipad、书本、折叠雨伞等，满足一天的出行物品，安全带材质的包带宽度也适中。

已经停产的F12是目前在闲鱼等平台溢价最为严重，如圆点拼接、牛皮纸色的价格已经翻倍。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK06X3mW3dTUU9ZW1NqZ9uWuVDPwJRA9zSpZRD9wgI8vA36wlp7OwDwTn86ZSoJ3J4QRib9R6PKm4FA/640?wx_fmt=png)

而对于00后木木来说，买FREITAG主要是好搭配，甚至会降低她买其它包包的欲望，“不分时间不分场合，出门前想背的只有FREITAG，以前是衣服搭配包，现在不管穿啥，这个包都能完美融合，最爱的就是容量，不大，但是能装，现在出门，就算旁边有很多只包摆在眼前，还是只会下意识地顺走那只亮眼的FREITAG邮差包。”

FREITAG的配色也有自己的“鄙视链”，颜色来自于旧卡车的防水布，彩色太容易买到了所以没什么稀奇，彩色，纯色、黑白配色或特殊图案的，F门人会高看一眼，不过由于吸热的缘故，很难看到深色，因此，全黑配色作为少见的配色，价格被炒得很高。

蓝色、红色是5到10年前欧洲卡车篷布最流行的配色，但在国内，这些强烈而明亮的色彩却是很多年轻人都不敢碰的雷区，而今年多巴胺穿搭开始在年轻人流行起来后，FREITAG过去被潮人们嫌弃的纯蓝色、亮红色也被带火。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK06X3mW3dTUU9ZW1NqZ9uWuwammiaIpyKGfiaibCRX5ylQJ961ZFBy1Gn0U5zqTLuC1ibcAWHl8aiay5IA/640?wx_fmt=png)

两者盛行的本质都是一种情绪穿搭，是年轻人在追求情绪价值，对于生活压力的盛放，唤醒积极情绪的一种方式，来追求一种对生活的自我满足感。木木愿称FREITAG为“多巴胺最百搭单品”。

好看、好搭配是入坑的第一步。对于Jack来说，入坑后，他会经常性地拿起手机打开小程序或者官网，有空就刷一刷。因为好看的刚上架就卖掉了，卖不掉的往往巨丑，看过一波又一波，一旦遇到一只自己中意的，期待的心情就会被无限放大，上头购买，“就是害怕手慢了之后别人就买了，遇到一个热门款式的稀有配色，我从不犹豫，直接买，反正在闲鱼迟早能蹲到有缘人。”

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK06X3mW3dTUU9ZW1NqZ9uWuiaibfawf8Sj16d9YmLRdC6iauWiaJDx4t54VyCMgU41HuwXPJfzricCM3pQ/640?wx_fmt=png)

剁主发现，与LV等奢包的限购限量等饥饿营销方式不同，FREITAG的每个包都有一张独一无二的“身份证”，自带价值稀缺，特别是买一个包包后，偶然之间有缘在官网看到这块布原先在卡车上的样子，他前世今生的宿命就跟用户真的链接到了一起。对于F门人来说，虽然入坑前期不买，但会和产品频繁建立情感连接，对品牌的忠诚度也会一直上升。

在小红书，有无数F门人调侃：“难逃FREITAG劫，遇到喜欢的真就写着自己的名字，要一直背到给自己的女儿当嫁妆。”“本来就是做旧的，不会像奢侈品包一样要小心翼翼去呵护，真的是一个包可以用到传宗接代。”

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK06X3mW3dTUU9ZW1NqZ9uWuJA84cnmLc7UUNurH4fIPnPYskjg64mgh18jrE2CkInst8zvMibWJE5w/640?wx_fmt=png)

还有一个绝杀在于品牌主打“有痕迹才有魅力”。对于F门人来说，买FREITAG就像盘核桃。

一个全新的状态很好，但是用出了自己特有的印记才有意思。

FREITAG通常有3年保修，受损可进行修复，五金在官网可以免费订购自己换。但在小八看来，如果是各种刮痕、褶皱、磨损，不会专门维修，反而自带岁月痕迹的工业质感和一股脏范儿，“就像收老物件有这种感觉，越老是越好”。

喜欢收集FREITAG的Jack则另辟蹊径地认为，本身新包包自带臭气，收二手的话，味道基本无了。

至于堪比轻奢包的价格是否是智商税，有F门信徒告诉剁主，确实用的材料并不值钱，贵的一部分主要在于原材料和加工过程中会大量排碳，而且只在瑞士造，人工费本身就高。

不过，对忠实F门信徒来说，真喜欢的话，就谈不上智商税。

![](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd5XKRkVpVVL3eMHVjGS5HhMvWKUlkUjiaia8R29ZhuicIwoKqEo9j36mgNGcN2aOfjGI2109bVTQgibWw/640?wx_fmt=png)

**Citywalk的新“社交货币”**

这段时间，F门信徒们也在疑惑，为什么大街小巷背FREITAG的人突然多了起来，就像几乎是一瞬间，年轻人喜欢上了Citywalk一样。

City walk，又叫城市漫游，是一种随性行走、感受城市风貌历史文化的旅游方式，也是今年社交网络兴起的最流行的城市运动之一。打开小红书，你会发现无论在哪个city，都有人在尽心尽力walk，不仅有大量City walk的路线分享，还有专门的组织者发布相关活动，甚至有不少网友寻找“City walk搭子”，或骑行、或城市越野跑，或者只做“街溜子”。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK06X3mW3dTUU9ZW1NqZ9uWu489u4EtZMuA63RmjHibg5bSibyX59E2eGNp2YVm19JHE2MPPHyHkoL7A/640?wx_fmt=png)

这时候，FREITAG作为一种社交货币出现了，由于圈层特点极其突出，涉及中产、亚人等各类年轻群体，同时，铁粉占比很大，看到路上有人背FREITAG，自有用户马上就会嗅到对方和自己一样的品位气息，从而产生认可。同时，他们讨论的不只有包的好用和好看，这块防油水布的前世今生，经手过的主人，都是可以聊天的谈资，社恐的年轻人在街边遇到好看的FREITAG，也可以选择发在社交平台上，寻求原玩家互换。

同时，City walk的风也不可避免地蔓延到 FREITAG 粉丝群里，切中的第一个场景就是骑行。

这刚好和Freitag“骑行友好”的品牌理念契合。Freitag 兄弟俩创立 Freitag 的最初动机就是从他们骑行的日常考虑，想要一只适合在多雨的苏黎世骑行时也能安心使用的包。F14、停产的F17都是骑行场景中最常见的系列。

“小布加上FREITAG背包，在巨鹿路、长乐路、富民路上拿一杯咖啡已经成为小红书上扫街Look必备了”。Jack感叹。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK06X3mW3dTUU9ZW1NqZ9uWuGB7NwRInf9ZGWJ7t6xSsUpVV9PsSrJ6N9MYbkEtErTibCvdeNKnh9Vw/640?wx_fmt=png)

小红书的优势在于多层内容生态叠加，每天有无数原生需求反馈及潮流方式的倡导，可以挖掘具有潜力的潮流风向,比如#多巴胺穿搭##City walk#，与之圈层相契合的F门人通过内容分享，便能构建出有趣体验的场域价值。

同样潮流体验也发生在具有“交换购买”和“内容社区”心智的闲鱼，因为强社交、强圈子属性，才触发了Jack等F门人闲置买卖的新思路。

而在线下，从2018 年在上海开第一家门店开始到现在，FREITAG 已经渗入到国内各城市的潮流据点。

有别于传统的箱包零售商，FREITAG选择的入驻的线下门店是更多的是美术馆、骑行生活品牌店、生活方式体验馆、艺术区、买手制时尚概念、书店等。在线上、线下，FREITAG会举行各种城市历史、文化的探讨活动，去关注城市发展进程，思考个体与社会的连接和价值，用积极的态度去构建和参与城市可能性，这些“种子用户”大部分来自于创意、媒体、潮流以及文化产业。

在FREITAG内部，并不会以年龄、职业、消费层次去做划分用 YCU（Young Conscious Urbanites）来形容消费者，即有意识的年轻城市人。

今年3月，FREITAG在上海开了首家直营店，试图打造出了一个城市文化潮流标地，其项目的负责人 Oliver Fischhaber 曾提到，这里就像一个公园一样，并不只属于 FREITAG，而是周边生活的居民，你随时可以到这里锻炼、午餐，或是和朋友一起来散散步。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK06X3mW3dTUU9ZW1NqZ9uWu9H6YJicvjjsQZianzxE7PW09EHHJSqhOA02sj7mtaaLTMHKNibezlWGzw/640?wx_fmt=png)

直营店还新增了F门人自主制作包包的体验，在虚拟操作上挑选自己喜欢的卡车篷布，自由裁剪，并下单购买。最终这个订单将会同步到苏黎世总部，经数周制作完成后会从苏黎世的工厂远洋寄送到用户手中。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK06X3mW3dTUU9ZW1NqZ9uWuZCr0zFmke3ibKSwXRu34EUoGcCkBic3qdPX0BhtWS4QuHfN2SiaGr75nQ/640?wx_fmt=png)

而当用户购买FREITAG 变成了一种体验，就意味着它在用户的生命中占据了一席之地。

如果把做品牌比喻成练功，那么流量、投放、转化这些营销手段其实都是“外功”，用户体验才是真正决定段位的“内功”，而现在的年轻人更希望通过碎片和细节编织自己对品牌的立体认知，对于自己的消费和精神体验有一定的要求和判断力。

因此，FREITAG的出圈不如说是和年轻人的切身感受城市新生活方式、期待“松弛感”的情绪价值恰好找到了一个共同的交集，同时，踩中了骑行、城市漫游等流行体验场景，靠着时间和“用户体验”的口碑积累，形成如今的规模和特色。

更重要的是，当FREITAG变成自带社交属性的潮流货币之后，借助闲鱼、小红书等平台，反而实现了一种另一种意义上的二手循环和流通，这何尝不是另一种可持续和共享呢。