# 保持创新，把商业属性与艺术相结合|对话tokidoki艺术总监Simone Legno

> 公众号: 娱乐资本论
> 发布时间: 2024-11-02
> 原文链接: https://mp.weixin.qq.com/s/WJ5Aw3uLSIa5FlsMwD6JIw

---

![图片](http://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd6F6Y83LIszsXQfh29diaibTrvdjPqibu60xsQU6ibS1dT8EPdb6tCiatlw2zaic62tkzcaicEmpWFcszUgg/640?wx_fmt=jpeg&from=appmsg&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)

**作者|吴晓宇**

由中国玩具迎合婴童用品协会（中国玩协）主办的CTE中国玩具展、CLE中国授权展、CKE中国婴童用品展、CPE中国幼教展于10月16-18日在上海新国际博览中心举行。娱乐资本论作为合作媒体，与多位行业大佬进行对话，探讨IP授权领域的新变化和新趋势。

“tokidoki”意为 “sometimes”，是命运发生改变的时刻。tokidoki诉说的是“希望”-每个人内心深处所隐藏的力量。它终究会给我们直面新的一天的勇气和能量，这就是“命运齿轮开始转动”的魔力。

![图片](http://mmbiz.qpic.cn/mmbiz_png/cIR5IicBJichAmr0IChmuQBSZoVdia5I3TNojmBpicbrq5ZD6ZKO1pCYRDK2GySfAN3F7BpicicVpibkVHaVsOOTbEx3Q/640?wx_fmt=png&from=appmsg&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=1)tokidoki艺术总监Simone Legno

娱乐资本论·预言家游报对话了tokidoki创始人——国际知名艺术家Simone Legno，他秉承着数十年如一日的创作理想和热情。Simone认为，CLE中国授权展规模非常大，有很多有意思的IP。对于tokidoki而言，商业属性和艺术、美术部分的结合将是未来的关键。

**以下为本次对话实录：**

**预言家游报：在本次展览中，tokidoki是否有新IP产品发布？**

**Simone：**是的，今年我们合作了许多品牌。今年展台上我们tokidoki有一些上新的服装系列，还有我们与品客薯片的联动。这些都是最新的合作，当然还有很多其他新的周边产品我们也会陆续曝光。

**预言家游报：目前，tokidoki的IP产品在市场上的表现如何？**

**Simone：**令人兴奋的是，接下来的2025年是tokidoki诞生20周年。我们正在进行许多跨界合作。我们将与华纳兄弟合作，在2025年推出tokidoki的第一部动画。我们在美术和绘画方面下了很多功夫。我们还与一些政府协会与机构合作，比如与意大利政府以及与梵蒂冈的合作，意大利是我的故乡。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)tokidoki X Bobbi Brown梦幻独角兽限定系列

**预言家游报：今年，tokidoki计划着重拓展哪些品类的合作产品？**

**Simone：**在服装和零售之外，我们想扩展鞋类和珠宝业务。tokidoki过去有许多与知名国际品牌合作的经历。所以我们会把合作目光更多的放在珠宝以及鞋类上。

**预言家游报：您觉得今年IP授权领域有没有什么新变化和新趋势？**

**Simone：**我非常喜欢这次展会，我认为它的规模非常大。我参加过拉斯维加斯、伦敦、东京和香港的展会。就规模而言，这次是最大的一次。这很有趣，因为有很多来自西方的经典品牌，但即使是我有很多也是第一次了解。我看到了许多在中国市场上非常强大的品牌，一般在国外都找不到的。对我来说，来到这里并了解中国市场正在发生的事情让我非常好奇。有很多非常酷的作品，非常有意思的角色和游戏。

**预言家游报：面对不断变化的市场环境，tokidoki采取了哪些策略来充分发掘并提升IP的价值，以满足粉丝日益多元化的需求，并加强与消费者的互动交流？**

**Simone：**我对tokidoki的成长感到非常高兴。我们在不断改善我们的IP，对此我也非常开心。我认为tokidoki的关键在于我们始终保持创新，始终保持新思路以及新角色，在此基础上，我们也一如既往的注重IP收藏属性。同时，凭借20年的经验，我们学到了很多关于市场的知识，了解哪些角色更适合授权。我认为tokidoki的商业属性和艺术、美术部分的结合将是未来的关键。

**预言家游报：请分享一下您对IP授权市场未来趋势的看法或预测。**

**Simone：**正如我所提到的，2025年蛇年将是非常特别的一年，许多与“蛇”相关的IP有更为契合的合作内容，比如拳头游戏或哥斯拉。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)tokidoki X Bobbi Brown梦幻独角兽限定系列

但是2026年将是马年,众所周知独角兽是tokidoki的主角，也是一群平凡小马穿越魔法森林而变成独角兽的故事。所以我认为tokidoki的独角兽会有很多IP推广的机会。

**推荐阅读**

[![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247652305&idx=1&sn=2b249c5043dc5e7a359dcd3a97fb2690&chksm=c057860af7200f1c47f422eb01ee292399232eefea319f1b81e732cfb6b5611e3a02910eaa0f&scene=21#wechat_redirect)

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)
