# 击垮打工人？AIGC开启乱纪元

> 公众号: 娱乐资本论
> 发布时间: ref: <Node>
> 原文链接: https://mp.weixin.qq.com/s/jzMsSTDiotzp2PdTpYSu1A

---

![图片](http://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd63autpgFdRMskmUZqicr9PkkPalh8zZTSO6g6VGcibkQ5Bv23QBEgW65QpyZj2OaT8qvYMEiaJUZDDw/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)

**作者 | 不空**

         

AIGC已经从一场大厂之间厮杀夺位的军备竞赛，演变为关乎每一位普通打工人“生死存亡”的“HC革命”（Head Count）。

         

国内头部公关及广告服务商蓝色光标打响了使用科技力量优化人员配置的第一枪，利用AIGC技术叫停了创意内容外包。AI带来的替代性危机甚至已经蔓延至电商服装模特中。时尚服装品牌李维斯宣称今年将会在电商渠道尝试AI模特。

                   ![图片](http://mmbiz.qpic.cn/mmbiz_png/HKEDX7MqXK2miayuEpuvT0R1KfcqG9QiaTib4J8wKicz0cADB1agkhTEx0zhFoicFuckPVjHibsib5KuhPbxXHfM3NDjQ/640?wx_fmt=png&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=1)

在这场科技变革中，打工人始终处于漩涡中心。

         

一方面，AI学习变成了一个自上而下的指令，由领导层快速反应，推动AI工具在工作流中的普及。在大厂做内容运营的安安透露，部门周会新增了AIGC工具分享的环节。而在一家中小规模设计公司做视觉设计工作的大福也表示，公司购买了Midjourney的年费会员，要求设计师将AI工具运用到工作流中。

         

另一方面，沸腾的风口最容易滋生焦虑，狂热的AI学习热潮正在印证着这一结论。大厂员工晓瑾就认为，身边的同事虽然宣称对AI不感兴趣，但AIGC的线下沙龙却异常火爆。

与此同时，剁主还发现，尽管国内已经出现了“百模之战”的局面，大厂竞相推出自研大语言模型。但是，员工在实践中更倾向于选择ChatGPT、Midjourney等工具。

AIGC技术正在从生产力迭代下沉为生产关系变革，打工人也面临着一场转折危机。

         

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**“将AIGC上升为公司策略”**

         

“AIGC是近一个多月以来部门会上出现频率最多的词，从如何转型到落地应用，每一位领导对待AIGC的热情都很高。”

         

进入到2023年后，国内的AIGC领域迎来了快速迭代的常态化发展期。继百度之后，阿里、昆仑万维、商汤等实战派也在四月份相继推出自研大语言模型，迈向AGI黄金时代。与此同时，王小川、王慧文为代表的上一代互联网创业大佬也亲自领兵，躬身入局，以全力以赴的姿态再造事业的“第二春”。

         

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

图源：文心一言官网

可以肯定的是，AIGC引领的这场科技巨变势必会开启互联网领域的全新对抗赛，而这场战役压力也会落到每一位打工人的身上。

         

在技术洪流之下，打工人只能或主动、或被动地加入其中。安安称，在ChatGPT在国内热度正火时，部门直属领导就曾“建议每个人都积极尝试ChatGPT等大语言模型，并且探索与自身工作相结合的方式。”自此之后，部门便新增了一项周会流程，即在各项工作汇报结束后，部门人员需要轮流分享AI工具的使用经验和心得体会。

         

当AIGC化身成为一项工作指标，AI焦虑也找到了快速传导的路径。“原本并没有AI焦虑情绪的同事在部门氛围的感染之下，也开始有了焦虑的情绪，担心自己的岗位在某一天会被AI优化。”

         

结合自身的使用经验，安安认为，ChatGPT为代表的大模型工具确实能够提升工作效率，“花费在信息搜集、寻找灵感等基础性工作的时间被大大压缩。”最重要的是，大模型惊人的迭代速度也蕴含着无限颠覆的可能性。

         

不过，在安安看来，提效的另一面绑定的则是降本二字。“提升效率之后，必定要裁掉基础性岗位，这才是将AI引入到工作流中的真正目的。”可见，AIGC的引入也是对工作岗位的重新分配。

         

“未来，基础性岗位应该会被AI替代。但是，能够在AI冲击之下留下来人，不仅拥有格外出众的工作能力，肯定还需要灵活运用AI工具，将其赋能到工作流程中。”

         

除了大厂之外，中小厂的员工同样在这次的AIGC技术冲击中如履薄冰。

         

在一家中小规模设计公司做视觉设计工作的大福透露，“老板开会时直接将AIGC上升到公司战略的高度。同时，公司购买了Midjourney的年费会员，要求每个人都使用Midjourney这类AI工具来完成分镜这类工作。”

         

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

图源：Midjourney官网

         

公司战略的转变自然也起到了降本增效的作用。大福介绍，AI工具确实能够提升前期效率。不过，自去年起，公司就开始通过裁员来降低成本，截至目前，员工人数已经减少了40%。

         

大福还发现，设计岗位的招聘明显减少，平均薪资水位也有所下降。“之前大厂对视觉设计的要求高，需求也多，但是现在市场上整体的设计岗位数量已经大大减少了。同时，由于多数公司普遍认为设计岗位的可替代性很强，薪资水平自然也就下降了。”

         

设计岗位与技术的融合也在市场需求上有所体现，已经有公司开始将设计岗位调整为AIGC产品设计师，招聘要求中也明确规定需要具备AIGC素材生产能力建设。

         

“总之，市场肯定是会越来越卷的。”大福如此总结道。一场可预见的冲击已经悄然掀开了巨变篇章的序幕。

         

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**“人人都说对AI不感兴趣，**

**但抢票却非常积极”**

         

在大厂高管笃定了AIGC光明前景并且狂热ALL IN的同时，AI技术不断开发的可替代性潜力正在倒逼每一位打工人为了自身来之不易的工位而奋起努力。

         

最优选择自然是进行系统性地AI学习和实操练习。值得注意的是，在AI学习热潮之下，AI课程在近期也成为知识付费领域的热点。

         

以知识性博主Caoz为例，4月11号他在知识星球发布了一门名为“ChatGPT&AI赋能商业”的学习课程，价格为799元，仅仅一个晚上，这门课程就吸引了近四千五百名成员订阅。除了Caoz自身的影响力之外，自然也离不开大众层面对AI的学习热情。

         

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

4月12日Caoz的知识星球页面

         

同样在抖音直播间中引爆AI学习热潮的@张诗童商道以创作文案、优化PPT等内容直击打工人的痛点，吸引了不少用户的关注。

         

除了自驱力带动的学习热潮之外，一些公司，尤其是科技大厂更是为员工推荐和安排了一系列AI课程，以供员工进行自主学习。

         

就职于国内某大厂的晓瑾介绍，她所属公司使用的工作软件日常都会推送学习内容，在AIGC的热潮来临之后，每日推送的内容都以AIGC为主，其内容的涵盖范围也十分广泛。“不仅有大语言模型相关的基础知识，比如技术优化、案例分享等内容，还有高管和专家的内部分享和体会。”

         

与此同时，公司设立的学习课堂还上线了大量AIGC直播课程，从AIGC相关工具的上手到练习都可以为员工提供全程指导，课程在普适性之外也兼顾针对性，以实际工作为导向建立员工对AI工具的认知。

         

在线上课程之外，晓瑾称，公司还组织了AIGC相关内容的线下沙龙，允许员工在线下自由交流。线下沙龙的主题更偏实操向，诸如利用AI优化文案、AI绘画工具快速生成海报等更具实践意义的内容。

         

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

夜晚，本图为AI作图，创意by娱乐资本论

不过，由于是线下活动，不免会受到场地等多方因素的印象，因此该活动就设立了人数限制，需要内部员工进行线上预约，提前预定名额和门票。不过，据晓瑾透露，这类线下沙龙广受员工欢迎，每次活动的名额都很难抢到。

         

“人人都说不感兴趣，但是每次抢票却非常积极。”晓瑾的这句话恰恰点出了当前打工人在这场技术变革中的急切心理，从小浸染着“赢在起跑线”理论的打工人，自然也不希望在这次科技浪潮中落于人后。

         

为了鼓励员工使用AI工具的积极性和热情，安安公司还举办了一系列AIGC的比赛，比如AI绘画、AI生成动画视频等比赛。“基本每隔一段时间，公司就会发起这类全员活动，优胜者不仅会在公司内部展示作品，还设置了奖金和额外的礼品，力度还算是比较大的。”

         

公司层面主导的这场自上而下的AI教育进一步强化了打工人学习AI工具的决心和动力，也顺利重塑了大众对AI的认知，成为互联网科技公司成功转型的根基所在。

         

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**硬性要求VS抵触情绪，打工人面临“大考”**

         

当AIGC已经成为确定性方向，那么，顺势而为、因势利导就成为了打工人的生存法则。

与其被动焦虑，不如主动学习。最大程度释放AI的工具属性，借其提升自身工作效率，优化工作分配才是当下最应该把握的机会。

事实上，AIGC在技术上的无限延展力已经打通了多条创意内容的生产路径。

在图文内容生产方面，以ChatGPT为代表的辅助工具能够在信息整合、灵感提示等前期工作流程方面进行优化。

落实到方案设计前期准备工作上，安安结合节日内容策划方案的应用案例予以阐释。“这类策划方案在操作之前往往只有大方向，但却没有明确的主题。比如，植树节内容策划只是一个大方向，而保护植被、关爱地球就可以被认定为具体的主题。”

在确定主题前，安安会借助AI工具以关键词为核心进行信息搜索，“这样能够在最短的时间里掌握更多的信息量，为方案撰写提供思路和背景信息。”从工作效率来看，安安认为，有了AI工具的帮助，至少能够帮助她压缩百分之七十的准备工作。

         

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

图源：通义千问官网

同时，在方案设计阶段，安安还会以提问、假设条件等强逻辑性的方式寻找灵感。“AI工具的学习能力很强，但前提是需要帮助AI理解题意，也就是说需要我们对AI解释背景信息。”

在视觉设计方面，大福肯定了AI工具在生成素材、辅助拍摄等方面的表现能力。

         

在实际的设计工作中，尤其是商品氛围图、品牌设计图等具有传播属性的图片和海报往往需要大量匹配的素材图，这是设计行业中的常识之一。“不仅需要与产品相契合的辅助元素，还可能会涉及到空景等一些背景图。”

         

大福进一步解释道，“对于设计师而言，这其实是工作流程中非常耗费时间精力的一个步骤。如果完全依赖人工的话，这些素材图不仅需要设计、搭建、拍摄，对于商业设计而言，时间和成本并不小。”

         

而AI工具可以根据提示关键词进行精准设计，能够节省时间和成本，提高生产效率。“这些步骤的优化意味着，我拥有更多的时间投入到精细化设计中。”

         

不过，在AIGC工具重塑工作流程的另一面，AIGC的发展和普及也不可避免地对人类自身的存在价值和意义发起了冲击，出现了AI技术与社会发展相互推进却又彼此对立的情景。

         

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

图源：Midjourney官网

         

比如，AI绘画一方面确实处于蓬勃发展阶段，重塑了产业发展活力。但是，在另一方面，设计师和原画师对于AI绘画的抵触声音从未减弱，“缝合怪”、“尸块拼接”等叙事话语中也隐藏着人类对自身不可替代性价值的捍卫。大福坦言，直至现在，她依然坚定认为AI绘画工具存在着版权问题。

         

但是，AIGC技术已经在工作流中先发制人，成为了不可逆转的风向。迷茫的打工人在抵抗情绪与硬性要求之间几番挣扎，如何化解这番分裂情绪正是对打工人适应能力的一次“大考”。

**话题互动：**

**你的岗位受到AIGC冲击了吗？**

**推荐阅读**

[![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247578126&idx=1&sn=d8f0409c4f95362fe8d86a13f0a7310a&chksm=c058a7d5f72f2ec33a2f2bd98529b3247d434b8bfd4485f19358df3aedb6ac523c5691e00313&scene=21#wechat_redirect)

[![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247577773&idx=1&sn=1003bd8da237d3a8677ccab8576c61b1&chksm=c058a576f72f2c600ef49ff118f479e41f7bd167e350cd5f18ee2da0eb9248fa299f7b036cca&scene=21#wechat_redirect)

**选秀节目消亡后，秀人和公司如何求生？**

**点击观看**

**↓↓↓**

**如需商务合作后台回复【商务】**

**如有转载需求后台回复【转载】**

**更多文娱产业背后的经济逻辑，来关注↓↓↓**