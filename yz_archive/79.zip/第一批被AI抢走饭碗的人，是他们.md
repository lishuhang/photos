# 第一批被AI抢走饭碗的人，是他们

> 公众号: 娱乐资本论
> 发布时间: ref: <Node>
> 原文链接: https://mp.weixin.qq.com/s/L-69nzVAnZHomVOXTRSayQ

---

![图片](http://mmbiz.qpic.cn/mmbiz_png/jNZszpkibXx9fK5DxyTD7AyeFpFRtOjibtXBxHxv9ibzVMWibiaric81WOFUJLW0R1iabhKNBDSeVExetG9DF1zviaEjew/640?wx_fmt=png&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)

**作者 | 宋佳旻 王雨娟 李莹 辛晓彤 叶徐彤**

**编辑｜余乐**

ChatGPT横空出世才几个月，多个行业已经切实感到了来自AI的冲击。

社交媒体上，打工人们纷纷担心自己被裁员。传言中受AI冲击最大的包括游戏美术、插画、文案、服装设计等行业。

**我们经过访谈发现，游戏、设计等行业的原画师这个工种受到的冲击最快、最大，已经出现了裁员现象。**广州一家中型外包游戏公司的特效技术总监丹青称，公司原画团队2023年初使用AI之后，已经裁员2/3。

还有很多人在考虑转行，原画师小毛转型成为美妆博主，学习动画的大四学生龙三丰则考虑毕业后去当教师。

更多行业暂时还没有受到裁员的直接冲击，但是已经开始运用AI工作。从业十多年的手游项目主策划张立东表示，AI已经能辅助广告公司的前期工作，节省了很多成本。

很多受访对象告诉我们，**用AI帮助自己工作也并不是那么容易的事。今后，自身水平过硬，又善于使用AI的“复合型人才”将会更受企业的欢迎。**

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**原画师已开始被裁**

在丹青所在的公司，原画团队自从2023年初引入国外的一款付费AI软件后，工作效率提升了3倍。借助AI，打草稿的步骤节省下来，原画师只需完成后期细节修改，“相当于节约了50%的工作量。”之前15个人的工作量，现在5个人可以完成。

于是，公司开始分批裁人：每次裁三四个，一共裁了22位，团队人数缩水2/3。**公司明确告知员工，裁他们就是因为有了AI。**

裁员后，公司每个月能省下20万元人力成本，“现在还只是初级阶段，以后有成熟的制作链就会节省更多成本。”丹青说。有了AI后，公司的订单虽然没有增加，但利润率明显提升。

**不过，丹青所在的公司裁的都是初级和中级原画师——他们的工作已经可以被AI完全取代。技术更好的资深原画师则无人被裁。**

丹青解释说，资深原画师的核心竞争力在于通过后期调整，来满足甲方的细化需求。“这是AI还没有办法完成的，还需要很长时间的迭代才有可能实现。”

从事服装设计的悦悦就发现，公司放弃了一个各方面都很合适，只是不会用AI的原画师，并招来三个会用AI做图的画师之后，反而出现了一些新的问题。

首先，团队的整体效率并未因AI而提升太多。**使用AI辅助绘画后，前期工作加速了，能省下1/5的时间，但是由于这几位“AI画师”本身水平一般，又要花很多时间去做后期修改。**

另一个问题是，用AI可能会被客户发现。

**为了维持订单价格，乙方通常不会主动告知甲方自己使用AI作图。**但是，自从悦悦的公司用上AI以后，甲方经常发现画稿中有“非人类所能造成”的细节错误，进而发现悦悦的公司使用AI，要求降价。双方开了好几次会也没谈拢价格。

后来，公司把三个AI画师辞退到只剩一个，并要求他优化流程。公司也不招新人了，只敢招一些技术很熟练的老员工。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**AI很难完全取代人**

目前，更多行业和工种里，AI暂时还构不成对人的威胁。

在乙方美术团队内部，原画之外的岗位受AI影响并不大。**丹青表示，目前AI还没有波及动作、模型和特效这三个团队。**

特效资源库是每个公司的独立资产，在市面上不流通，而AI需要大量资源库喂养。因此，特效行业在很长的一段时间内都不会受到AI冲击。

**游戏领域的甲方公司也不太会受到影响。**腾讯某头部游戏工作室的一位策划人员表示，像他们这种稳定上线的项目，整体情况还不错，所以基本没有出现裁员的情况，更毋论因为AI的应用而裁员。

游戏制作人张立东表示，现在AI工具所产出的内容，还无法完全满足作品产出的需要。**在游戏开发中，需要把人物角色、道具等在Photoshop（专业修图软件）中分层处理，但AI交出来的内容，是单一的图层，所以应用局限很大。**

Stable Diffusion和Midjourney是目前常用的两款AI绘图工具。张立东认为，Midjourney是傻瓜式操作，适合普通人；Stable Diffusion则更适合用于游戏行业的图像生产，且功能和可拓展性每天都在进步。但是，要想让它成为彻底的生产工具，“现在还非常困难”。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)Stable Diffusion页面 图片来自网络

**不仅如此，用AI并不是一件容易的事情。包括GhatGPT、Midjourney等在内的一系列AI工具，都有比较大的使用门槛。**“能好好使用AI工具（对人员的要求），可能比某些小公司的用人需求还要高。”

最初使用AI绘画工具时，很多人会讶异于自己通过简单的操作就能获得一张高质量的图，**可一旦需求越来越细，难度就会指数级提升，“给AI提需求是一件非常困难，或者说非常有技术性的事情。”**

从现有的AI工具及人员水平来看，应用到工作中肯定是会付出比较大的经济代价。“大家需要很多培训学习及试错的成本。”张立东表示。AI画图工具本身是个以算法为基础的大模型，如果想要大规模应用在实际工作中，还需要团队不断编写插件。

在绘图之外，游戏行业的文案工作也没有被AI取代。在某游戏大厂担任文案策划的小鲨表示，公司已经开始研究AI，但她身边也并没有人因此被裁员，**“商业写作涉及的内容很复杂，而且游戏文案不是纯写作，涉及策划内容和多部门的配合，这些AI都实现不了。”**

张立东告诉我们，AI在文案工作上确实有超高的效率，但它的成文容易被分辨出来。“一般实际工作中所需要的文本，都是特定的，针对某个主题，需要有比较深入或者新颖的观点，目前AI还不太容易做到。”

**很多情况下，AI或许可以拿出99％近似对的答案，但也可能会出错，只是它没办法自己检查，永远不知道自己是错的。**从这个方面来看，人永远不会被完全取代。“低级的工种可能会被取代，但每一个新技术出来的时候大概都是这样。”张立东说到。

**很多公司考虑到版权风险，不会将ChatGPT投入使用。**“公司目前还不会将ChatGPT作为辅助编程的工具。”某科技大厂的高级工程师程建也说。一方面，这是因为公司有信息安全、商业机密的规定，不会将软件需求上传至ChatGPT的网络，另一方面，大公司的代码要查重，不能直接引用外部代码片段，如果直接拷贝ChatGPT的生成结果，会存在版权风险。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**更多行业，AI放大人的能力**

“AI取代人不是一件特别容易的事情，但是利用AI工具进行效率提升是很容易的，现在就能实现了。”张立东认为。

**包括大厂在内的很多公司已经开始运用AI工作，放大人的能力。**

以他刚刚为之做过Stable diffusion使用培训的广告公司为例，该公司已经有意识地将Midjourney等AI绘图工具用在业务的前期沟通阶段，比如先用AI出几张示意图，看看哪个更靠近甲方的需求，就能在这个基础上继续向前推进。“只这一个步骤，就可以为他们节省很多时间。”

阿里一位推荐算法相关业务的主管告诉我们，近一个多月来，他们团队已经经常在工作中使用ChatGPT了，用来帮助写代码和替代搜索引擎的功能。

上述腾讯某头部游戏工作室的策划人也提到，AI的应用会有助于策划或者运营岗的同事更好地跟美术团队进行沟通。“有些需求，语音或者文字可能表达不准确，但是现在就可以用Midjournry，先跑一批符合自己需求的参考图，然后再去跟美术或者UI（界面设计）同事沟通。”

只是现阶段的这种应用，更多是员工的个人行为，公司层面并未倡导。

除了离AI技术很近的游戏和互联网公司，**传统制造业也开始大范围运用AI。**

或许在普遍认知中，AI与传统制造业相隔甚远，后者的低利润运营模式撑不起前者的高成本。但是，在莆田一众制鞋厂商中间，索罗芬（Soulsfeng）的创始人黄逢春就将AI带进了传统制鞋业。

索罗芬对AI的应用**主要在设计和广告环节**。设计领域，索罗芬借助Stable Diffusion这个模型从文本生成图像。黄逢春表示，从前至少需要五名设计人员完成的工作，现在只需一名设计师。随着AI的不断“学习”，它对指令的理解和风格的把握也更加纯熟。

如果说产品设计仍需设计师把控风格，那广告营销对AI的倚仗就更多了。黄逢春举了个例子：**老板不可能要求一个员工做1000条广告，并控制所有广告的投放渠道、产出效率等，但AI可以，**只要设置好投入产出比等几个关键数据即可，AI可以做出几千甚至上万条广告，并分发在合适的渠道。“换做人力，至少也得是几十个人的团队共同协作。”

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**打工人的焦虑和转变**

在AI投入应用后，不少打工人陷入焦虑，开始考虑转行，尤其是在原画师这样最先受到冲击的领域。

**“AI带来的是精神上的打压，让中低层画师产生自我怀疑。”**有四年从业经历的插画师M君说。

之前，M君每个月能画四张图，这个月只画了两张，大部分时间都在焦虑和尝试AI中度过。当她看到自己用AI生出来的图很粗糙，不能用的时候，就可以安心地去画画；但是，在社交平台上看到别人用AI生出非常精美的图后，她就又开始焦虑。

插画博主龙三丰认为，AI对画师的冲击就像方便面对餐饮行业的冲击一样，有人会选择就此吃快餐、走捷径，但她还是会踏踏实实烹饪、练习技术。但是，她在看到关于裁员的讨论时也无可避免地“感到很慌张。”

北京某科技公司程序员小杨发现，很多使用过ChatGPT的前端程序员也都开始慌了：“感觉技术升级后，本来10个人做的工作，现在一个人加ChatGPT就能做。”

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)小杨用Chat GPT解决一些工作问题 受访者供图

**小毛是一名工作两年多的原画师，她认为AI会让打工人更加辛苦。**“在游戏公司工作本身就很累，每天我要上11个半小时班，AI出现又会进一步加剧行业内卷。”

在精神内耗过后，很多人开始谋求转型。丹青称，**特效行业之前人才没有那么饱和，但是因为AI的使用，很多人开始从原画等行业涌入特效行业。**他近一个星期收到的简历，有1/5是从原画行业转来的。

龙三丰考了教师资格证，“如果无法找到心仪的美术工作，我还能去当教师。”

去年底被公司劝退后，小毛决定彻底离开游戏行业，做起了自由感更强的美妆博主。

但对于有些人来说，AI带来的焦虑不过是九牛一毛。小杨告诉我们，**35岁门槛、互联网行业不景气、疯狂内卷等重重焦虑包围着底层程序员，“很少有人在意再加一点ChatGPT带来的焦虑。”**

**M君也选择留在插画行业，发挥人的创作在情感上的优势。**她使用Stable Diffusion工具，把自己的半成品喂给AI，发现AI没有她自己画的脸有情绪和特色。“虽然我画得不完美，能看出笨拙的痕迹，但我感觉我自己画出的更有情感。”

一家自动驾驶公司的程序员李立也对AI持积极态度。李立认为，对于程序员来说，如何看待AI的影响取决于对自身工作价值的定位。如果程序员认为自己吃的是资源，那ChatGPT毫无疑问威胁了他们的技术资源；如果程序员认为自己的价值来自服务，来自提高效率带来的利润。那ChatGPT作为一个帮助程序员提效的工具，应该受到欢迎。

**“一个好的技术不应该是让人失业的技术，而是解放人的技术。”**

（应受访者要求，悦悦、丹青、龙三丰、程建、李立、张立东均为化名）