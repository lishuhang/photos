# AIGC侵入文化产业，焦虑与机遇齐飞

> 公众号: 娱乐资本论
> 发布时间: ref: <Node>
> 原文链接: https://mp.weixin.qq.com/s/-Thz4KvTZFXTUWsrJec5GA

---

![图片](http://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd79GxfvK4JTesr9HF21lJPOoAqHkSflFbLKYoUmJ7R1xps0dVckb3EKskn4zYkBmvM3Z1ACsnj5gg/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)**作者|满天**

短短三个月时间里，一个词来形容文化行业，或许AI带来的“眩晕感”是最佳的注释。

AIGC、ChatGPT、GPT-4、Midjourney、NewBing、Bard、Copilot 、Firefly.......这一个个的新技术新工具不断蹦到人们眼前，形成了真正的知识轰炸。怪不得连比尔·盖茨都出面，将OpenAI所带来的人工智能革命性创新与他第一次接触图形用户界面相提并论，甚至两年翻一番的摩尔定律也第一次面临真正意义上的失效风险。

那么，中国的文化产业要如何面对如此汹涌的AI大潮呢？

预言家游报最近走访了多位影视行业以及游戏行业的从业者，不少人在这半年时间里都在研究生成式AI技术，很多人也不免陷入了AI焦虑。

像陆川、陈洪伟这样的影视人，都在用力地培养新人运用AI，陆川更是喊出了“AI用15秒生成的海报，比专业公司一个月做得还好。”甚至有项目组省了几十万的成本。                                                                         ![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

（使用智能绘图软件midjourney辅助生成电影《霞光路》概念气氛图）

像腾讯和互影科技等提前准备，已在业务中布局了可以高效利用AI技术的岗位和工作流程，除了行业已知的砍美术外包团队，互影更是利用ChatGPT等技术来辅助制作全新互动叙事项目。

像淘宝店主Andy和某MCN机构，则已经布局产品AI效果图和批量化网红上装工作流，轻松将外部摄影工作室数人的工作提炼到了一个人来负责。艺术家和大学教授赵伯祚也已经利用AI创作了数幅广告作品。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

（示意图）

也有公司还在研究GPT-4新的落地化方向，为员工集体找外部培训和内部交流机会，也为下一款作品积蓄力量。

不过，文化产业的从业者们都有一个共识：新的深度学习AI浪潮不像元宇宙，也不像Web 3.0，热潮之后就会销声匿迹，而是成为未来10年甚至20年深刻改变人类的新一次产业革命。[【泛内容领域，最大的一次入局机会，欢迎来戳】](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247575387&idx=1&sn=8efba9141704cb0cef6a1f50dab08132&chksm=c058b280f72f3b96710bb715ff1742b200c326af294c1a6fec04eee7b12781b6546e39f9d97f&scene=21#wechat_redirect)

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)**焦虑**

面对AI大潮，焦虑几乎是大部分从业者的情绪注脚。

游戏大厂工作的拍拍去年就开始研究AI。GPT-3.5率先落地的就是绘图领域，美术工种的拍拍几乎不可能不焦虑。

“原来我是不懂技术这块，但是AI能做的事情实在是太多了，一出来所有人都看傻了。公司很多生产环节迅速接入AI，所以没办法，只能不停地学，硬着头皮也要学，”拍拍向预言家感叹。

拍拍当然担心自己的工作被AI取代。这几年拍拍没有离开原来的公司，做着最基础的美术工作，就是希望能够借助自己的力量帮助看好的游戏早日上线。GPT-3.5落地化之后，拍拍发现AI能够自动生成一套还不错的UI设计，自动渲染更是不在话下，惊叹的同时焦虑在所难免。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

（AI根据提示词生成的UI界面）

从去年学到现在，拍拍使用Stable Diffusion以及后面的Midjourney越来越熟练，出图的速度和效果也远超她的预期。逐渐地，拍拍即将和AI达成和解。此时，更强悍的GPT-4语言模型来临，拍拍的AI焦虑重新浮现。

同样是身处游戏行业，做着公关工作的JoJo就没有工作被取代的焦虑。

JoJo告诉预言家 ，他曾经尝试利用ChatGPT帮助自己生成一篇公关稿件，且尝试了诸多prompt技巧。文章是通顺的，结构上也符合一般公关文的体例。但ChatGPT的长期记忆能力仍很一般，因此技术上缺乏对公司业务、文化等上下文全面的理解力，对于不同行业、不同时期受众的情绪和认知，也缺少捕捉能力。

所以，ChatGPT写出来的东西自然是四平八稳，但文本尚无法激发与受众的深层次沟通、共情和引导。即便通过prompt令所产生的公关文本，可以实现看似相对白话和个性化的风格，但所传递的气质也过于“板正”。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

（图片来自于小红书账号@Selina靓靓）

“公关文的最终意义不是文字本身，甚至有时也不是信息本身。而是基于事实，展现关于公司和产品的能力、气质、价值观和共情力。ChatGPT在这方面还有相对长的路要走，当然我也很希望看到它在未来，能展现这方面的能力。”JoJo说。

由于尚未接入整体工作流，因此即便有了AIGC技术，JoJo的公司也还没有裁撤初级的原画师，不过一些外包成本被节省了下来。

然而，学习AI技术的紧迫感还是伴随着JoJo。

AI绘图刚刚开始发酵的时候，落地的产品还不多。JoJo每款产品都能赶在第一批进行尝鲜，测试之后他还愿意在朋友圈分享他使用的心得体会。

从ChatGPT开始，AI技术和产品的迭代开始加快。直到近期，人们短时间内就见证了英伟达为AI量身打造的GPU推理平台、Google Bard、Microsoft Loop、Runway Gen 2、Github Copilot+以及Adobe的萤火虫纷纷发布。JoJo告诉预言家 ，这是他第一次感受到具体的AI工具实现爆发式增长，有一种“玩不过来”的感觉。

互影科技的Gary是一个企业管理者，他所经营的公司以互动内容开发和云互动技术研发为主业，其中一条业务线是互动影视。也就是说，互影科技的生产流程中既包含了影视制作、游戏设计环节，又包括了技术研发环节，应用AI技术的需求自然更加迫切。

去年下半年的时候，Gary就已经通过互影的首席科学家，也是清华人机交互博士了解到GPT-4开始进行测试。所以深度学习的AI技术在今天实现井喷，Gary和团队有幸成为了最早一批受益者。

与此同时，Gary也没有被AI浪潮所困扰。在他看来，使用生成式AI工具最好的人需要具备一项重要的能力，那就是通过提出正确问题的方式来取得最终想要的结果。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

（图片来自于微博@五蕴幻身所做的Firefly测试）

Gary认为：“一名CEO或者管理者，最擅长的事情应该就是问问题。在这种情境下，AI可以被看作一名考虑周全且让人愉悦的同事。人和AI之间不断训练、学习和对话，寻找你想要的答案，其实是非常有趣的。这种新奇和有趣，可以掩盖主要的焦虑。”

同样拥抱AI大潮的还有艺术家和台北实践大学教授赵伯祚，他现在已经训练了10个不同的Chat-GPT模型，每一个都能帮助他干不同的事情。搜集论文资料、撰写剧本、产出商业照片，赵伯祚的工作早已离不开AIGC技术，焦虑自然是不存在的。

当然，如果想像陈洪伟、赵伯祚这样玩赚AI，也可以现场向他们请教学习，并在0基础的情况下提供账号并被手把手指导。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)**落地**

比焦虑蔓延更快的，是AI技术的落地速度。

成都某游戏公司的程序贝尔告诉预言家 ，上个月开始，公司很多项目开始全面应用AIGC，现在已经能生成大型复杂素材并且直接应用，节省了巨量互相沟通的时间精力。

JoJo所在的公司也是如此。2月份美术中台的负责人就带着其他同事一起利用Stable Diffusion制作素材。他们尝试把原创IP的图片素材喂给Lora插件。只需要二三十张，AI就能生成大量效果不错的图片。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

（图片来自于公众号全民熊猫计划，右图是利用左图卡面生成制作）

这些测试的图片素材展现了初步的量产可能性，无论是用于icon或者平面素材稿。不过JoJo认为，至少以当前AIGC相关工具的能力和便利程度，处于“把玩以上，量产未满”的状态。同时，作为游戏公司，也要充分考虑玩家对于AIGC产出内容的接受度。

像腾讯这样的游戏大厂则更进一步，技术上实现了虚拟城市的快速构建，提升了游戏开发效率。

本周召开的GDC2023上，腾讯正式发布了3D游戏场景自动生成解决方案。游戏开发者借助AIGC的能力，搭建一座 3D 虚拟城市的时间被大大缩短。过往这些虚拟城市消耗的时间需要以年为单位计算，现在只要几周时间就可以完成。城市布局、建筑外观和室内映射都可以交给AI轻松搞定。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

 （图片来自于新浪）

“就AIGC的工作流能力来说，目前我们看到了加速发展的趋势。也许今年年底到明年年初，AIGC可以在技术层面具备深度接入工作流的能力。”JoJo表示。

比起游戏，影视制作领域AIGC技术的落地速度同样不慢。

影视工业最前沿的好莱坞早已意识到AI技术已经渗透进剧本的创作之中。3月22日，好莱坞编剧公会表示，他们将允许Chat-GPT等人工智能软件运用到剧本创作中，前提是不影响编剧署名与分成。

Gary告诉预言家 ，AIGC的新技能更多能够解决人们两方面的难题：

一个是信息的归纳总结。人们向AI灌输大量的故事构想，GPT-4就能帮助创作者整理信息，对于过往的故事的框架、范本等等去做调研。

另一个则是头脑风暴层面，新的设定、美术风格探索等等强调想象力的部分，AI都能帮助创作者进行审美融合。比如中式美学和赛博朋克如何进行融合，普通创作者可能需要极长时间进行思考，AI就能进行快速试错，打破创作者的既定思维模式。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

（图片来自于小红书账号MatCha抹茶先生所做的剧情故事板）

Gary的公司正在开发一款国民级IP的互动内容。原来的计划是类似《源代码》，通过不断地循环来拼凑出一个完整的故事线。但从去年接触AIGC技术之后，团队就开始探索通过Chat-GPT等技术的辅助，生成类似漫威网剧《What if…》的内容形式，带给玩家更充分新鲜感。

剧本筹备阶段，最直接利用AI的方式就是产出分镜头故事板。原腾讯影业副总裁陈洪伟表示，他目前正在跟进的项目，分镜故事板的产出就完全交给了Midjourney。最终效果来看，Midjourney绘制的故事板不输普通的分镜师，直接帮助陈洪伟的项目省下了几十万元的成本。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

（图片来自于推特@Kris Kashtanova）

陈洪伟直言，相比过去的纯文字剧本。未来AI全面进入影视制作流程后，剧本对于画面场景的描摹将会被重视。只有把具体的生活情景提供给AI，才能输出人们想要的效果。

赵伯祚则提醒预言家，AI参与电影或电视剧剧本创作已经落地，但这不意味着非专业人士也能轻松上手。如果想要借助AI的力量创作剧本，还需要针对剧本公式和故事结构等相关知识进行充电。不具备基础知识的小白即便有了AI这个超级助理也是无济于事的。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)**未来**

展望未来，AI技术仍然有许多发展方向值得人们期待，尤其是文化产业。

外界总会产生一些担心，认为AIGC技术只是一时的风口，半年之后就会和Web 3.0、元宇宙以及NFT一样，成为“过气网红”。

不过，几乎所有和预言家交流的行业人士都一致认为，AIGC技术将会成为未来十年的风口。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

（图片来自于AVAR官网，利用AI所生成的数字服装）

在陈洪伟眼中，AIGC技术可以让Web 3.0重新焕发生机。“Web 3.0需要海量的数字资产进行填充，之前的技术基础意味着人们必须投入大量的时间进行建模工作。现在无论是虚幻引擎这样厂商推出的Human Animation技术，还是生成式AI，都让数字资产的诞生越来越快速，Web 3.0的概念不再是一句空谈，”陈洪伟说道。

除了数字资产的生产之外，AIGC技术与前沿的脑机接口技术实现融合，同样能够引发无限的遐想空间。

一直以来，很多游戏公司的规划中包含了研究脑机接口技术。近几年，三七互娱、米哈游以及盛趣等游戏公司纷纷选择与神经医学实验室和人工智能公司合作，就是要探索脑机接口技术的新方向，与虚拟现实等技术融合，进一步提升玩家的感官刺激。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

（图片来自于米哈游官网）

JoJo也认为，脑机接口实现商业化之后，AIGC技术的大爆发将使得两者不断融合，脑机接口内容的生产在AI加持下将会迎来井喷。人们可能24小时都可以零成本享受和生产娱乐内容，虽然这样的世界听起来有些魔幻。

当然，生成式AI技术的发展眼下已经引发了不小的争议。失业潮焦虑只是其中一个方面，围绕版权、虚假新闻以及技术伦理的争吵每天都在继续。

3月29日，马斯克、沃兹尼亚克以及上千名科技大佬签署了一封名为《暂停大型人工智能研究》的公开信，希望所有的人工智能实验室都能立即暂停强于GPT-4的人工智能系统训练，暂停时间为期6个月。这封联名信也表达了行业人士对于人工智能发展的担忧。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

（图片来自于yahoo）

和它的进化速度一样，人们解决AI出现的问题也很快。目前Midjourney采用的素材已经完全实现了商业化，从而规避了版权风险。虚假信息和技术伦理问题，恐怕还需要全社会共同思考。

全面拥抱AI大潮，文化产业的每一位从业者都不能逃离。AIGC就是新一轮AI大潮的最前沿。焦虑只是暂时性的，面对落地速度如此之快的技术，眼光面向未来才是文化产业人士登上时代快车道的唯一解决办法。