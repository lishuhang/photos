# 音乐演出的另一面：卖不动票、Livehouse关停、口碑下滑
> 公众号: 娱乐资本论
> 发布时间: 2023年08月08日 15:31
> 原文链接: https://mp.weixin.qq.com/s/cVMCNz_hQFiTtg7bL7_NFg
---

![](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd5XKRkVpVVL3eMHVjGS5HhMeg5rpc668WmmWricLTCiafUgPxWosYTxLGOfabn3UwsqrMp3JNtqXHGQ/640?wx_fmt=png)

**文｜阿歪**

近日，TFBOYS十周年演唱会的消息引发又一次抢票大战。自官宣以来，“TFBOYS抢票”、“TFBOYS天价黄牛票”、“黄牛已经向TFBOYS十周年演唱会下手了”等消息反复登上热搜，引发关注。

继五一假期和端午节之后，音乐演出在暑期又迎来了小高峰。光是7月至8月，全国就将有超百场演唱会、音乐节举行。不仅周杰伦、林俊杰、蔡依林等头部歌手纷纷开启巡演，同时旺盛的需求也刺激了很多消费品牌、地方政府等入局主办音乐节。

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/HKEDX7MqXK0JYnXJodXFqNGsbMwpsjKAHqxRc6hNGktJVjeIia2U1DKSwXLiaOePpibIe0TvtoGZ2BFkJH2yWpaVw/640?wx_fmt=jpeg)

但整个市场快速增长的同时，各种问题却在悄悄滋生。

**很多大型音乐演出不再一票难求，反而出现由于供给过剩而“卖不动票”、“打折出售”的情况。**有相当数量的音乐节以“天气原因”或者“不可抗力”而公告取消或者延期举办，但很多都被网友指出，实际是因为卖不动票了。比如泰山花海星空音乐节只取消一场的操作，就引发网友质疑。与最初溢价黄牛票满天飞的情形不同，如今有不少知名歌手的演唱会门票，在二级市场都出现了打折的情况，包括李荣浩、薛之谦等歌手。

此外，**作为与音乐节、演唱会等大型演出共同构建演出市场的小型演出空间，Livehouse在五一之后出现了严重的生存危机。**有一些Livehouse因生存问题关停，比如景德镇文艺复兴Livehouse于7月26日发布公告，宣布关闭。同时，也有很多独立音乐人也陆续因为“生存问题”宣布取消或者停演Livehouse。

除了演出本身的票房问题和生存问题，需要注意到的是，**今年由于演出市场的快速增长也引发了很多乱象，导致不少音乐演出虽然提高了票价，但实际体验却很差，**“溢价黄牛票”、“柱子票”、“座椅脏”、“场地差”、“音响差”等问题一次次地消耗着观众的热情，也影响着大众对音乐演出的口碑与认知。

繁荣之外，音乐演出市场正在多方面“遇冷”。

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/HKEDX7MqXK0JYnXJodXFqNGsbMwpsjKAibA6DwsxodeBjnodic68JickyibRlw4vjsFolxibXwCsoWGJRnHk7icFrHew/640?wx_fmt=jpeg)

![](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd5XKRkVpVVL3eMHVjGS5HhM96SMCp5nUGM0eX9wb6oNE6mVwhKHO97icYHNGdKnKqziaQ16151htNgw/640?wx_fmt=png)

**卖票遇冷：音乐节频繁取消/延期、演唱会门票打折**

其实从上半年开始，就已经有部分音乐节宣布取消或延期。而近期，发布停演公告的音乐节越来越多。据不完全统计，截至8月5日，已经发布延期或取消公告的音乐节近30场。光是7月，停演的音乐节就多达10场。

这些公告给出的理由大多是“天气原因”、“场地搭建”、“不可抗力”，但频繁的取消与模糊的说辞也引发了观众的质疑，很多人表示，实际就是卖不动票了。尤其是一些“天气原因”被指出并非事实，比如原定8月5至6日的泰山花海星空音乐节，公告表示“因天气原因取消8.6的演出”，有网友表示：“太假了，6号也没有恶劣天气啊”。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK0JYnXJodXFqNGsbMwpsjKAORjUmQk9icR1a6scOO2MByibsvibDrMhfPy58uzHshbj1U0q8icjCJjKNQ/640?wx_fmt=png)

与音乐节相比，演唱会虽然很少出现取消或者延期的问题，但今年也有不少演唱会也面临着卖票难的困境，其中不乏大众认知度高的歌手。比如很多人表示低价买到了李荣浩的演唱会门票，而此前供不应求的薛之谦的演唱会，如今也在二级市场打折出售。甚至有黄牛在朋友圈发文，不是热门歌手就先别办个唱了。

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/HKEDX7MqXK0JYnXJodXFqNGsbMwpsjKAoNnWOR5HmXTppuqbvQQtXKz4bfC6G5Flol3HrJufSiciah2RHKIKWQsg/640?wx_fmt=jpeg)

整体来看，今年的音乐演出市场，确实也显现出了一些疲态。

**从演出供给来看，今年的演出项目数量增长非常快，已经开始出现供给过剩的趋势。**比如被歌迷称为“特种兵式”开演的薛之谦的演唱会，据不完全统计，截至9月共官宣了47场。今年上半年，大型演唱会、音乐节演出多达506场。有业内人士表示，今年很多演出其实都是过去三年积压的项目，所以本身就比较多，而且今年演出市场的火热也吸引了多品牌主办音乐节，比如江小北、元气森林、隅田川等，进一步丰富了供给。

**从演出内容来看，今年也有不少演出出现良莠不齐、内容同质化等问题，消耗了观众的热情。**比如，有些音乐节由于由于场地拉跨、音响效果差等被差评，很多人表示“音乐节去体验一次就够了”。此外，大量的演出也导致阵容的同质化，万能青年旅店、九连真人、房东的猫、郭顶、焦迈奇等乐队和音乐人，频繁出现在各个音乐节的名单上，而且不少阵容不及预期的音乐节对观众失去了吸引力。

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/HKEDX7MqXK0JYnXJodXFqNGsbMwpsjKAV4n8smTZzQ87SRuErGcKKqp9PFlA1xukAKZwvJ5rIh5Z75zxhPaXeQ/640?wx_fmt=jpeg)

**从观众需求来看，经过上半年的报复性观演之后，很多人也会更加谨慎。**有业内人士表示，今年演出市场这么热，也是因为过去观众被积压的需求，当这些需求被释放之后，市场也会归于冷静。**而且今年整体的经济还在恢复期，大众的消费热情还未完全恢复。**由于今年音乐演出不仅票价整体有所上涨，而且很多人除了购买门票，还需要花费交通住宿等成本。因此，除了部分核心乐迷会多场观看之外，大多数观众并不会频繁观看。

**不过部分音乐演出“出票难”也与黄牛的猖獗有关，尤其是演唱会门票。**上半年市场的繁荣吸引了黄牛的注意，不少阵容比较优质的音乐节或者知名歌手的演唱会，黄牛会想办法大量锁票，但其实下半年除了部分头部歌手，观众对大多数演出的热情都开始下降。无法溢价的黄牛票，只能在二级市场上打折流通。

可以发现，多方面的原因导致了今年很多演出开始“卖不动票”，“秒售罄”不再是常态。比如一向有好口碑和好阵容的虾米音乐节，其秦皇岛站在开票后第二天，各个类型的票均有余量。李荣浩的演唱会，就有网友表示：“480的票，临期200收的”、“长沙场700多买的1280的15排”。据一位演出主办方透露，“现在很多看起来阵容不错的音乐节，其实售票都没那么好了，我们刚刚举办的这场，阵容各方面都很扎实，但是开票之后也没达到预期。”

![](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd5XKRkVpVVL3eMHVjGS5HhMvWKUlkUjiaia8R29ZhuicIwoKqEo9j36mgNGcN2aOfjGI2109bVTQgibWw/640?wx_fmt=png)

**Livehouse生存遇冷：倒在演出行业繁荣发展时**

与大型音乐演出因供给过剩等原因导致票房不佳的情况不同，**Livehouse在今年格外热闹的音乐演出市场中，反而面临着最严峻的生存危机。**作为小型现场演出空间，Livehouse一直以来都是孵化音乐人和乐队的重要基地，也是过去三年很多乐迷的“代餐”。

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/HKEDX7MqXK0JYnXJodXFqNGsbMwpsjKAVsYGLlgMkc9hVkKGq10DbygpFR7sUvyCf1BWHmbGrDCzdp0zfQkEdw/640?wx_fmt=jpeg)

今年演出市场的复苏，本让很多人看到了希望。而且五一之前，各个地方的Livehouse演出也有明显的回升，据不完全统计，今年五一之前全国Livehouse的演出场次多达千场。但从五一开始，Livehouse的演出开始降温。中国演出行业协会表示，大型项目呈现超强吸金能力的同时，二季度音乐类Livehouse场地演出和巡演已出现关注度和票房下滑。

一些Livehouse宣布关停，景德镇文艺复兴Livehouse于7月26日发布公告宣布关闭；一些独立音乐人宣布取消Livehouse，新声乐队鲸鱼马戏团宣布今年巡演之后无限期停止Livehouse巡演；一些Livehouse通过专供粉丝的专场派对来填补空白，MAO Livehouse推出了Taylor Swift’s Night粉丝派对，很多Livehouse也推出了Kpop特别专场。

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/HKEDX7MqXK0JYnXJodXFqNGsbMwpsjKA0MvQvDMKVY2vlCbCxbxFR6TagkvLgJygBEOVic7GKzsBhSqUZDk7XwQ/640?wx_fmt=jpeg)

Livehouse的遇冷，既与今年大型演出的挤压有关，也与音乐行业的发展和运营成本的增加等原因有关。

**今年大型演出的扎堆，分流走了大量的观众和音乐人。**往年在音乐节量还没有这么多的时候，很多音乐人会在Livehouse开巡演，但今年由于音乐节猛增，但凡能带动票房的音乐人和乐队都会去音乐节。比如夏日入侵企划、逃跑计划、廖俊涛等音乐人，今年基本上都去了各个音乐节，很少有专场Livehouse。而有名气的音乐人向大型演出的倾斜，也带走了Livehouse的部分乐迷。

**运营成本的增加，乐队资源的稀缺，导致了Livehouse的盈利困难。**景德镇文艺复兴Livehouse在公告中表示，设备、房租、人员等成本都在不断增长，而且拼命解决了成本问题后，乐队资源问题也是难题。今年有人气的音乐人向大型演出倾斜，小众独立音乐人也因为生存问题而停演Livehouse，独立音乐人石磊4ROCK取消了成都站的Livehouse演出，并表示“成都站和其他站票房太多悬殊，实在没有能力承受这么大的亏损，所以不得不取消。”

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/HKEDX7MqXK0JYnXJodXFqNGsbMwpsjKAMPJcJNjfeNxrhkjNqbtd94NmHtHWF7XC2mkBJTibic9EL5aE9ib2h3N7A/640?wx_fmt=jpeg)

**作为小众音乐类型的聚集地，Livehouse的发展也与小众音乐的破圈有关。**《乐队的夏天》的出圈吸引了很多新的乐队粉丝涌入Livehouse，《说唱新世代》等说唱类节目也为Livehouse带来了大量新的嘻哈迷。但近两年，国内音综缺乏爆款，也没有新的小众音乐类型破圈，Livehouse没有办法吸引到更多外围粉丝。

**此外，Livehouse在本身的发展过程中，也出现了不少问题，影响了自身的口碑。**因为Livehouse的收入和重心应该是以音乐演出为主、酒水为辅，但不少场地却通过设置VIP卡座、推销酒水来营收，忽略音乐演出本身，导致了Livehouse的污名化。剁主搜索发现一家名为“ZH live音乐现场”的livehouse，有各类酒水套餐，但完全没有演出相关的消息，而类似的案例还有很多。有网友表示，“很多就是打着Livehouse的名头吸引眼球，但实际上就是酒吧。”

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK0JYnXJodXFqNGsbMwpsjKAc766Lh4WWbLvWiaTnz7EneEJAXPicCo8bITXPmeTtfJQDw8G4D4CoibKw/640?wx_fmt=png)

大型演出的扎堆、乐队和音乐人的透支，让Livehouse和一部分独立音乐人陷入了更严峻的生存问题，而这些小型音乐空间曾经是很多独立音乐人迈入更大舞台的必经之路。

![](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd5XKRkVpVVL3eMHVjGS5HhMib3wA5jQwdcYp8xX3w0U30P5vyCzUfFzSoAfeJN0qSN25sx8bj8n0iaw/640?wx_fmt=png)

**口碑遇冷：“维权群”与“避雷贴”齐飞**

除了大型演出票房疲软、小型演出阵地Livehouse降温，今年的音乐演出不得不提的，还有观众日渐变差的体验和口碑。

其实今年音乐演出的票价整体都有所上涨，有业内人士表示，今年演唱会整体票价上涨幅度预计达到10%~15%。音乐节的门票也是一路升高，有些演出的单日票价高达998元。整体来看，2019年上半年音乐节、演唱会等演出600场次的票房是12.32亿元，而今年上半年的场次是506场，票房达到24.97亿元 。**上涨的票价本应该匹配更优质的演出，但今年不少演出虽然门票越来越贵，体验反而越来越差。**

在社交平台上，有不少关于音乐演出的避雷帖。比如天津乌戈世界音乐节就因为现场过于混乱而引发了很多人的吐槽，甚至投诉。根据乐迷的反馈，窄小的场地足足有6万多人，“踮脚都不敢怕猜到后面的朋友”，而且演出时间混乱，盘尼西林迟到了半个小时，原定10：20表演的许嵩也直到快11点才开始。

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/HKEDX7MqXK0JYnXJodXFqNGsbMwpsjKAYCG3AMm1RugRwucJt5z1vJQh6hJz80ibe8V8NfJRZibR6loMEpHj5tsg/640?wx_fmt=jpeg)

嵩山音乐节更是因为抄袭宣传文案、虚假宣传嘉宾阵容、跳票不退票等问题，被贴上了“最差”的标签，一度引发了上千位观众的“退票”与“维权”。此外，元气森林音乐节、咪豆音乐节都因为各种问题而被吐槽。

观察各个音乐节的反馈，观众的槽点主要聚焦在**“音响设备差”、“演出时间混乱”、“场地拉跨”**等问题上，今年的音乐节虽然数量庞大，但由于缺乏行业规范、且新入局的非专业主办方越来越多，各种负面问题正在消耗观众对音乐节的热情。

**不仅音乐节，很多由专业演出公司承办的演唱会，也没有实现高票价、高质量。**

而且不少演唱会的槽点也很令人匪夷所思，**“椅子脏”、“没空调”、“太拥挤”**等问题出现不止一次。比如梁静茹沈阳场的演唱会因为没有空调，现场观众多次齐声要求“开空调”，而杨千嬅、张韶涵等歌手的演唱会，也由于座椅太脏而被吐槽。很多人吐槽，这都不是专不专业问题，是主办方根本不用心。

今年频繁出现的**“柱子票”**更是直接损害了观众的正常消费权益。在今年5月梁静茹上海场的演出会中，就有粉丝不幸花千元买到“柱子票”并且维权无门的现象。此外，包括刘若英、毛不易在内的多位歌手的演唱会，都出现了“柱子票”。

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/HKEDX7MqXK0JYnXJodXFqNGsbMwpsjKAfCFl1IWiccYy5xUPFhy6qTEfq1b7YTogKfjNvbMhpNibD9Fic1zUZ78cw/640?wx_fmt=jpeg)

**另外，演唱会门票的机制问题，也在今年被无限放大，影响了很多观众的消费体验。**今年演出市场的火热吸引了很多黄牛下场，甚至不少粉牛也加入其中，由于很多演出门票未采用实名制，进一步加剧了黄牛的猖獗，导致真正的粉丝抢票难，二级市场却各种溢价票漫天飞。不久前林俊杰的演唱会开票，为了买票不少黄牛招募985、211及本科以上的大学生背题，参加官方购票平台JJ20的“考试”。

而部分采用了强实名制的演出，虽然有效杜绝了黄牛，但因为不允许退票、转票的条款，也让很多临时有事无法到场的歌迷不得不承担损失。迫于很多消费者的维权，梁静茹、刘若英、鹿晗等歌手开通了限时退票通道。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK0JYnXJodXFqNGsbMwpsjKAwNhofILdz3mdvxJjWE2ic4HicQ5vEiaOd5afcfCsEtmZQAkJiankI3wc1w/640?wx_fmt=png)

这些低质量的体验，不仅会影响观众对当下音乐演出的负面情绪，也会影响观众之后对此类音乐演出的不信任，导致影响其消费决策，产生“不看不买”的情绪。目前社交平台上，已经有很多“最差体验，下次不去了”、“再也不想去了”的评论。

纵观今年的音乐演出，繁荣无疑是主旋律。但繁荣之外，从售票到口碑、从大型演出到Livehouse，各个环节都开始出现趋势性的负面问题，而这些负面问题已经对下半年的演出行业产生了明显的反噬。虽然今年音乐演出增长明显，很多主办方也吃到了市场发展的红利。但长期来看，要想持续性地吸引观众，还是需要依靠优质的内容和服务，否则这种增长也只是短暂的繁荣。

![](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd6RbduWQ1AIryUvalfYznTBHJZwVW6G1gosXoTsfeSLolMHPIiasAATwylyPf9tSLBqM6lliaVkwukQ/640?wx_fmt=jpeg)