# 深入内部，《原神》走红欧美的原因我们打听到了

> 公众号: 娱乐资本论
> 发布时间: 
> 原文链接: https://mp.weixin.qq.com/s/jOELTSaeccQ4YuuE6dM69Q

---

![图片](http://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd4fI5qQS0nBxzJhze9qENl2Z8eGoKI6Hk8uVf1a2I1CV4mjeNwgxOH794DgL6GD2a1WJ0xicicyKYuQ/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)**作者|毛丽娜**

不出所料，2月份出海收入增长双料冠军，又是《原神》。

这是它蝉联冠军宝座的第九个月，而且从后续版本内容及竞品情况来看，这把铁王座在未来很长一段时间内，都会属于《原神》。

在诸多国产手游中，《原神》是个异数。

Sensor Tower 商店情报数据显示，米哈游《原神》移动端收入的47.7%来自中国iOS市场，日本市场收入占20.7%，美国市场收入占8.9%。

一般来说，出海成绩优异的手游，在国内市场往往呈现水土不服的状态；反之，国内市场运营得风生水起的手游，在海外受众却很有限。唯独《原神》，做到了国内国外“两开花”，特别是在欧美市场获得了成功，即使诞生之初有着“抄袭《塞尔达传说》”的原罪，但欧美玩家仍旧愿意为了它买单。

《原神》的火不仅体现在收入上，还体现在海外社交媒体声量上。

据 GameRant 报道, 过去一年《原神》是Twitter上讨论度最高的游戏，与它有关的推文共有 12571 条，转发量为 3903520 次，而第二名《最终幻想14》转发量仅为《原神》一半。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

这不禁让人好奇，作为一款二次元游戏，《原神》是如何突破欧美市场的壁垒，不断吸引欧美玩家入坑的？带着这些疑问，预言家游报打入《原神》欧美玩家内部，想从他们的口中，获悉最真实的入坑答案。 

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)**我为《原神》狂，欧美玩家眼中的《原神》**

每个月都会有这样一个周五，俄罗斯玩家阿廖沙提前推掉一切聚会、准时守在电脑跟前，因为这一天是《原神》的前瞻直播，声优或制作组成员会为玩家带来下一个版本的新情报，以便于玩家提前进行游戏规划。

“我以前是个很爱社交的人”阿廖沙说，自从入坑《原神》以后，他的生活发生了许多改变。比如新版本更新后，他会专门请一天假，开荒锄大地，在电脑前一坐就是十几个小时；再比如前瞻直播那天，他会把手机调成静音，“谁也别想打扰我看新情报”。

像阿廖沙这样每个月死守前瞻直播的欧美玩家有很多。以3.0大版本更新为例。米哈游选择Twitter与YouTube作为前瞻直播平台，约有百万玩家同时在线观看这场直播。值得说明的是，这场直播的主持人是米哈游创始人之一刘伟，以及《原神》制作团队，因此直播全程使用中文，但语言不通却没能熄灭海外玩家的观看热情。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)阿廖沙甚至打算加入米哈游

谈及为什么喜欢《原神》，阿廖沙说首先是这款游戏足够自由，虽然也有主线剧情，但并不强制玩家一定要做任务。如果你只是个喜欢看风景拍照的休闲玩家，在游戏中也能获得乐趣。

不过伴随着版本内容越来越多，阿廖沙也承认，《原神》的自由度有所下降，“有些区域不做任务就去不了，而且米哈游的剧情量越来越大还不能跳过剧情或者倍速播放，这也是我为什么必须请假在家开荒一整天”。

游戏中的其他玩家都很友好，也是阿廖沙为《原神》着迷的原因。曾经在其他游戏中有过不快乐回忆的阿廖沙，对于大型多人社交类网游心里有些抵触，没有公屏聊天的《原神》，让他松了口气。偶尔，他会收到其他玩家想要进入他世界的申请，“每个来的人都很礼貌，会问我有没有要帮忙的，有人还会用游戏中的道具弹琴给我听。”

正因为自由、且游戏内其他玩家友好，阿廖沙愿意把这款游戏推荐给朋友。

其他欧美玩家则表示，身边入坑《原神》的人变多了，靠《原神》赚钱的人也变多了。

“《原神》就是直播流量密码。”玩家Mark是2021年稻妻版本入坑的，该版本浓郁的日本文化很对他这个老二次元的胃口。在体验游戏内容之余，他也会搜索一些二创或看看其他玩家直播，“当时直播《原神》的人没有现在多，而且很多主播同时直播好几款游戏，不以《原神》为主，现在专门做《原神》内容的人变多了，网站也会给到流量倾斜，于是看的人和做的人都越来越多。”

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)爆料博主Xwides

屡禁不止的海外《原神》内鬼，同样与财富密码有关。

所谓“内鬼”就是在版本发布前泄密的人，他们往往会提前数个版本泄露游戏内容，玩家出于对后续版本规划的需求，对这类爆料也很喜闻乐见。这就给了内鬼生财的机会：比如建内鬼网，植入广告收广告费；或者拉群，每个群员每月要上缴群费以换取最新爆料，群费从几十到100美元不等。

“有内鬼靠收费爆料能月入几千到上万美元”，也难怪米哈游频频发律师函整治爆料者，但内鬼乱象特别是海外内鬼却还是屡禁不止。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)**海外玩家亲述：我是这样入坑的**

一般来说，国内游戏出海没有什么特别的渠道。大多数厂商还是遵循着传统的买量投放，如果游戏靠买量达到一定声量吸引到了初始玩家，那就有生存下去的可能。

《原神》不太一样，Mark第一次听到这个名字，是在漫展上。

和国内漫展不同，海外漫展是影视剧、游戏的重要宣传渠道之一，《权游》衍生剧《龙王家族》就选择漫展作为自己的宣传阵地。而二次元属性浓厚的《原神》，本身与漫展就有高度契合之处。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)AI  作图  by  娱乐资本论

Mark表示，2020年的纽约漫展因疫情取消，所以2021年的漫展无论是规模、人数都比之前要大，“毕竟等了快两年”。还没进入场馆，只在排队的时候，他就发现这次的纽约漫展与过去很不一样。

“我记得很清楚，漫展入口处挂着大幅《原神》的海报，上面是雷电将军和神子她们，不得不说将军的立绘还有那种压迫感，一下子就把我吸引住了。”

不止如此，进了场馆后Mark发现，几乎一半以上的coser都装扮成《原神》中的角色，而且找他们拍照互动的人也很多，“本来我就很喜欢二次元文化，从漫展结束后回家就准备玩一玩”。

这是Mark第一次接触中国游戏，也是他第一次玩手游。

“从内容上来看很好理解，没有我想象中的那种浓郁的，需要对中国文化有所了解才能明白的中国元素；玩法上，我不喜欢用手机打游戏，但它支持PC端，玩起来就很顺手。”

不止纽约，去年一年洛杉矶漫展、多伦多Anime North漫展等欧美漫展上，《原神》几乎都是C位担当。Mark的一些二次元同好，也遵循着跟他差不多的路径入坑。

Mark提到的“内容好理解”，也是《原神》作为国产游戏，闯荡欧美却没遭遇“文化水土不服”的原因。

年近30岁的Dickson是中国文化爱好者，但他坦言除了三国类题材外，他几乎不玩其他来自中国的游戏。

“太难理解了，有些游戏的本地化翻译做得也很差，我没法从游戏文本和内容中获得任何乐趣。”

《原神》中的七个国家，在现实中有实际参考对照，但理解门槛并不高，而且就像Dickson说的，本地化内容做得够用心。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)B站埃及小姐姐谈须弥版本本地化

“就拿这次的风花节内容来说，角色赛诺是冷笑话爱好者，经常会说一些双关语，游戏文本在这里的设置是很巧妙的，有谐音、意译、引申义等等，经常会让我忘记这是一款中国团队制作的游戏。”

在故事暗线及世界观方面，《原神》化用了诺斯替神话系统，这一点于海外玩家而言也比中国古代神话故事更容易接受。Youtube上有不少海外玩家深挖游戏背景故事进行考据，Dickson说，这些游戏外的考据也是游戏持续吸引他的原因。

须弥版本海外玩家数量暴涨，也与米哈游在该版本一连化用了波斯、埃及、印度等多个国家的神话人物和传说有关。中东、印度等地，在传统游戏产品中很少被提及甚至深度挖掘，正因如此须弥版本获得了海外有色人种的青睐。

“我感觉，好像新开一个国家，就有很多对应原型国家的人入坑。”         

俄罗斯玩家阿廖沙则表示，在西方世界主导的游戏中，俄罗斯的形象多负面、鲁莽，而《原神》中最吸引他的，是以帝俄为原型的至冬国。“不知道该怎么形容，那个音乐还有国家的感觉，让我觉得很对，而且俄文的用法也很考究，所以我应该会一直玩到2025年至冬国上线吧。”

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)**十年配音无人知，一入原神天下闻**

在交流中，预言家游报发现了另一个有意思的现象：声优与《原神》之间存在互相成就的关系。《原神》在欧美市场的破圈，与海外配音演员的努力营业分不开。

与已经形成粉圈文化的中日声优偶像不同，欧美声优因文化背景、二次元向消费内容起步等外因，更类似于幕后打工人。体量大、玩家多的《原神》，给了他们被外界关注到的机会。

Mark和阿廖沙都表示，在《原神》之前，他们玩二次元游戏都会选择日配，因为“英配水平不行，配不出二次元的感觉。”但随着版本更迭，他们渐渐发现英配业务水平进步神速，一些新加入的配音演员表现甚至不输日配。

“比如雷神这个角色”，说起雷神的英配，Mark感触很深，“剧情中她有两重身份，一个是执行命令的人偶，一个是本体雷电影。剧情中有一幕是人偶和影的对峙，配音演员Anne真的配出来了非人和人的感觉。”

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)配音演员anne

可以说从稻妻版本开始，英配凭借自己的业务水平扭转了外界对他们的刻板偏见，并获得了欧美二次元用户群体的认可，而且越来越多已经在欧美圈内有知名度的声优加入《原神》项目组，以期进一步提升自己的知名度。

英配们在享受《原神》带来的流量同时，也在为《原神》增添热度吸纳新粉。

与国内不太一样的是，欧美玩家对于配音演员将自己与角色捆绑的行为并没有那么抗拒。角色赛诺在剧情中有爱说冷笑话的设定，而且与另一位角色提纳里交情匪浅。配音演员在直播《原神》时也会刻意说大量冷笑话，并且在提纳里出现时，说一些“他好可爱，我好喜欢他”的话自炒cp。这样的行为，在国内可能会被骂蹭热度，在欧美却挺受玩家欢迎。

此外，英配们经常会组织定期团建，有时候是线上连麦打游戏，也会有线下聚会活动。这些内容会被制作成切片，经过二次解读后在网络上进行传播，“很有意思，也很吸粉”。

欧美玩家也很喜欢看配音演员讲述自己如何被选入《原神》项目的心路历程，鹿野院平藏的英配kieran在得知自己被选中后，在直播中喜极而泣。这段视频切片为他带来巨大关注，其中包括20多万来自中国的观众。其他英配谈幕后故事的视频，播放量同样可观。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

值得指出的是，与中日韩三国配音均为专业配音演员不同，英配中有不少人本身就是游戏博主或网红，比如为赛诺配音的Alejandro。这些自带粉丝的英配加入《原神》项目后，他们的原始粉丝会出于支持偶像的目的去接触这款游戏，继而入坑，这也是近一年来《原神》在欧美地区玩家数量持续增长的原因之一。

凡事有两面，配音演员是助力也是隐患。

2月份提纳里英配被指借角色身份诱骗未成年少女，在欧美玩家圈引发轩然大波，米哈游更是以前所未有的速度与这名演员解约以示切割。整活固然能带来流量，但演员与角色捆绑过深，一旦演员出事，角色甚至游戏也会受到反噬，这一点在国内许多游戏身上都发生过。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

此外于米哈游而言，虽然《原神》成功打进了欧美市场，也得到了欧美玩家的认可。但伴随着玩家数量变多，特别是非二次元玩家的加入，“政治正确”问题逐渐成为欧美《原神》的主议题。尤其须弥版本开启后，欧美玩家开始讨论“角色够不够黑”“有色人种是否被忽略”，最近新登场的黑皮佣兵迪希雅，因技能设计割裂，强度欠佳，被认为是“米哈游歧视实锤”。

二次元女性角色多为“白幼瘦”，《原神》作为一款二次元手游也难逃窠臼。但随着游戏成功出海，玩家群体的扩大，“白幼瘦”审美势必会令一部分人觉得不适，如何平衡原有玩家群体与新入坑玩家，特别是欧美玩家群体的审美差异，是米哈游未来要好好琢磨的问题。

另外，《原神》本质上是一款卖卡游戏，角色设计既不能太弱，影响当期卡池销量；也不能太强，阻碍后续卖卡大计。迪希雅并非限定角色，她的强度欠佳从策划卖卡角度来看是能说通的，但“有色人种”这顶帽子扣上了，海外玩家的情绪就很容易被煽动。这样的事情在未来只多不少，即要卖卡，又要讨好所有人，对米哈游是个考验。

从欧美玩家真实入坑反馈中不难发现，《原神》的成功路径并非不可复制。总结起来，就是在合适的场合说合适的话给目标人群，一家独大并不利于市场发展，也希望诸位厂商加把劲，将更多《原神》输送至海外。       

**话题互动：**

****原来你也玩《原神》？****

**推荐阅读**

[![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247569305&idx=1&sn=0258a2f804cfaf1948f11e3a1137c734&chksm=c058da42f72f53544fc4112a03b8e4f72a35e7c8eb368dcea274b98e14c0d3130af0c4e90900&scene=21#wechat_redirect)

[![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247569102&idx=1&sn=6d536fe97cbf67e91921e5a9c90634a6&chksm=c058db15f72f5203a391869dfed551e4194d05b01cda21cf1815383254b35ddd4fc0b8422e4e&scene=21#wechat_redirect)

**100万粉一夜带货3000万，董洁咋做到的****？**

**点击观看**

**↓↓↓**

关注**娱乐资本论视频号**，追料更及时

-

**如需商务合作后台回复【商务】**

**如有转载需求后台回复【转载】**

**更多文娱产业背后的经济逻辑，来关注↓↓↓**