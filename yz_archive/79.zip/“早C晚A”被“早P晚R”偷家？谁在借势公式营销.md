# “早C晚A”被“早P晚R”偷家？谁在借势公式营销

> 公众号: 娱乐资本论
> 发布时间: ref: <Node>
> 原文链接: https://mp.weixin.qq.com/s/qiudwgxnCi1hdxCSiRr6xQ

---

![图片](http://mmbiz.qpic.cn/mmbiz_png/jNZszpkibXx9fK5DxyTD7AyeFpFRtOjibtXBxHxv9ibzVMWibiaric81WOFUJLW0R1iabhKNBDSeVExetG9DF1zviaEjew/640?wx_fmt=png&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)**作者|库库紫**

说起近两年美妆行业的心智营销，没有品牌不想复制珀莱雅，推出另一条“早C晚A”式的爆火公式。

所谓“早C晚A”，指的是早上使用含有维C类成分的护肤品，晚上使用含有维生A类成分的护肤品，二者相结合来美白亮肤，抵抗衰老。

正是凭借这一概念的提出，珀莱雅这一老牌国货美妆在过去两年迅速焕发新生，尤其是在去年，借助公式概念推火的红宝石精华、双抗精华等大单品，珀莱雅在38 节、双十一等大促中居于国货之首。

复制者蠢蠢欲动。    

就在近日，它的孪生姐妹“早P晚R”开始在23年开春形成一股小风尚，不少品牌集中跟进，批量在社交领域投放话题内容。对早C晚A的种草引爆打法进行了复制追踪。

根据魔镜电商聆听数据，从2023年2月至今，各大互联网平台上关于早P晚R的讨论在2023年2月达到顶峰，而关于早C晚A的讨论在2022年3月之后便热度退却。 

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)图片来源：爱魔镜科技

同样，除了早P晚R，不少护肤品牌还根据成分和营销特点推出了“早C晚B”“早B晚A“”早E晚R““早U晚A”等时尚美容公式，希望悄悄借势新护肤思路搭上公式营销的快车。

然而，这些关键词的流行程度却远远比不上早C晚A曾经的盛况。尽管讨论不少，但大多是品牌投放，缺少消费者的自主跟进。

显然，上述公式都没能成功占领消费者心智，在成分护肤、功效护肤的时代，护肤界的公式营销所取得的成绩有目共睹，但很明显，不是所有公式营销都能有水花。

到底什么样的护肤公式可以帮助品牌扩大市场？公式营销的路径可复制吗？

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)**“早P晚R”能否接班“早C晚A”**

实际上用“接班”这个词用来形容它俩的关系稍显不合适，更形象的说法应该是早P晚R的“收复失地”——因为早P晚R是由早C晚A的底层护肤逻辑推导出的更温和方案，用以弥补早C晚A成分过于刺激导致敏感肌不耐受等问题。

“早P晚R”的含义是，日间防御（Protect，包括抗光、抗污染、抗氧化损等）+夜间修护（Repair，激活抗衰焕肤靶点，温和滋养修护抗老），并扩大了早晚可供挑选的成分范围。

日间可以选择麦角硫因、EUK-134、虾青素、植物多酚、白藜芦醇、艾地苯、熊果苷、烟酰胺等来抗氧化，晚间修护则可以从玻色因、补骨脂酚、胜肽、LR2412等成分中选择，以此来让消费者巧妙规避早C晚A耐受度问题的同时，可以选择最适合自己的抗老产品进行搭配。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

简单来说，两者的卖点都是抗衰。早C晚A直接提供了一套清晰明了的成分方案——白天用维C产品，晚上用维A产品，缺点是功效偏猛，敏感肌肤建立耐受门槛高；而早P晚R更为温和，适应成本低，并且选择范围大。

但选择更多对于品牌来说一定是好事吗？也许不然。

在早C晚A风靡之际，一些大品牌的CA组合就以CP形式“出道”，珀莱雅的双抗精华和红宝石精华总是成双成对出入，消费者磕得不亦乐乎，俨然护肤界赤手可热的明星抗衰CP。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

换句话说，入手早C晚A，对于各个年龄阶段有抗老需求的消费者来说都几乎没什么学习成本，不仅公式给总结出来了，就连产品搭配方案都写好了送到消费者眼前，上一秒还在心动，下一秒就可以打开橙色软件激情下单。

反观早P晚R这一公式，**太过宽泛的概念和宽松的选择范围使得它听起来有点像个“伪公式”**，比起公式它更像个概念，还是没什么新鲜度的那种——美妆护肤领域的消费者们早已不是当初的傻白甜，白天防护夜间修护的理念早已深入人心了。 

**所以，早P晚R不具备早C晚A的知识新鲜性，无法让消费者产生对未知的好奇，又因为成分选择颇多，消费者还得经历一次学习筛选的阶段。**真正能占领消费者心智的，应当是像“早C晚A”那样兼具新鲜感、刺激性和便捷性的公式。

不过，早C晚A的热度已经退却，“温和护肤”已经成了2022年后美护界的一大热词，《2023我们青春肌抗老趋势白皮书》表明，青春肌人群越来越关注主打温和高效的抗老产品，“早P晚R”顺应的正是这一护肤理念。

然而，回顾2022年，在社交平台上讨论声量较高的黑马护肤品牌们的主阵地也正是敏感肌温和护肤市场——主打敏感肌专用的薇诺娜、理疗护肤的逐本、低剂量温和美白的谷雨、医研共创的玉泽......

可以看见，国货敏感肌护肤市场已经有品牌正在强劲生长中，而早P晚R的几个代表品牌野兽代码、朴理等仍处于起步阶段，淘宝官方旗舰店的在售产品不超过20种，除了一两个主打产品外，其余产品的付款次数基本只有三位数。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

早P晚R没有大品牌的知名度作为靠山，也缺乏足够的知名KOL背书，后续营销动作无法复制当时早C晚A的盛况。

2022年，上述薇诺娜等品牌已经抛弃了公式营销思维，主要集中于强化品牌核心护肤概念，在精准目标人群中耕耘品牌口碑。这也侧面暗示了品牌仅凭“早P晚R”做公式营销可能难以复制早C晚A的成功，更何况是在敏感肌护肤这个已经强者云集的次级市场呢？

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)**公式/概念营销可复制吗？**

早P晚R不行，那什么样的公式可以？

复盘网上近几年大热的四大美妆护肤新锐词汇，包括早C晚A及其衍生公式ABC护肤、以油养肤、纯净妆护以及微生态护肤，无一例外都在强调护肤品的成分构成。

在成分党遍地跑的当下，各种护肤产品让人眼花缭乱、目不暇接，品牌或产品的成分核心概念确实在营销中能够起到举足轻重的作用。

以上述新锐词汇之一“以油养肤”为例，这个概念在2021年-2022年间跟随兰LAN品牌进入大众视野。

在早前，尽管任何护肤品当中都含有油性成分，但鲜少有人单独将“油”作为一个护肤单品去使用，并且大众的观念里干性肌肤才需要油，油性肌肤对其避之不及。

但兰品牌在提出“以油养肤”的概念后，打破了大众固有思维，并推出了几款分别适合不同性质肌肤的护肤油，通过美护界的头部KOL骆王宇、程十安等人的背书带货，成功扭转了国人的护肤消费思维，让自己成为护肤油的“代言品牌”。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

其他几个美妆新锐词汇也有着类似的营销轨迹，而在这个过程中，最核心的关键词，就是如何在功效成分遍地走、美妆知识一大把的环境里“被记住”。

这四个“被记住”了的公式概念有几个明显共同点，也是公式/概念营销必须具备的：

**1.新鲜和独特。**这些概念无一例外都是大部分消费者闻所未闻的，甚至颠覆了长久以来固有的护肤观念。以微生态护肤为例，放在以前很难想象会有护肤品用菌群做主打成分记忆。

**2.朗朗上口、容易记忆。**尤其是早C晚A和以油养肤，不仅让KOL和带货直播间有一个强凝聚的口号使用，还真正做到让消费者听一次就知道在强调什么成分。

**3.核心概念和主推成分精准。**早C晚A主打抗衰，以油养肤主推油的作用，纯净妆护主打成分精简安全，微生态护肤主打益生菌群功效。反观早P晚R，抗衰、温和、多样化一揽子都想包，反而难以打出差异化。

**4.强背书。**这四个概念中三个都背靠大品牌，兰护肤油也极其频繁地出入各种电商直播间，而早P晚R的代表品牌朴理、野兽代码还没有足够的实力攀比营销投入。

2019年，成分护肤党崛起，至今仍然霸占护肤观念的第一宝座。在焦灼的市场竞争中，成分公式为品牌带来过不可估量的声量，但在蛋糕被分得越来越小的当下，通用式的护肤公式竞争力已然减弱，像“早P晚R”这样简单的公式复制很难将上一代的受众直接剥离和继承，朴理和野兽代码等新护肤品牌还需要继续精细概念，瞄准差异化目标人群，在细分人群市场中寻求最大化。