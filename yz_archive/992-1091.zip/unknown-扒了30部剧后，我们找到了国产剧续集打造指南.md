# 扒了30部剧后，我们找到了国产剧续集打造指南

> 公众号: 娱乐资本论
> 发布时间: 
> 原文链接: https://mp.weixin.qq.com/s/uFYd9zZ0O9fkfB0SHAsZFg

---

![图片](http://mmbiz.qpic.cn/mmbiz_jpg/jNZszpkibXxichMxl1AYOC3OPGBcgeGz1LyUcojSAn8ibXcDt3UUtAqpLvWvbEWYvFb6S3vNjMOA01jdhJKVWx8Vg/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)**作者｜肉松**

近期，一直被剧粉催更的《大宋少年志2》终于更新了进度：官宣演员阵容。

一个老生常谈的问题再次被提起：**为什么国产剧续作总是一鸽再鸽？**

而这部剧的“虽迟但到”，给人一种续作终于要支楞起来的感觉。就在不久前，也有多部剧集的续作先后上线：《少年派2》《欢乐颂3》《二十不惑2》。

但这几部作品中，有的口碑持续翻车，有的质量与热度不成正比。这也并不新鲜，复盘过往项目可见，千呼万唤始出来的续作不及预期，很多项目都停留在第二季。于是又牵扯出一个相关问题：为什么国内无法做出成功的系列剧？

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

需要明确的是，这里说的系列概念对应季播欧美剧，其最大特点是边拍边播、排播稳定，一部剧持续输出5-7季也很常见，而对成功标准的界定，则同时包括内容品质和商业价值两个方面。

站在观众视角上，上述两个问题的答案往往与演员有关。在第一部之后，演员片酬上涨，戏约增加也让档期难凑；其次是剧本质量及进度，王倦一个编剧的身上就背了好几部剧的“欠债”。

通过与从业者们的交流，娱乐资本论发现答案不止于此。国产剧系列化这件事，涉及到作者、演员、主创、制作公司及平台的各方博弈，同时又在政策、环境等因素影响下而不受控制。即便如此，面对其商业价值、品牌效应带来的吸引力，系列化就像一座必须要逾越的高山。而且这种趋势在今年越发明显，从制作公司到平台，有人已经给出成绩单，有人在赶着交卷，也有人在拓新路。

是时候聊聊国产剧系列化的问题了：所谓的“续集魔咒”是如何形成的？国产剧系列化究竟难在哪？从业者在探索中找到了哪些解题思路？

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)**续作扎堆背后：口碑下滑、延续性不足**

对于优质国产剧往系列化发展，观众往往是持欢迎态度的，但现实是，结果时常让人空欢喜一场。制片人大喜总结，做出一部让观众满意的续作并不容易，大致要满足以下几点：

**第一，保持剧作整体水准**

近期的几部续作中，最典型的是《欢乐颂3》，继第二季的口碑危机之后，由于人设和情节不落地、演员演技等原因再次遭遇负面评价，豆瓣评分跌破系列最低——开分4.6。仍以豆瓣评分为标准，此前的系列化作品，比如《无心法师》《心理罪》《河神》等，几乎都没能保住首部的口碑。

**第二，原班人马回归**

一直以来，大部分续作都无法聚齐原班人马，《二十不惑2》的女主回归了三位，甚至像《欢乐颂3》一样迎来阵容集体大换血。过往项目中，因为韩东君等演员是制作公司唐人的签约艺人，《无心法师》是为数不多主演统一的系列；《暗黑者》则是另一种例外，饰演男主的郭京飞同时担任监制。

而换角是观众最不愿意看到的一幕，原班人马塑造的角色深入人心、演员间的演技差异，都会造成观看门槛。

对《法医秦明》《河神》的很多剧粉来说，在第一部中饰演男主的张若昀和李现，其位置始终是难以替代的；在《将夜》《我只喜欢你》的相关评论中，有不少观众表示，王鹤棣、虞书欣不是在演角色，而是在模仿前一部作品中演员的表演。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**第三，剧情发展符合观众预期，尤其是CP线**

相比普通剧集，观众对系列化作品通常有着强预期，会预判情节和人物关系走向。但基于换角等原因，这点也很难实现。比如，《二十不惑2》中的姜小果、梁爽和段家宝都有了新的感情线，从高达8.1的豆瓣评分来看，观众对其作为续作的认可度可见一斑，但仍有很多观众因CP被拆而惋惜。

还有部分系列让观众陷入漫无边际的等待。《庆余年》《大宋少年志》都播出于2019年，但第二季都迟迟未开机，前者还处于剧本阶段，#李小冉说庆余年2剧本还没出来#于昨日登上热搜，后者的最新进展则是网传将于9月开机。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

但好在，这些都是已官宣的项目，用观众的话来说，欠债迟早要还上。更考验观众耐心的是那些呼声高但悬而未决的剧，比如《御赐小仵作》《侠探简不知》。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)**版权纠纷、档期难凑，为何国产剧不易长久？**

抛开做得好不好，能将续作推出已经相当于一种成功，而不论是沦为狗尾续貂，还是落入口碑、热度难两全的境地，这些结果都说明，国产剧系列化始终是摆在从业者面前的难题。

大喜告诉小娱，自己一直在尝试系列化，尽管还没有做出成功案例，但积累并收集了不少经验教训。如果能吸收以下建议并顺利落实，会离成功更近一步。

**建议一：改编IP、搞定版权，启用靠谱编剧**

梳理相关项目可见，国产剧系列化大多依赖IP，对应到创作流程，版权是第一道难关。改编长篇IP有天然优势，但版权归属不统一会给系列化开发造成障碍，那观众看到的就并非系列，而是七零八落的不同版本了，比如《法医秦明》。作者选择拆卖版权或按进度写一部卖一部，都很容易出现这种情况。

另一种情况是，当原著体量有限或可用素材有限，一部剧就能把IP消耗完。很多时候，推出续作也意味着脱离作者进行输出，新的问题又出现了。

因为后续内容需要原创，在基本创作外还要考虑只沿用概念还是续写故事，而这个过程不仅存在版权风险，还会拉长项目周期，消耗市场和观众的耐心。据了解，《摩天大楼》第二季的开发就一度卡在前期阶段，今年年初时正由第四拨编剧在打磨大纲。

**建议二：抱到“大腿”，再考虑原创**

备受行业推崇的IP改编尚且如此，本就罕见的原创项目要想系列化则属于难上加难。

2020年的《侠探简不知》是近年黑马剧之一，搜索其关键词，能在社交平台上看到大量期待后续的呼声，今年4月10日是其播出两周年，编剧看到观众觉得很难有第二季的猜测后表示“大概是有的”。这个回答虽然让人有所期待，但也可以理解成前途未卜。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

此外，项目进展也取决于主控方与编剧是否能建立长期合作，如果答案是否定的，前者会找其他编剧接手。相比之下，原创项目更换编剧的风险性比IP改编要高，站在编剧的视角上也更为微妙——很容易出力不讨好。

而这种情况在行业里并不少见，编剧阿杰正在接触的一个项目就是原创剧集的续作，还处于和片方沟通的阶段，难以抉择的一点是，延续之前的风格还是加入新的东西。

**建议三：谨慎选择优势题材，创作易、过审难**

回到内容层面，在讨论系列化有优势的题材时，不得不提的是刑侦、律政和医疗，在强设定下，可以将故事置于相对固定的空间里，且很适合做成单元结构。但它们同属审查的重点关注对象，项目过审的难度系数在不断上升，道现阶段，这类项目在立项前都要先交给相关专业机构进行审核。

同时，本就不存在的“标准”也在发生变化。编剧汤祈岑告诉小娱，《暗黑者》系列的创作过程就经历了这种变化，这也是第三部与前两部相隔时间较久的原因之一，“以前能写的东西后来就不能写了。”

**建议四：原班人马回归是底线，要么就提前规划**

以人物成长为主线的故事同样有系列化空间，比如《少年派》《二十不惑》，这也引出另一方面的难点——码盘。

对观众来说，原班人马的回归是剧集系列化的意义之一，但这点向来是最难实现的，第一季走红会导致演员片酬上涨，此外还要协调多位演员的档期。编剧王深林提到，这两个因素不是全部，由于此前的成功案例太少，也存在演员对续作没信心、不想演的情况。

在根本上，出现这些问题很大程度上是因为，大部分国产剧都是看到市场反馈后才决定系列化的。也包括《暗黑者》。汤祈岑回忆，在筹备第一季的2013年，国内做网剧还处于试水阶段，投入成本也有限，**所以前期目标只是先把项目做出来。**

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

这会埋下不同的隐患。比如，为了趁势推出下一部而压缩剧本创作时间，剧作质量也会随之下降。随着系列化形成趋势，也有片方在有意向时同步准备剧本，再依据市场反馈做最终决定，但能不能用得上又是另一回事了。再者，缺乏前期规划也会影响其它生产要素。不止是演员难以回归，也包括编剧、导演等主创。从过往的国产系列剧来看，大部分项目都没能保持统一班底。

而真正致命的是，这种“走一步看一步”的观望态度也说明，片方并未想好要做什么。

整体看来，只有由头部公司或平台牵头并提前规划的项目能够成为例外。比如《庆余年》《鬼吹灯》，**这两个项目都事先搞定了版权、演员及主创团队，企鹅影视与七印象合作的后者提前准备了五部的剧本，但还是无法保证更新频率。**按照目前进度，它们似乎很难实现各自五年三季、每年一季的计划了。

往前追溯会发现，早在卫视时代，国产剧就对系列化多有尝试，有些作品已被如今的观众视为经典，但其中包含时代滤镜的成分。《神探狄仁杰》也存在版权问题，导演和制片人分道扬镳之后，分别推出了两版第四部，一部改名为《神断狄仁杰》，另一部于2017年才姗姗来迟，但质量明显下降；《重案六组》系列的主演中，只有饰演季洁的王茜做到了常驻。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

可见，国产剧系列化之难其实是历史遗留问题。只不过早期的内容水准更有保障，能做到让观众“真香”。而如果用一句话来总结这件事在当下的难点，应该是：它既涉及到作者、演员、主创、制作公司及平台的各方博弈，也在政策、环境等客观因素影响下而不受控制。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)**难做还是想做，国产剧系列化路在何方？**

看起来，国内影视行业并非系列化开发的优质土壤，但从业者又对其难以割舍。

除了大喜，不止一位制片人曾对小娱直言做系列的憧憬，“其实所有公司都想做系列”“一直想做，但还没成功”。王深林也观察到，这两年接触过的很多项目里，制片方都提出想采用开放式结局，为后续留一个可能性。

这背后的原因并不难理解。**首先是商业回报**，《欢乐颂》系列是最好的案例，第一季成为现象剧后，第二季的招商表现抢眼，在口碑下滑、原著故事已经拍完的情况下，又启用新“五美”并由阿耐担任编剧，一口气启动了后续三部，播出的第三季依旧不缺品牌支持。

企鹅影视主导的《鬼吹灯》系列则属于另一种典型，对于这样的大IP，要想还原原著并实现其改编价值，往往需要较大规模的投入，如果只做一部，很难实现盈利甚至收回成本。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**其次是品牌效应，**王深林此前接触过一个由制作公司发起的系列化项目，除了内容考量，借助系列打品牌也是对方的明确诉求。在成功的前提下，系列化的持续性有助于制作公司彰显产能、积累赛道优势，从而获得更高的声量。

对平台来说也是同理，此外，与系列进行强绑定还能提高用户粘性，形成稳定的排播。说得大一点，则同时是剧集行业工业化水准的一种证明。

**最后是具体操作上，**王深林表示，相比开发新项目，有第一部的数据和反馈作为支撑，制作方还是更愿意推进续作，因为这意味着更低的试错成本以及热度上的先发优势，就像IP改编比原创更吃香一样。

那么，谁在跟进系列化探索？面对层层难题，创制端是如何进行系列化开发的？

结合过往作品及平台片单来看，制作公司方面，最出成果的还要属头部玩家，比如，正午阳光、柠萌影业、新丽传媒，略有不同的是，前两家的自主性更高，而新丽对系列化的专注与腾讯影业、阅文的合作及规划有关。

**除了它们，另一些打造过优质、甚至爆款项目的公司也在打系列化这张牌，比如留白、五元等，只是处理方式和赛道有所区别。**

前者创始人徐康曾在接受媒体采访时提到，公司剧集业务的关键词之一就是系列化开发，他认为，“在这个行业阶段，一年一清零的做法太过时。”目前看来，马伯庸IP似乎为留白的相关规划提供了可能。后者则在悬疑赛道上占据一定优势，从《白夜追凶》及包括12集短剧在内的部分项目中，都能看到系列化探索的痕迹。

平台方面也在以不同打法进行布局。其中，芒果TV发力明显，除了近期的《少年派2》，《大宋少年志2》《长安十二时辰2》也出现其最新片单中，而湖南卫视一直是系列化开发的先行者；青睐大IP、与企鹅影视强绑定的腾讯视频也手握多个系列：《欢乐颂》《鬼吹灯》《斗破苍穹》《斗罗大陆》。

优酷在系列化上有明显的题材偏好，先后推出《重生》《重生之门》《庭外》，深耕悬疑；相对而言，爱奇艺的兴趣更集中于剧场化运营，但反向来看，提高用户粘性、实现商业价值等效果是类似的。

而所谓的解题思路，其实就藏在以上这些尝试与布局中。除了常规开发方式，即类似于欧美剧的季播化，在同一背景之下、围绕同一群人持续性展开故事，国产剧系列化呈现出多元玩法。

其中一种是以细分题材形成系列，适合由制作公司主导。比如柠萌，以教育为主话题，打造了包括《小别离》《小舍得》《小欢喜》在内的“小”系列，《二十不惑》《三十而已》《四十正好》则统一被归置为女性系列。

另一种则以作者及其IP为核心展开的“宇宙”，在不同平台及公司的共同推进下，指纹、紫金陈和马伯庸宇宙都在逐渐成型。这个过程中，平台通常扮演着更重要的角色。

尽管这些系列不存在季播剧的延续性，但也在一定程度上放宽了受众面，有利于受众积累及引流。从操作上来讲，对演员档期没那么高要求、不同项目可以同步推进，成功率也相对更高。

经过多年来的探索，从业者们似乎已经形成共识：抛开审查制度下无法边拍边播这点，国产剧仍然很难实现真正意义上的季播，或者说普及这一模式。在这种情况下，国产剧系列化趋势中也出现了细分玩法和选择，可以预见，除了继续等待，观众会看到国产系列剧的更多打开方式。

**话题互动：**

**你觉得为什么国内无法做出成功的系列剧？**

**推荐阅读**

[![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)](http://mp.weixin.qq.com/s?__biz=MzA5NjcxNTIyNg==&mid=2650716963&idx=1&sn=5129b84c1fd3a7fbd7a625c6d0b6657f&chksm=88a1f396bfd67a8044a8ec3b2e99f3450d2186305c36c93e26db5ed4cc0dfea6d541d60717da&scene=21#wechat_redirect)[![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)](http://mp.weixin.qq.com/s?__biz=MzA5NjcxNTIyNg==&mid=2650717064&idx=1&sn=1566f16ca91838023e91ce4ec04b5f00&chksm=88a1f33dbfd67a2bab2ef5e41b3b0cd7728f0888337bd487d9ae311f97e485b6e2b9e58aa4f2&scene=21#wechat_redirect)

**AI绘图取代美术设计师?游戏大厂不同意**

**点击观看**

**↓↓↓**

关注**娱乐资本论视频号**，追料更及时

-

**如需商务合作后台回复【商务】**

**如有转载需求后台回复【转载】**

**更多文娱产业背后的经济逻辑，来关注↓↓↓**