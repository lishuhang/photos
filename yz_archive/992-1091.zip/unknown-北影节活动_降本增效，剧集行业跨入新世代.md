# 北影节活动|降本增效，剧集行业跨入新世代

> 公众号: 娱乐资本论
> 发布时间: 
> 原文链接: https://mp.weixin.qq.com/s/SBOO4Uyxtlg73BbB5gPI5A

---

![图片](http://mmbiz.qpic.cn/mmbiz_jpg/jNZszpkibXx8sN4sTtaOGKTLoLNIAdJQRRg8urCoNL0VviapVvZib6VXwbexiacdYIcQQ9JB55zACrYAhKN7xmn3IA/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)

不知何时起，“降本增效”取代了“影视寒冬”，成了影视行业人最常说起的词。

2022年，影业行业似乎已经开始习惯了行业寒冬对自己带来的冲击，理性的面对行业现状，寻找新的机遇。也是在此之中，“降本增效”成了整个行业的共识。一方面“降本”成了所有人的考验，当钱整体数量变少了的时候，钱花在哪里就变得尤为重要。在此，除了平台及制作公司自身的控制之外，国家也出台了一系列的政策，严格限制了在过去被疯抬的明星片酬及IP价格等。另一方面，“增效”是市场对整个行业提出的更高要求，怎么能够做出广大观众喜欢的内容，而不是一味的去复制“流量”+“大IP”的组合拳，是每一个内容生产人需要探索出来的新路。

针对这一变化，剧集行业在上半年已经有所感知。

自2017年互联网影视进入精品化高速变化状态，台剧与网剧逐渐由同步走向各自领域的垂直，视频平台优势凸显。然而在网剧精品化到一定阶段时，影视内容势必再一次寻求大众化的突破。

今年上半年我们已经可以看见，冬奥题材《冰雪之名》同步六大卫视三大视频网站，制造了体育热潮；头部作品《梦华录》依托优质内容打破圈层，引发全民口碑；现实主义题材电视剧《人世间》，通过网台联动，成功在年轻圈层炸开讨论度，并在全年龄层中引发共振。平台对大众内容的鼓励，也是在力求通过台网共振，将优质影响力最大化。

当传统资源都聚集到了头部项目，中小型项目也在用户侧领域找到了新机遇。去年《突如其来的假期》证明了小的也可以很美，而爱奇艺在2016年首创分账模式，2021年，《少主且慢行》分账破7500万，到了今年，也有《我是赵甲第》分账超7000万。随着分账剧模式的日益成熟，剧集公司也不再完全依赖toB模式，剧集公司通过toC模式的学习和研究，更加精准的找到了用户的审美变迁和独特需求。

面对行业的种种变化，娱乐资本论应第十二届北京国际电影节组委会邀请，承办主题论坛**“降本增效，剧集领域跨入新世代”**。我们邀请了多位行业先驱，与我们一起探讨，在都强调“降本增效”的当下，该如何生产出更好的内容。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

因疫情防控需要，本次活动观众需要提供**48小时内核酸证明及疫苗接种证明**

> 活动形式：线下演讲及对谈
>
> 活动时间：2022年8月16日 13:30-15:30
>
> 报名方式：微信报名，审核通过后即可
>
> 报名微信：13031046324

扫码报名👇👇👇

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)