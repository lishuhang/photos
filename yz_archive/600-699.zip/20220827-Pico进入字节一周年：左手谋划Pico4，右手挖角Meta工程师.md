# Pico进入字节一周年：左手谋划Pico4，右手挖角Meta工程师

> 公众号: 娱乐资本论
> 发布时间: 2022-08-27
> 原文链接: https://mp.weixin.qq.com/s/kqA9ZDB2srtIL_Yv_TOuTA

---

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/jNZszpkibXx8AYBibK1d7piaqISTd2EJ7aSagXzKtRuLFdlKYy0t18ansv5VszdUPIeh5T5Zj8A9hmIfpNPeKM1gw/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)

**作者｜不空**

去年8月29日，Pico创始人周宏伟的一封内部信，证实了字节收购Pico的消息。

有消息称，面对字节和腾讯，Pico之所以选择前者，是因为字节在给出超高收购价的同时，还允诺利用旗下抖音帮助其推广VR，进一步扩大市场声量。

转眼一周年过去，Pico在公共舆论中几乎是无处不在。有消息称，张一鸣本人对VR非常感兴趣，Pico团队也已经从三四百人扩张到了接近1500人。

除了大规模的营销动作，Pico在内容层面几乎全方位对标Oculus——在海外重金合作VR内容，投钱毫不手软；跟国内VR公司也大量合作。

另一边，腾讯收购黑鲨尚未成行，但腾讯内部的XR团队已低调成立，未来可能会形成腾讯、字节两家在VR上PK的竞争格局。

即将在9~10月发布的新品Pico 4和Pico 4 pro，被认为是纳入字节体系以来，Pico要放的一个“大招”。

目前Pico官方没有发布任何关于这款新品的消息，但由于这款新产品也将在欧美发售，美国监管机构FCC近日披露的Pico 4部分技术参数，引发了众多海外媒体的关注。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

人们发现，这款新品在性能上可能出现超越Meta旗下Oculus Quest 2的一系列技术提升——包括：第一次实现彩色透视（戴上VR也可以通过摄像头看到周边环境，且是清晰的彩色画面）；面部识别和眼球追踪（能有效降低眩晕，提升游戏体验）；Pancake光学方案（能大幅降低头盔重量）等等。

另一个被外媒热炒的消息是：7月31日，Meta 前软件工程师Jian Zhang在推特发文表示正式入职Pico的美国团队，并积极招募团队成员。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

Jian Zhang在VR硬件性能方面有过突破性的成就，是渲染技术Application Spacewarp的发明者之一，这项技术帮助Quest 的CPU 和GPU性能提高了70%。

同样在7月底，Meta 取消了对Quest 2的价格补贴——Meta称，由于全球经济下滑导致制造和运输成本上升，从8月1日开始，所有型号的头显产品价格都将上调100美元。

有评论认为，Meta的涨价，无疑给到进击中的Pico一次“弯道超车”的机会。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**技术层面，Pico 4能否超越Quest 2?**

VR行业的老人会这样调侃，VR这行干久了，难免要得颈椎病。原因就是VR头盔的重量并不适合长时间佩戴。

目前的VR设备，用户戴着玩半小时到1小时已经是极限，想要提升用户使用VR的时长，就必须降低VR头盔的重量，并且减少佩戴之后的眩晕感。

在这一方面，行业最前沿的光学方案Pancake，就通过一系列光学提升，大大降低了镜片厚度，从而减轻头盔重量，这一光学方案据称将会应用在Meta的新品Project Cambria上。根据外媒的一系列报道，Pico 4也将使用Pancake的光学方案。

Pico 4将在行业里首次提供“彩色透视”的功能，这意味着，用户戴上VR头盔，依然可以顺畅的通过外部摄像头看到周围的环境画面，并且画面由黑白升级成为了彩色。

一个全新的体验是——Pico 4 Pro将搭载面部识别和眼球追踪功能。

这两项技术一般认为会使用在头像功能上，从而使得VR社交中，人物的3D化身更加真实。此外，眼球追踪还被寄希望于实现一种新的输入方式，并且提供注视点渲染，但这些功能能否真的实现，目前还是未知数。

从使用体验来看，VR还有两大核心指标——屏幕和定位系统。屏幕技术参数保障了画面的清晰度、流畅度，定位系统则关联着游戏的体验感，诸如乒乓球游戏等需要精准操控的应用，就对VR头显的定位系统提出了较高的要求。

从网传的屏幕参数来看，Pico 4无论是分辨率，还是视场角，都将优于Quest 2。

此外，Pico 4采用的“无极瞳距调节”，也将优于目前的Quest 2，将会让用户的视野更加清晰。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

Meta Quest 2 参数；

源自Meta 显示工程师 Cheon Hong Kim 的分享

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

Pico 4 参数；源自外媒

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

Pico Neo 3参数；源自官网数据

在图像定位系统方面，Pico和Quest都使用了图像识别定位系统，但这一系统非常考验算法积累，相较之下，有着更长时间算法积累的 Quest 优势就相对明显。

资深VR玩家阿轩手上拥有Pico Neo 3 和 Quest 2，他认为在定位系统方面，两者还有着较大的差距。“Quest 2的定位系统非常精准，指哪打哪，玩游戏时非常流畅。而 Pico 总是跟指向的位置发生一点偏移，不是偏下，就是偏上。”

这类问题还发生在去抖算法上。“就拿打字为例，Quest 2有指针吸附效果，输入过程的稳定性和准确度非常高。而Pico Neo 3的指针就会飘忽不定，连个wifi都要好久。”

除此之外，作为一款VR一体机，Pico 的串流问题也比较明显。串流是为了解决Pico自身游戏数量少、存储空间少的问题。目前，Pico分为有线串流和无线串流。

有线串流就是通过一条累赘的线连接头显和电脑、电视等其它设备，但是VR头显使用过程中动作幅度大，有线串流这种繁琐的方式遭到了一众玩家的抵制。

而无线串流对网络要求比较高，Pico在无线串流方面存在不稳定、延迟等令人诟病的问题。这些遗憾在Pico 4中能否得到优化，也是用户颇为关注的问题。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**重金“补课” 跳级发展**

尽管在硬件设备方面，Pico 与 Quest 、PlayStation VR（简称“PSVR”）、Valve Index HMD等头显设备之间还存在一定的差距。但是，有赖于字节跳动的雄厚实力，Pico的补课升级之路也比其他选手走得顺畅许多。

为了补齐硬件短板，Pico高薪网罗全球专业人才，积极扩张团队规模，同时也在不断提升技术自研能力，强化VR领域的技术地位。

根据Pico官网数据，Pico有逾300名员工，很多岗位依然在招聘中，这样的规模在VR公司中并不常见。国内爱奇艺的“奇遇”团队目前只有100人左右。

目前，Pico在整体团队布局方面着重强调全球市场，海外团队的筹备是当前的重点。Jian Zhang的加入正是一个重要标志。根据LinkedIn资料显示，Jian Zhang自2016年起涉足VR领域，此前有长达十年的游戏开发经验，在VR游戏方面沉淀了非常成熟的技术和经验。Jian Zhang还有另外一重身份，就是 Meta 前软件工程师。

进入字节跳动之前，Jian Zhang在Meta负责图形和渲染技术、VR SDK、游戏引擎集成和OpenXR等方面的领导工作。

Pico希望Jian Zhang领导组建一个新的XR团队，除了Jian Zhang之外，Pico还在湾区、西雅图、圣地亚哥等地开放了四十多个岗位，这些岗位和一个名为Pico Studios的内容组织有关，包括Pico Studios负责人及其运营经理，还有VR硬件和软件开发的相关岗位，Pico对美国市场的占领决心不容小觑。

此前，Pico的美国团队主要负责企业销售，一直都是低调行事的做派。从今年六月份开始，Pico变得激进起来，调整了美国团队的定位，从企业销售转变为内容开发和本土市场开拓。

除了团队之外，Pico在VR领域的技术自研能力也在不断提升。根据企查查数据显示，Pico母公司北京小鸟看看公司在VR领域的专利数量高达503项，有近一半是实用新型专利。虚拟现实技术、显示器、视觉以及头戴式显示器等专利数量居多。

Pico的高调布局直指 Quest，加之近期Meta旗下产品Facebook、Instagram都被爆出模仿字节跳动的Tiktok，一时之间，两家科技巨头颇有几分剑拔弩张之势。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**内容生态遭遇“围堵”，字节如何带领Pico突围？**

许多国内VR玩家不约而同地表示，如果在Pico和Quest 2之间做出选择，多数人更倾向于选择后者。

问及原因，他们表示，留住用户的始终是内容，Quest 2的内容生态建立得比较完善。

游戏一直是VR产品的主要构成部分，也是许多游戏爱好者选择VR头显的原因。但是，国内VR头显在游戏内容开发方面比较薄弱。“Pico里面的游戏太少了，而且都是小游戏，没有大作。”许多VR用户玩几次就腻了。

根据偲睿咨询的数据显示，截止目前，PicoVR助手中共有205项内容，其中游戏有148款，主要以运动节奏、娱乐竞技和益智休闲为主。

这并不仅仅是Pico存在的问题，爱奇艺、小米、华为等设备在游戏开发方面都存在显著短板。

Pico内容方面的薄弱其实是VR市场“大鱼吃小鱼”的伴生影响。

一方面，头部内容开发者正在被大厂垄断，收购、投资是常见手段，又或者用一纸独家协议绑定双方的合作关系，在大厂面前，Pico的机会本就不多；

另一方面，Quest 2销量已经突破1480万台，Steam上也有千万级的VR玩家，而Pico的销量还在百万量级。因为Pico用户基数比竞品小很多，Pico的独家VR内容收益也不大，开发者的积极性也就不高，这就需要硬件厂商的补贴激励。

而根据媒体统计数据，截止4月底，Quest平台共有357款软件，还打造了《节奏光剑（Beat Cyber）》《半衰期：爱莉克斯》等爆款内容。

其中，《节奏光剑》是一种“切方块”的音乐类游戏，目前全球收入已经超过1亿美金。《节奏光剑》的火热，甚至带红了一系列游戏KOL。抖音账号“VR玩家一号”是国内唯一粉丝量破千万的VR类KOL，不少爆款短视频，均来自《节奏光剑》的游戏体验。

国内头部VR游戏开发商穴居人工作室的《Contractors》登陆Quest之后，营收已超过千万美金。客观的说，目前Pico上还没有任何一款游戏有这样的吸金能力。

如何突破海外大厂的“围堵”，实现内容生态的快速升级，成为Pico的一个重要命题。

自去年年底以来，Pico VR应用商店的内容更新速度开始加快，每个月都有三四款游戏上新。为了不在内容方面落入下风，Pico还购买了大量在Quest 上大获成功的游戏，如《Superhot VR》、《Red Metter》、《Eleven Table Tennis》等游戏。

Pico还在娱乐和视频内容上不断发力。

今年4 月 9 日以来，PICO 已于其平台主办了 3 场直播演唱会，分别邀请王晰、郑钧、汪峰进行演唱。

其中， 7 月 2 日的汪峰VR 乐享会，微博相关词条曝光度已超 1.9 亿，成功实现破圈，让VR 线上演唱会这一形式走进大众视野。郑钧、汪峰的演唱会也均采用 8K 3D 180°VR+ 实时互动的形式，让VR 直播体验大幅提高。

6 月 17 日，A-SOUL 于 Pico 首次开播，区别于其他 VR 直播形式，本次直播场景、主播形象均为虚拟建模，主播通过动作捕捉技术实现互动。本次直播共吸引超 8000 人报名观看，报名人数超汪峰 VR 直播演唱会。

兰亭数字董事长兼CEO 孙文博表示，Meta在视频上没有很好，而字节在视频上投入很大，抖音本来生态就很好，因此在他看来，视频或许是Pico弯道超车的机会和布局点。

---

在VRChat里虚拟社交是什么体验？

SNH48的粉丝现在都用VR追星？《节奏光剑》凭什么火爆全球？

长按扫码预约直播，

你不知道的VR新玩法，就在直播间。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**话题互动：**

**说说你的VR体验吧。**

**推荐阅读**

[![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)](http://mp.weixin.qq.com/s?__biz=MzA5NjcxNTIyNg==&mid=2650713734&idx=1&sn=f88b661d017126b3783417266d3e5707&chksm=88a1e633bfd66f25d9a47c1c16aca71529ed62b5f5811869cc37f16792293e32847b7e3f93a5&scene=21#wechat_redirect)[![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)](http://mp.weixin.qq.com/s?__biz=MzA5NjcxNTIyNg==&mid=2650713564&idx=1&sn=36cd9f014bfb346b1e2b78fda4480f3a&chksm=88a1e569bfd66c7f160cd9fbfa27e9b63c806bf49da8044b9216c16544e60abbe81ebffb3298&scene=21#wechat_redirect)

**《明日战记》是怎么演变成一场网络骂战的？**

**点击观看**

**↓↓↓**

关注**娱乐资本论视频号**，追料更及时

-

**如需商务合作后台回复【商务】**

**如有转载需求后台回复【转载】**

**更多文娱产业背后的经济逻辑，来关注↓↓↓**

‍

‍
