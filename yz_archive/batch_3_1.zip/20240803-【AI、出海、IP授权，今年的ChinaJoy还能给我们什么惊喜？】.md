# AI、出海、IP授权，今年的ChinaJoy还能给我们什么惊喜？

> 公众号: 娱乐资本论
> 发布时间: 2024年8月3日 13:39
> 原文链接: https://mp.weixin.qq.com/s/7_XsLhk-OHYzomv5XjqPJQ

---

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd73RmjEPibGBwESxhlM6AcZQm5Q8BeGkZhOzkD71muQT4tm8yPdTocH9tDgTyG534opIVXK12r0r1g/640?wx_fmt=jpeg&from=appmsg#imgIndex=0)

**作者|吴晓宇**

“今年你来CJ了吗？”

“来了，不过今年没什么想看的，还是见见朋友。”

“我今年都没来，还有别的事情，脱不开身。”

“过两天我得去，不过是谈业务去的，回来约饭！”

一年一度的ChinaJoy结束了。根据ChinaJoy官方发布的数字，**2024ChinaJoy观众参观人次36.7万，相比2023年的33.8万实现了大幅提升**。参考今年线下活动市场的热络程度，ChinaJoy能够吸引如此之多的观众入场并不奇怪。不过，这个数字还是创造了近十年来ChinaJoy入场人次新高。

对于身处游戏行业之中的人们来说，ChinaJoy的影响力却在经历着剧烈的震荡。有些人参加ChinaJoy已经成为了习惯。无论展会中有着怎样的内容，他们都会来凑个热闹。还有些从业者已经渐渐远离了ChinaJoy，项目上也都有更多更重要的事去做。

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd73RmjEPibGBwESxhlM6AcZQiaz3xmeKHqXZS6Y4mQsllwyNgkPI3UVxfmSq1qkJvT25VYFic6LqhmtQ/640?wx_fmt=jpeg#imgIndex=1)PlayStation展台

游戏厂商们的心态似乎也是如此。**腾讯、网易、西山居、巨人和世纪华通，这些从端游起家的游戏大厂如约而至**。只参加了一次ChinaJoy的米哈游又再次缺席，毕竟半个月后它们还要在上海举办第二届原神嘉年华。

通过四天的逛展后，小娱观察到了一些有趣的行业现象。其中，**ChinaJoy的商务属性逐渐回归，透过展会活动进行招商的企业越来越多，侧面可以证明行业的信心正在回升**。许多小团队的独立游戏选择到ChinaJoy现场参展，希望得到发行商的青睐。

AI和出海仍是今年ChinaJoy的热门话题。同时，IP授权也逐渐成为ChinaJoy展会中不可忽视的一部分。 

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6F6Y83LIszsXQfh29diaibTr3TeAhEqwPmVIbTLr28yAn6FmQQNdkUeBcoWGHia8WCTglcRCuWTXjUg/640?wx_fmt=png&from=appmsg#imgIndex=2)

**传统大厂仍在坚守，展会回归商业属性**

ChinaJoy举办的20年间，参展厂商的阵容总是变来变去。**大浪淘沙之下，端游时代成长起来的游戏厂商似乎已经变成了ChinaJoy的坚守者**。腾讯、网易、西山居、巨人和世纪华通，这一系列端游时代响当当的名字现在依然是ChinaJoy的门面。

今年ChinaJoy最大的两个展台依旧属于腾讯和网易两家。相比前两年的ChinaJoy，**腾讯和网易宣传的重点也更加明确**。

**腾讯展台中，《三角洲行动》和《地下城与勇士：起源》是他们重点展示的两款游戏。**《三角洲行动》此前已经进行了几轮测试，在玩家群体和行业媒体中的口碑不错。《地下城与勇士：起源》则是今年上半年腾讯游戏重要的收入来源。腾讯在ChinaJoy力推这两款游戏也是合情合理的。

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd73RmjEPibGBwESxhlM6AcZQVyo8tI3hpLP3h60MsrQjBV1EZJiaQCtLoElUsNQIdDvW9DaPxusibiaiaw/640?wx_fmt=jpeg#imgIndex=3)《三角洲行动》展台

和腾讯的情况不同，**网易今年占据了比较大的展台，主要是为了庆祝暴雪回归。**在ChinaJoy现场，暴雪宣布《炉石传说》即将于9月25日回归。玩家只要登陆游戏的账号，即可获得2023年错过的所有炉石卡牌。另外，暴雪还给《炉石传说》准备了中国风卡背、幸运币皮肤以及一系列回归活动。除此之外，《蛋仔派对》《永劫无间手游》和《逆水寒》系列游戏是网易重点展示的游戏。

最近两年，**许多出海企业调整了自己的发行方向，把海外市场已经验证过的游戏拿回国内市场运营**，都取得了不错的效果。一些大厂的缺席给了这些游戏公司展示自己的舞台。

来自上海的益世界就是一家比较典型的国内市场和海外市场并重的公司。去年8月，日式RPG《异世界慢生活》在海外上线，并在欧美市场取得了不错的流水成绩。此前，《异世界慢生活》刚刚获得了版号，益世界就把这款游戏带到了ChinaJoy进行展示。

类似的情况同样发生在世纪华通集团下属的点点互动的身上。

2023年，点点互动开发的冰雪末日题材SLG游戏《无尽冬日》在全球上线。根据Sensor Tower数据显示，**《无尽冬日》一年时间内购收入突破5亿美元大关。**

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd73RmjEPibGBwESxhlM6AcZQAcN6CeIjxzHKRqFMTdv0bM3tDsS3Xovyib1cz86XiaRQ3KuSv7hYxBzQ/640?wx_fmt=jpeg#imgIndex=4)《无尽冬日》展台

今年5月，《无尽冬日》进入国内市场，主要在小程序端发力。此次ChinaJoy中，世纪华通为《无尽冬日》设置了专门的展台，自然是希望将这款游戏的热度推向新的高度。

观众参观人次创下新高，但**许多行业人士认为ChinaJoy的商务属性在逐渐加强。**小娱和多家参展企业进行了交流。这些厂商很明确地表示，他们参加ChinaJoy的核心目标就是来寻找新的商业合作伙伴，顺便让自己的产品接受玩家的检验。

而**在ToB展区中，游戏已经不再是厂商们洽谈的唯一业务**。一些公司经营着出海的流量业务。恰逢今年短剧成为了行业的焦点，这些公司开始把自己的业务扩展到短剧领域。**HeatShort和美团都把自己展位更多的展示区域留给了短剧。**

美团告诉小娱，他们已经在自己的App端上线了大量的短剧、有声小说和小游戏，这些业态都能帮助他们提升用户的停留时长。

[今年的ChinaJoy还举办了专门的短剧创新论坛，娱乐资本论作为本次论坛合作伙伴深度参与，论坛成功召开。](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247640399&idx=2&sn=d7f2cc5b38dff84851df496b33112206&chksm=c057b094f7203982df4e5506636755a2446f30def91d17f0d716e85b2f3fa5a6018ba86e53da&scene=21#wechat_redirect)活动围绕“短剧”的相关主题，**邀请了来自短剧、游戏、技术科技、视频平台等多个领域的30多位权威嘉宾和业内精英，展开了关于短剧发展方向的讨论。**

另外，**To B展区中出现了大量独立游戏展位**。这些独立游戏搭车ChinaJoy，就是希望借助展会的影响力找到发行商或者投资方。这种情况在过去几年是不敢想象的。

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd73RmjEPibGBwESxhlM6AcZQPXop5Sfl9Mp9Pp7PAo0JChDovdUcWcmsibFicdn8svKpyLy0ico9WZpBA/640?wx_fmt=png&from=appmsg#imgIndex=5)AI作图   by娱乐资本论

小娱这几年接触了很多开发者，他们往往采取了独狼创作模式，2-3个人就能攒起一个独立游戏团队，业余时间也能实现游戏开发。现在，ChinaJoy给了这些开发者把游戏落地甚至带给更广泛玩家群体的机会。今后ChinaJoy或许会有更多类似的独游生态。

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6F6Y83LIszsXQfh29diaibTr22R5h68ra6cKETkiaMiac8OxkOc6r74Zqicw4rVbKCVjrFkL2RRQq5gNQ/640?wx_fmt=png&from=appmsg#imgIndex=6)

**游戏产业AI落地加速，出海服务商不断增加**

过去半年，游戏行业中有一种论调。那就是AI在游戏领域的应用和落地进展缓慢。然而，来到ChinaJoy你会发现，**AI依旧是行业内最热的话题。**

ChinaJoy的E7馆和E4馆汇集了大量的游戏配件厂商和智能手机厂商的展位。走进这两个展馆，几乎每一家厂商都在主打AI概念。

**AMD在ChinaJoy现场发布了锐龙AI 300系列处理器**。联想、华硕、宏基和微星都推出了搭载AI 300系列处理器的产品。AMD表示，AI 300系列处理器最为重要的能力就是移动端算力达到了50TOPS，这为生成式AI工作带来了极大的加持。

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd73RmjEPibGBwESxhlM6AcZQWXTkHlVmiaZ99kmegpZZorkCApVuMqObak1b2SC0AZHgzSbLcmib5YIw/640?wx_fmt=jpeg#imgIndex=7)AMD发布华硕AI PC新品（图源：AMD中国官方微博）

AI如果想要在游戏产业中发挥作用，更关键的一点还是要接触玩家。网易算是参展厂商中在AIGC技术层面研发比较深入的一家公司。

网易在ChinaJoy官方的AIGC论坛中表示，**AI的出现，给他们带来了新的思路——通过把AI“开源”给玩家，让玩家更好地融入整个游戏的生态系统、形成良性的反馈机制，也扩充了UGC内容板块。**这一点在《蛋仔派对》得到了充分的应用。

根据网易方面的介绍，以UGC内容创作见长的《蛋仔派对》中，他们正在通过AIGC吸引、帮助更多玩家，完成从参与创作、到爱上创作、精于创作的“进阶”过程。其中，基于AIGC打造的乐园地图“万能生成器”已被5300万玩家所使用。

除了UGC内容之外，**网易还挖掘出AI在游戏助手和陪玩层面的新应用**。在骁龙主题馆中，骁龙联合了网易24工作室和伏羲实验室，一同展示了《永劫无间手游》中的AI助手。《永劫无间手游》AI助手可以识别玩家的语音指令，并且与玩家实时进行交流。

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd73RmjEPibGBwESxhlM6AcZQibJsEPFEYlKYP591WxAnHicvnDjL20JCNHXQNmGqECRTyhZmtbOkaS2A/640?wx_fmt=jpeg#imgIndex=8)现场玩家试玩《永劫无间手游》（图源：高通官方微博）

游戏中，AI助手还可以帮助玩家进行打团、当诱饵和撤退掩护等一系列帮助。这一技术早前已经被运用到了《逆水寒手游》中，随后网易还会将其引入到一系列SLG游戏中。

**AI助手和AI陪玩在玩家群体中大部分时间收获的是好评**。不过，对于SLG游戏这种强烈依靠大R，依靠指挥感驱动的游戏，AI陪玩或许会产生一定的争议。娱乐资本论之后还会进行AI陪玩的相关报道，感兴趣的玩家可以在评论区留言，交流您的看法。

**出海则是游戏行业中另一条火热的赛道**。服务出海企业的公司是今年参展ChinaJoy的主力军之一。

时间往回推几年，Facebook和谷歌都是ChinaJoy的常客。游戏出海还不热络的年代，海外的广告巨头在国内市场有着充分的施展空间。然而，人们无法预估市场的变化速度，就像没有人能猜到TikTok能够成为海外游戏推广的重要阵地。ChinaJoy的展馆内，人们也找不到Facebook和谷歌的踪影了。

**今年，ToB展区中推广支付合规的企业在逐渐增多**。游戏在海外运营的过程中，稳定高效地接收多渠道收款成为了厂商们的一大痛点。于是，Paypal、贝付和Skypay成为了ToB展区中洽谈业务比较多的展台。

另外，一款游戏如果想要在海外推广，免不了需要在海外寻找网络红人或者KOL进行推广。今年的ChinaJoy中，小娱也见到了多家海外红人的营销服务商。他们告诉小娱，**现在YouTube、Twitch和TikTok的红人能够影响一款游戏的破圈程度**。这些红人拍摄的广告或者视频中插的推荐能够迅速触达游戏受众以外的人群。

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6F6Y83LIszsXQfh29diaibTrSehp43ribpQjVk5Jlod5NKE3rr828WF1U3ONJvMm3nxR6rmibFJXyLSQ/640?wx_fmt=png&from=appmsg#imgIndex=9)

**线下谷店“入侵”CJ，游戏公司也要做快消品**

ChinaJoy向来不缺少售卖周边的参展商和企业。不过这两年，**IP授权公司的参展面积越来越大，参展公司数量也远超过去的寥寥数家。**在这些拥有IP授权业务的公司中，人们也极易发现IP授权领域的新业态和新趋势。

[线下谷店无疑是今年消费赛道中的热点](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247640538&idx=1&sn=7ac6128b1defd4fd77c62a44c58351bd&chksm=c057b001f7203917b733df210d80c43487da0b6b1542674be885d8f603ab0f7b32d580a85362&scene=21#wechat_redirect)。单单是今年上半年，全国各个城市新开了近百家谷店。谷店的兴起带火了北京、上海、广州、成都和天津的多个商圈。其中，百联ZX是全国以谷店为基础的商圈中最为出名的一个。

ChinaJoy的E5展馆，**三月兽、模玩熊、天闻角川等一系列动漫周边公司都设置了展位**。有意思的是，这些公司也都在上海百联ZX拥有线下实体店。可以说，这些公司把ChinaJoy现场变成了一个小型的百联ZX。

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd73RmjEPibGBwESxhlM6AcZQzJOy1ibRF57icUHeE77fFU86sVicv8WvwBkXeia926VFFsKExUr3dVjRxw/640?wx_fmt=jpeg#imgIndex=10)天闻角川展台（图源：天闻角川官方微博）

小娱与这些动漫周边公司的工作人员交流时发现，**线下谷店的生意并没有那么好做，IP仍然是一切的核心**。线下考察百联ZX，上述观点得到了验证。《全职高手》《排球少年》和《蓝色禁区》等部分热门IP占据了各家店铺的主要位置。商品同质化不可避免，但似乎只有这样才能维持一个可观的收入。

另外，小娱还在ChinaJoy现场遇到了一家经营仓储式折扣店的项目负责人。这位项目负责人向小娱透露，他们的店铺不像好特卖或者BIGOFFS一样售卖食品饮料或者服装，而是各类手办、卡牌和玩具等动漫周边产品。**利用自身的渠道优势，这家仓储式折扣店可以把诸多品类的动漫周边价格打下来**。或许随着线下谷店的发展逐渐深入，类似的新业态还会不断涌现。

星巴克、上好佳、康师傅、三得利、悸动（新茶饮）等快消品品牌今年在ChinaJoy有了自己的展位。这些企业参加ChinaJoy，**除了可以向外界展示他们的衍生品和联动业务，也能和游戏厂商们直接洽谈IP联动**。

与此同时，许多游戏公司也在探索IP衍生品甚至是新的快消品业务。比如巨人网络去年与武康大楼联合打造了脑白金+咖啡快闪店，为期一个月。今年，巨人把脑白金+cafe搬到了ChinaJoy现场。小娱在现场品尝了脑白金咖啡，薄荷、梅子与咖啡混合的味道意外地不错。

**观众回归，商务属性回归，应该是一个游戏展会的最佳状态**。当下的中国游戏产业，信心比什么都重要。2024年的ChinaJoy，或许是行业对外释放这种信心的最好契机。

**话题互动：**

**你今年参加ChinaJoy了吗？**

**推荐阅读**

[![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd5DSjage4O8SR5cmYDbvlibrQkF1TsJKfU6ibQIXEq1px1k6YPHe3sRPKdfaXBxE4jRJHD53e01QJsg/640?wx_fmt=jpeg&from=appmsg&tp=wxpic&wxfrom=5&wx_lazy=1&wx_co=1#imgIndex=11)](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247640538&idx=1&sn=7ac6128b1defd4fd77c62a44c58351bd&chksm=c057b001f7203917b733df210d80c43487da0b6b1542674be885d8f603ab0f7b32d580a85362&scene=21#wechat_redirect)

[![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd5DSjage4O8SR5cmYDbvlibrgmvA1nDxPo95xOGbXaN8eTHfK9EnWdXW95nPAqwoLJKRQj7mdd9URw/640?wx_fmt=jpeg&from=appmsg&tp=wxpic&wxfrom=5&wx_lazy=1&wx_co=1#imgIndex=12)](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247640279&idx=1&sn=01e369a959e05594d8d337cdf67a185a&chksm=c057b10cf720381a4b35650f4191e061cf56f4db45a529c3c033d8c7cfa6caeec85e5fe34fea&scene=21#wechat_redirect)

**我们用《抓娃娃》拍了部中式恐怖片**

**点击观看**

**↓↓↓**

**如需商务合作后台回复【商务】**

**如有转载需求后台回复【转载】**

**更多文娱产业背后的经济逻辑，来关注↓↓↓**

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd6F6Y83LIszsXQfh29diaibTrLpWA6mYU7OBCKOiaScSWhmy5Xo4hoPAIlAvDPSfdicEHvOzZCEY4boJw/640?wx_fmt=jpeg&from=appmsg&wxfrom=13&wx_lazy=1&wx_co=1&tp=wxpic#imgIndex=13)
