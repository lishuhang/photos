# 万圣节玩具在Tiktok上“爆单”，Tiktok Shop的机会真的来了？

> 公众号: 娱乐资本论
> 发布时间: 2022-10-31
> 原文链接: https://mp.weixin.qq.com/s/c5QNsNar6YuxjJ4HOKGrMQ

---

![](https://mmbiz.qpic.cn/mmbiz_png/jNZszpkibXx9fK5DxyTD7AyeFpFRtOjibtXBxHxv9ibzVMWibiaric81WOFUJLW0R1iabhKNBDSeVExetG9DF1zviaEjew/640?wx_fmt=png)**作者|不空**

“这个万圣节，我买到的最棒的礼物就是这个南瓜玩具！”

19岁的英国小伙Raj在Tiktok中提到的南瓜玩具是一个做成南瓜形状的玩具灯，开灯之后，五彩斑斓的灯光巧妙地响应了节日的热烈气氛。

![](https://mmbiz.qpic.cn/mmbiz_png/HKEDX7MqXK1hHOOCkTkOxbmFwhUiaeBcFCs32UUibzdcwp777iak1yLFLLRJaXKsv0LpCcGrhzV2v0hqiao3A7qqpg/640?wx_fmt=png)

在短视频中，他进一步解释道，自己是平时在刷Tiktok时看到了义乌的一个商家的视频，视频展示了各种各样不同的玩具，他一眼看中了这个南瓜灯并决定买来作为自己的万圣节礼物。

除了这款南瓜灯，在万圣节的氛围烘托之下，一款人皮面具在Tiktok也得到了不少年轻人的喜爱。

这款人皮面具的厂家正是来自义乌。义乌作为全球最大的小商品批发市场，拥有丰富的商品品类和发达的市场链，囊括链工艺品、饰品、日用百货、电子电器等所有日用工业品。这些品类正好切中链Tiktok用户的需求，而拥有10亿月活的Tiktok为这些小商品提供了蓝海市场。

剁主整理了Tiktok七月份至今的爆品数据，从数据中可以发现，个护、饰品、百货等品类成为了Tiktok上最受欢迎的商品。

![](https://mmbiz.qpic.cn/mmbiz_jpg/HKEDX7MqXK1hHOOCkTkOxbmFwhUiaeBcFsV4CvoPeYGq8cBmeS3bVLhoOIGOFGpBWLWjOdMeYKuUMLF82l93CibA/640?wx_fmt=jpeg)

Tiktok为何偏爱小商品呢？这些小商品又是如何在Tiktok上面掀起风暴的呢？

![](https://mmbiz.qpic.cn/mmbiz_png/jNZszpkibXx8r0eeusveAtyj98pKeBEz7tMuAmiadsyvAk4l30TZvmgP03RGX0iaosuL5yVawsdblYqeWUcOTHYoQ/640?wx_fmt=png)**这些商品在Tiktok上悄悄卖爆了**

“创意类的新奇特商品和低客单的家居用品在Tiktok上面还是有很大的机会。”Han River CEO林泽建如是道。

Han River是一家出海小家电品牌，长期深耕东南亚市场，近期获得了星迈黎亚集团数千万人民币融资。不久前，Han River旗下一款空气炸锅在Tiktok上获得了不错的反馈，尤其在印尼市场上的销售额排名位居前列。

Tiktok作为兴趣电商，背后精准推荐的算法机制是吸引众多小商品以及新品牌入驻的重要原因。“传统电商获客方式主要通过搜索渠道，曝光和增长都非常慢，但是Tiktok可以在直播和视频中展示，并且通过算法推送到精准的客户群中，因此在新品推广方面是非常有帮助的。”

“Tiktok在选品方面比较侧重单价低、外观和功能新颖的商品去做。个护类的电器，像吹风机、卷发棒、直发夹这类商品就属于第一梯队，而厨房类的电器由于客单价会比较高，因此排在第二梯队。”剁主对比了2022年第三季度Tiktok Shop英国、印尼、泰国等主要市场直播品类销售额的占比情况，数据也侧面印证了林泽建的这一论断。

![](https://mmbiz.qpic.cn/mmbiz_jpg/HKEDX7MqXK1hHOOCkTkOxbmFwhUiaeBcFpFTWCdhhLiblzoz9OfRpTPKKHFhG3cxrKQqhcXt8IT3eOMuU0wOhCvg/640?wx_fmt=jpeg)

结合上文中的两个表格可以总结出Tiktok爆品的几类趋势：

其一，新奇特产品在Tiktok上受到追捧，“新奇特类的产品非常好传播，很容易产生裂变的传播效应。因为可以结合产品制作一些幽默、搞笑类的视频。”梯拓跨境电商市场部负责人吴培鑫向剁主解释了产生这一趋势的原因。

@kl\_cool\_gadgets就非常擅长使用诙谐、幽默的视频风格推广商品，该账号的内容以测评新奇特小商品为主，具有强产品展示属性。目前，该账号已经拥有18万粉丝。在介绍一款婴儿洗发帽时，几个婴儿在洗头时状况频出的场景展示出家长为婴儿洗头的种种不便，为产品做出了很好的铺垫，接着再佩戴上婴儿洗发帽进行使用，强烈的对比之下，简单直白地介绍出了产品功能，在评论区就引发了粉丝的回应。

其二，客单价低的日用百货如大容量水杯也有很强的爆款潜力，尤其是在东南亚市场上。“相对于欧美市场，东南亚市场对于价格会更加敏感，低客单价的生活必需品更容易跑通。”

![](https://mmbiz.qpic.cn/mmbiz_jpg/HKEDX7MqXK1hHOOCkTkOxbmFwhUiaeBcFn7PEGHXbib5nUP4HeFcyPLVWXpfvMsxSBxAMoTSAX4fweZdZicibDUahg/640?wx_fmt=jpeg)

林泽建结合在东南亚市场的多年经验，也同样表示，与高客单价的商品相比，低客单价的商品在转化率方面表现得更为优异。同时，林泽建补充道，低客单价的商品成本并不是很高，但却很容易做出销量高达几千万的爆款产品。不少跨境电商都认为，中国，尤其是义乌的小商品价格优势明显，成本也会更低。

其三，卷发器、肩颈按摩仪等小电器的需求开始上涨，尤其在英国市场表现比较明显。跨境女装品牌Go.G.G市场负责人Aria对剁主透露，今年英国在Tiktok上的大爆款当属肩颈按摩仪，“虽然肩部按摩仪在国内已经十分畅销了，也并不罕见，但在发达国家市场就不太容易买到，就算有，在价格方面也比较贵。”这就给了国内小家电品牌很大的机会，“一些跨境品牌卖的肩颈按摩仪价格也就小几十磅，又非常实用，因此在Tiktok上就很火爆。”

![](https://mmbiz.qpic.cn/mmbiz_png/jNZszpkibXx8r0eeusveAtyj98pKeBEz7ejDSZf97dAE3mMYqSpwDp0blV0YsOONibSOjLz8EycRV8uxj7xc8QIg/640?wx_fmt=png)**选品准+内容准+推广准=爆单**

“选品，选品，还是选品！”

在某跨境电商脑暴会上，分享人多次强调选品的重要性。Aria也对剁主表示，“Tiktok平台内的生态还是比较活跃的，用户也逐渐培养出了在Tiktok Shop中消费的习惯。但是如果想让用户掏钱，选准产品是非常关键的一点，最关键的是挖掘到符合用户需求的产品。”

Yitao House是今年英国市场上卷发器这一爆款单品的推手，而爆款的诞生就离不开Yitao团队在选品方面的精准。头发护理在英国市场上的需求一直都很旺盛，因为英国消费者非常注重美发保养，同时，Yitao还发现卷发棒、直发架等产品在传统销售渠道上就有着稳定的数据表现。综合考量之下，Yitao认为，只要在线上渠道上能找到凸显性价比的产品就能提升爆款的概率。

找到货源之后，Yitao开始了大力推广，并且收获了亮眼的成绩。五月份，Yitao单日最高GMV近4万英镑。

找到切中用户需求的产品之后，内容的打磨也十分关键。在这一方面，Aria特别提到，“国内电商的经验确实会给Tiktok电商一些思路和范本，但是一定不能照搬照抄。很多时候把国内爆款的经验复制到海外不一定能成功。”

国内爆款内容在传播上具有鲜明的视觉特征，以抖音为例，抖音上大部分的爆款视频都会叠加滤镜，提升观看体验。这种方式在国内已经得到了很好的验证，并且取得了不错的转化效果。但是，“这一招在Tiktok上往往行不通”，Aria就在这上面踩过坑，“很多用户并不喜欢包装出来的东西，反而更喜欢最真实的，具有原生态感觉的东西。”

Han River也有着相同的体会，“按照国内的审美去制作的精美视频有可能得不到流量的认可，”因此，林泽建的内容制作团队招聘的都是当地具有社交平台经验的人才，这样才能在内容方面符合当地的思维和审美习惯。

Aria在复盘Go.G.G今年的爆款女装马甲时表示，视频内容非常直接明了地展示出了马甲的样式、版型以及穿搭建议，直奔主题的视频风格更受用户喜欢。因此，即便这件商品在单价上略高，在销售成绩上却很好。“到现在，售出了近三万件，基本全网的网红都在带我们的货。”

![](https://mmbiz.qpic.cn/mmbiz_png/HKEDX7MqXK1hHOOCkTkOxbmFwhUiaeBcFOQibngicUormRIj95LVQz61iakyD2tia7L4CApOhSsicD6lqHWKWvuz70KA/640?wx_fmt=png)

真实、原生态的内容还会增强用户对商品的信任。一些义乌商家甚至直接展示生产环境、产品包装等环节，借此来吸引用户。

@1mistore\_eduardo是义乌一米供应链管理服务有限公司在Tiktok上开设的西语带货账号，主播带着镜头直击生产、包装、物流现场，还原商品生产环境。这种方式不仅能增强用户对品牌的信任，吴培鑫透露，这类视频还能够推动与小B类客户的合作。

![](https://mmbiz.qpic.cn/mmbiz_png/HKEDX7MqXK1hHOOCkTkOxbmFwhUiaeBcF1rqYuIAZIJkadMfgnRfQqmiaeB9EcmStdY6eUklDWspKJYSmsic5JZ3Q/640?wx_fmt=png)

不少跨境电商都表示，和国内相比，Tiktok上获取流量的成本要低很多，主要包括达人的费用、广告费用以及寄出的样品费用。林泽建透露，印尼市场上网红合作的价格并不高，粉丝数量比较少的网红可以以商品置换的形式进行免费推广，头部的网红价格今年虽然上涨了，但价格也在一两万人民币左右。

Aria则表示英国整体要偏贵一些，此前他们做的联合直播活动，头部网红的价格要在1500-2000英镑起，这就需要在筛选合作网红时多下功夫。

口腔护理品牌MeToo在短短三个月就成为印尼线上销量第一的漱口水品牌，在Tiktok上线一周，就成为了排名前三的产品。CEO David表示，他们将网红分为S、A、B三类，中腰部网红采取纯佣合作的模式，从中筛选数据表现好、触达精准的S类网红。对于S类网红，就可以采取包月合作的模式，建立合作关系。

![](https://mmbiz.qpic.cn/mmbiz_png/jNZszpkibXx8r0eeusveAtyj98pKeBEz7gMbSIRF8ujdpJibC3CLgiaEEY6kJq4YuKUC4cv1ZG4kjEVEHhs35Zn3Q/640?wx_fmt=png)**小商品里还藏了哪些机会？**

“Tiktok现在非常适合入场，不论是产品侧还是平台侧都还有潜在的机会。”

较早入局Tiktok的Han River在总结过往经验时特别提出了供应链的重要性，“因为一旦出现爆款就会对供应链产生比较大的压力，因此，本地的备货库存一定是要准备好的。”在全球供应链都面临危机的情况之下，为了能够及时应对爆单的情况，林泽建认为商家可以在本地寻找供应链和分销商。

林泽建进一步表示，商家在有能力的前提下，可以进行品牌化升级，实现品牌优势。有了品牌加持之后，商家可以将线上和线下渠道进行打通。

MeToo就通过“两步走”的策略，加速实现了品牌化道路。David表示，在MeToo的发展规划中，团队计划用3-5个月借助Tiktok打通线上渠道，打造爆款单品。借力线上渠道的口碑进一步扩展线下渠道。

通过和印尼线下的连锁便利店进行合作，MeToo从九月就开始进行线下大规模铺货，计划在第四季度入驻3万家线下店。

![](https://mmbiz.qpic.cn/mmbiz_png/HKEDX7MqXK1hHOOCkTkOxbmFwhUiaeBcFEPxIibwFHhBfs5Jjp817qv4nYBAhLhjicibfNicwj75zWMiaB2xkxRGRPBw/640?wx_fmt=png)

在平台端，Tiktok也在不断完善跨境业务服务功能。埃森哲预计，2025年，全球社交电商规模将达1.2万亿美元，其中，直播电商是社交电商中增长最快的交易形式，海外直播电商年增速更是高达70%。

Tiktok Shop跨境电商品牌策略高级经理Jen介绍，Tiktok Shop在全力打通人、货、场，提供全要素解决方案。

在“人”方面，Tiktok Shop完善流量分发算法，一场直播或一个短视频能触达同一语言和文化圈的全部受众，实现最小成本覆盖最大范围的市场。服饰类的标杆品牌PatPat最开始集中在英国市场，但是在直播过程中，Tiktok Shop算法机制将内容也同时推送到了东南亚用户群体中间，帮助PatPat逐渐打开了东南亚的市场。

作为跨境交易，“货”是困扰商家的重要问题，库存、语言、货币等问题都令不少商家对跨境交易望而却步。Tiktok Shop开设了统一商家账号登录后台，可以进行本地化语言和货币自动匹配，帮助商家实时掌控库存量。

而在“场”方面，Tiktok Shop也逐步完善商家自播、国内代播和海外代播三种内容生产方式，推动内容制作流程的升级。

除此之外，Tiktok Shop官方也在通过多种补贴政策减轻商家的压力。今年，Tiktok Shop推出双月激励计划，主要针对英国站跨境卖家。9、10月份推出了满10英镑减4英镑的活动，适用于入驻的所有商家。在节日大促期间，Tiktok Shop也推出了满30英镑减5英镑的活动。

Tiktok电商正在加速发展，不论是商家还是品牌都需要抓住机遇窗口，趁上东风。
