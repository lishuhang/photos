# 假扮俄人成变现密码，真俄人为何吃不上红利？

> 公众号: 娱乐资本论
> 发布时间: 
> 原文链接: https://mp.weixin.qq.com/s/BmzoLTKzJ328MoB42xeSxw

---

![图片](http://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd4Hh2VnbvaiaUS1VqFkK2DLKtAakf1iaOwPagjRRfGKicZlxHRjG06iblYiae4jN36QOblIe7CZnPkiaZibA/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)

**作者 | 毛丽娜**

“俄罗斯人”正在成为中国互联网财富密码。

2023年第一神曲《爱如火》演唱者那艺娜，曾顶着“俄罗斯娜娜”的名字，靠着滤镜假扮俄罗斯人，在短视频平台积蓄起原始粉丝。大概中国网民对俄罗斯有种天然好感，游戏营销也在借力“俄罗斯”的东风，《原子之心》能在Steam排行榜拿下第七名，正因为它made in Russia。

![图片](http://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd4Hh2VnbvaiaUS1VqFkK2DLKq0JhNESG3icUhOVn8zhqF9RL1pCT9GBZFuUGibsibF24OnLAryDt8Hu6Q/640?wx_fmt=png&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=1)

有意思的是，国人靠着“假扮俄罗斯人”“撬动精俄/精苏情绪”赚得盆满钵满。而货真价实的俄罗斯人，这几年在中国社交媒体开设账号的也不少。但小娱通过实际采访俄罗斯本土民众发现，其实他们却很难吃到这份红利.

一方面，这些俄罗斯本地博主空有逆天毛式审美，却不知道中国网友真正想看的是什么。兴冲冲抱着靠内容养活自己念头的俄罗斯小伙，注册中国社交媒体账号后，为过山车式的播放量所困，时常陷入自我怀疑的漩涡。

另一方面，俄罗斯内部有着隐秘的鄙视链，大城市出身，见识更广、内容更优质的俄罗斯本地博主更希冀得到的是欧洲网友而非中国网友的认可。他们在YouTube上更新视频，内容更讨好西方人的偏好，直接搬运到中国平台，多数会出现水土不服的现象。

这些因素糅合在一起，造成了这种李逵不如李鬼的怪现象。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**俄罗斯营销术，有几种打法**

提到俄罗斯网红，伏拉夫绝对是标杆人物。这位2016年毕业于北京语言大学的俄罗斯小伙，还不到30岁，就已经在中国过上了有房有车的生活。他的走红路径，也是俄罗斯营销密码中最基础，也是应用范围最广的打法。

以现在的眼光来看，伏拉夫的走红有几分粗粝的味道，内容本身并无多少干货，只是从头到尾重复着“中国太棒了”“我爱中国”，但这种刘姥姥进大观园式的表演，恰好迎合了网友某种隐秘的、试图从外部世界证明中国日益强盛的心理，于是伏拉夫迅速走红，即使现在他的流量已经大幅下滑，但当年的红利仍旧够他在中国过上不错的生活。

也正是他，让许多中国网民陷入对俄罗斯人的“美丽误会”，认为每个俄罗斯人都像伏拉夫一样热爱中国。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

伏拉夫的走红模板，为后续的俄罗斯网红们打了个样，更让这种“美丽的误会”进一步加深。在抖音上，除去坐拥600多万粉丝的官方账号“俄罗斯驻华大使馆”以外，其余粉丝能过百万的俄罗斯博主，内容与几年前的伏拉夫并无太大区别：赞美中国地大物博、感慨能生活在中国有多幸运、最后还不忘呼吁中俄一家亲，老铁们点点小黄车下单。

当然，这种单纯夸中国的内容并不具备太多独特性，不独俄罗斯人，其他老外也可以效仿。于是有“俄罗斯博主”在这种模式上进行了变体：话题主要围绕婚育展开，宣称俄罗斯女孩不要彩礼，自带嫁妆，只求嫁得有情郎。

这种以婚育话题讨好中国网友的打法，常见于女性俄罗斯博主或其中一方是俄罗斯人的情侣博主。从评论区互动情况来看，这种做法也切实击中了目标用户，为他们编织出一场“国女不爱我，俄罗斯美女等我挑选”的幻梦。

第二种打法，是主打“卖惨”，变现方式靠播放量和打赏。

这类内容中，多是俄罗斯人介绍如今生活有多困顿，物价的飞涨有多让人难以接受。但比起单纯的夸夸，卖惨类在刚出现时获得的关注量大，伴随着“卖惨类博主”越来越多，观看阈值的提高，卖惨带来的流量很难维持在较高的水准。《原子之心》的营销话术，也算是第二种打法的变体与延伸。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

《原子之心》截图

必须指出的是，卖惨内容很容易触及到国内互联网下沉市场部分受众的逆鳞。很多观众会认为，有手有脚的大小伙子不好好找份工作，成天靠卖惨求打赏，实在有点不像样。

最后一种打法，则是科普类。这些博主大多住在俄罗斯，内容或介绍俄罗斯的风土人情、历史文化，或教观众学习简单的俄语。因为从海外向中国卖货有诸多不便，且他们也不知道应该怎么做跨国电商，所以变现模式多为卖课。

科普类俄罗斯博主多聚集在B站，因10分钟以上的中视频能承载更多内容。从粉丝量、互动量来看，科普类俄罗斯博主的黏性还算不错，凭借着内容能够沉淀下一批忠实粉丝，但这些粉丝中肯解囊买课的人不多。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

博主max，通过视频卖俄语课

“跨国上课没保障，对方是俄罗斯人交流起来可能会有困难。如果想学，还是会找中国机构。”

此外，部分俄罗斯手艺人入驻小红书，贩卖自己的手工艺品。小娱了解到，因生意难做，他们在各国种草平台都开了账号，主打广撒网，而在中国卖出去的产品也实在不多。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**外来的和尚，难念的经**

俄罗斯博主入驻中国短视频平台变现，并不是什么新鲜事物，伏拉夫走红也已经是四五年前的事情。但一个明显的、新的变化是，过去俄罗斯博主，多是俄罗斯来华留学或做生意，生活在中国的俄罗斯人，他们背后多站着MCN机构。

而从2022年开始，大量在俄罗斯本土生活，从未来过中国的俄罗斯人开始涌入中国社交平台，且以单打独斗居多。

他们选择中国的原因很简单，听说这里能赚到钱。但其中绝大部分摩拳擦掌准备大干一场的俄罗斯人却发现，中国的钱没有那么好赚。

2022年5月底，名为马克西姆的俄罗斯小伙在B站发布了第一条视频。视频时长仅15秒，拍摄的是洒水车在草坪洒水的一幕，因为既不懂中文，英语也很糟糕，马克西姆通过机翻为视频取了个标题《草坪在俄罗斯浇水》。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

这条视频发布后，就像其他刚起步的小UP主作品一样，很快石沉大海。两天后，马克西姆又发布了一条带字幕、内容更丰富、拍摄手法也很考究的视频，向B站的网友正式打招呼。

在这条视频中，马克西姆表示自己是通过朋友知道B站的，也知道在这个网站能通过拍摄视频获得一些收入。此后，他以1-2天的速度更新自己在俄罗斯各地旅行的视频，并在两周内获得了2500名粉丝。

马克西姆对于在B站更新视频这件事都抱着一种佛系的态度，他在彼得堡有工作，B站的收入只是零花钱而已。直到去年9月份，26岁的马克西姆离开俄罗斯，前往其他国家生活。

10月2日，断更半个月的马克西姆发布了讲述自己为什么离开俄罗斯的视频，这条视频上了B站的热门，累计播放量66.1万，并为马克西姆带来大量粉丝。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

“其实我很开心，我觉得我可以靠拍视频在异国养活自己了”，从俄罗斯移居哈萨克斯坦的马克西姆，在当地找不到心仪的工作，于是打算全职靠拍视频谋生。但66万的播放量就像一场梦，他接下来发布的视频播放量徘徊在四五千左右，收入少到难以维持生活。

“我不想这么做，但我不得不在视频中求大家为我充电、点赞，因为我想要活下去。”身上的钱越来越不够花的马克西姆，一路从哈萨克斯坦流浪到东南亚，好心粉丝资助他买了一台无人机，马克西姆把买无人机的过程做成视频发布，获得42.3万播放量，但和那条《出逃》内容一样，几十万的播放量只是过眼云烟。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

“我不知道是我的内容不好看了，还是我拍得太差了”，马克西姆为下滑的播放量和粉丝流失率所困扰。他想靠好内容、好设备以及更好的拍摄技巧来留住粉丝，殊不知结症并不在此。

又经历了一次播放量的大幅跳水后，马克西姆决定前往中国旅行，这条视频为他带来了12.9万播放，也是近一个月内他播放情况最好的一条视频。马克西姆认为，到了中国一切都会好起来，他能靠视频养活自己、买设备、环球旅行、等待着回家的那一天。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**钱是跪着赚，还是站着赚**

前有伏拉夫，后有俄罗斯娜娜。其实在中国靠打“俄罗斯牌”赚钱并不难，已经有了可遵循的范式，而且中国人对待俄罗斯的感情本就与其他国家不同。按理说，土生土长的俄罗斯人更容易赚到钱，造成理想与现实巨大落差的，是“两个俄罗斯”问题。

世界上存在着两个“俄罗斯”，一个是真实的、横跨亚欧大陆的北方大国，另一个是经过中国互联网加工与再解读的俄罗斯。

假扮俄罗斯人却能走红的那艺娜，正是深谙中国互联网上“俄罗斯情结”受众想看的是什么。比如说毫无灵魂的“夸夸”，或者是俄罗斯女孩不要彩礼，打不还口骂不还手之类的婚恋话题。

在莫斯科大学读研的Антон也曾想过自己要不要在中国网站注册个账号赚点钱，但通过研究其他博主的账号、以及与中国同学交流后他发现，这份钱很难站着赚。

“他们想看的，是一种再解读过的俄罗斯，跟我从小到大生长的这片土地完全不一样。我因为接触过很多中国朋友，所以知道应该怎么迎合，但总觉得很违心，而很多俄罗斯本土博主，根本不知道其实中国人喜欢看的是什么”。Антон认为，这也是为什么土生土长的俄罗斯人反而在中国赚不到钱。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)退潮，本图为AI作画，创意by娱乐资本论

更鲜为人知的一点是，此前愿意迎合中国网友喜好的俄罗斯博主，多来自于俄罗斯较为偏远的城市，莫斯科与圣彼得堡人很少。而这两座大城市的人，有属于自己的骄傲。

“他是个远东人，做出这种哗众取宠的事情来，不足为奇。”在与圣彼得堡的Ника交流时，她透露了一条俄罗斯人之间的鄙视链。如果说彼得堡是俄罗斯的上海，那么莫斯科就是俄罗斯的北京，这两座城市的人互相看不起，同时又鄙视着一切其他地区的人。

“这两座城市的人本身受西方影响更大，即使做博主，也更倾向于通过YouTube或者推特这类平台，而不是中国。”另外她表示，虽然很多中国年轻人有所谓俄罗斯情结，对俄罗斯人很有好感，但对于当代俄罗斯人来说，中国与韩国、日本等其他亚洲国家并无不同，“可能对俄罗斯人特别是年轻人来说，韩流反而更熟悉一些”

这些俄罗斯朋友甚至觉得，《原子之心》在中国的走红，都是一场由营销公司主导的，并非制作团队本意的“美丽误会”。“因为很可能制作团队自己都不知道，《原子之心》会在中国这么受欢迎，它本身是对标西方3A作品的。”

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

《原子之心》截图

小娱也发现，《原子之心》的制作团队曾在B轮融资接受过腾讯的投资，它在中国的发行商是来自新加坡知名的游戏与泛娱乐集团“GCL”旗下游戏的发行商4Dvinity

，而4Dvinity前阵子被邀请参到B站的“年度游戏盘点大赏”，而《原子之心》最丰富的二创类内容，恰恰出自B站。

从真假俄罗斯人在中国互联网的冰火两重天遭遇，不难得出这样的结论：假扮俄罗斯人因为击中目标用户需求，可以实现短时涨粉变现，只是有可能像那艺娜的前身“俄罗斯娜娜”一样，遭遇永久封禁。而真俄罗斯人，如果不放下自己的傲骨，则很难靠着高质量内容本身赚到钱。

“俄罗斯营销大法”确实是门好生意，只是它并不属于真正的俄罗斯人。

**话题互动：**

****你刷到过真·俄罗斯博主的视频吗，为他们打赏过吗？****

**推荐阅读**

[![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247570198&idx=1&sn=9ff2ea866dbd27574c0455ad5e9de957&chksm=c058c6cdf72f4fdb2be7f2cd76b9319d7aec4da652d10e1c95bb21dad8b2aca48222fe902df0&scene=21#wechat_redirect)

[![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247570298&idx=1&sn=c53c99db59bdbd8e46f189690d30a82d&chksm=c058c6a1f72f4fb79ecf954aac19e3e9b274379606b3a4ec18154d0f04dba3a50032af13b18d&scene=21#wechat_redirect)

**100万粉一夜带货3000万，董洁咋做到的****？**

**点击观看**

**↓↓↓**

关注**娱乐资本论视频号**，追料更及时

-

**如需商务合作后台回复【商务】**

**如有转载需求后台回复【转载】**

**更多文娱产业背后的经济逻辑，来关注↓↓↓**