# 博纳影业上半年营收14.72亿元，2021年31.24亿元，《长津湖》占比69.77%

> 公众号: 娱乐资本论
> 发布时间: 
> 原文链接: https://mp.weixin.qq.com/s/DI7h1Kg7ZdB7v1seFib3MA

---

![图片](http://mmbiz.qpic.cn/mmbiz_gif/Thf7MtZSy5JALgfBqcOgJ3oEboY0tjWTJ3Ea71eT33B6f0YH4h8icWumyxn16rmMHwDPeyxZCqPHlNUE0lxvs4A/640?wx_fmt=gif&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)

**作者|郭静怡**

近日，博纳影业发布了2022年上半年报。财报显示，公司2022年上半年实现营业收入14.72亿元，与去年同期相比上升81.95%，营业利润为7.44亿元，同比增长621%，实现净利润6.31亿元，同比增长151%。其中电影的投资、发行、院线和影院收入为其主要营业收入来源。

根据博纳影业的半年报数据，其公司前五名客户的营业收入情况分别为华夏电影、阿里巴巴、TSG、咪咕视讯、新疆华秀文化，其中华夏电影占公司全部营业收入比例最大，达到了64.19%，可以看出博纳影业的营业收入大头还是在电影票房分账收入。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

2022年上半年博纳影业主投的电影《长津湖之水门桥》于2022年春节档上映，这也是支撑上半年博纳实现高速营收的主要影片。这部电影上映至今已累计票房40.66亿，位居2022年内地票房榜榜首。

2021年博纳影业营收达到31.24亿元，同比增长94%，净利润实现3.56亿元，同比增长89%。博纳影业的营收能够快速增长，除了2020年疫情对影视行业冲击的外部原因，其关键在于《长津湖》。在2021年营收中，《长津湖》收入达到10.14亿元，占比69.77%。

2021年，《长津湖》于国庆档上映，截止2021年12月31日，凭借57.72亿的票房成为2021年内地票房冠军及2021年全球票房亚军。除此之外，由博纳出品的《中国医生》也获得了不俗的成绩。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

相对而言，2021年上半年，博纳影业仅上映了《新神榜：哪吒重生》与《迷妹罗曼史》两部商业电影，其中《新神榜：哪吒》仅是博纳影业作为联合发行方上映的电影。这两部电影的票房数据也并不理想，《迷妹罗曼史》于2021年5月上映，上映至今票房却只有239.7万。因此2021年同期博纳影业的经营业绩相对较低。

回顾博纳影业发行上映的电影，有着不错成绩的多为主旋律电影。《红海行动》、《中国机长》、《我和我的祖国》等影片不仅票房成绩位居前列，且猫眼评分均在9分以上，可以说是热度口碑双丰收，这些电影也已于今年7月1日重映。

除此之外，博纳影业也有一定的主旋律电影储备，2022年下半年《无名》、《海的尽头是草原》、《平凡英雄》预计上映，有望能够为博纳影业再添营收。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)