# 为什么蜜雪冰城旁边总有一家正新鸡排？

> 公众号: 娱乐资本论
> 发布时间: 
> 原文链接: https://mp.weixin.qq.com/s/kDlWR6ZJd5ESLTxrwh_HXA

---

![图片](http://mmbiz.qpic.cn/mmbiz_png/jNZszpkibXx9fK5DxyTD7AyeFpFRtOjibtXBxHxv9ibzVMWibiaric81WOFUJLW0R1iabhKNBDSeVExetG9DF1zviaEjew/640?wx_fmt=png&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)

**文字、数据 | 张晨阳**

**编辑、监制 | 唐也钦**

**设计 | 戚桐珲**

**运营 | 苏洪锐**

就像肯德基旁边总开着一家麦当劳，蜜雪冰城旁边也总开着一家正新鸡排。

这不是凭空观察得出来的结论。《2022餐饮特许加盟研究报告》显示，在各个餐饮品牌中，扎堆率最高（29.9%）的组合为正新鸡排对蜜雪冰城的扎堆，**也就是说，大概平均每3家蜜雪冰城，就有1家旁边开着正新鸡排。**

相比较近两年在营销上做得风风火火的蜜雪冰城，正新鸡排可能是个“隐形的巨头”：它的门店太小、甚至有点土，人们对它的广告记忆点大多还停留在8年前，《极限挑战》里黄渤拿着一块和自己脸一样大的鸡排大快朵颐。

但**这****个靠鸡排起家的品牌，已经在不起眼的地方开出了25000多家门店，**并且还在持续增长。

“餐饮界的隐形巨头”正新鸡排是怎么做到的？它的万店路径和蜜雪冰城有什么相似的地方？这对小吃品牌有什么启示？

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**炸鸡，一个好生意**

正新鸡排能够成功的一个大前提：在中国，做做炸鸡是一门好生意。

如果不算饮品类，规模做得非常大的餐饮品牌，几乎都在做鸡：从西式快餐肯德基、华莱士，到中式快餐小吃老乡鸡、杨铭宇黄焖鸡米饭、紫燕百味鸡……都是靠鸡起家、靠鸡发财。

从门店数来看，门店数TOP25餐饮品牌中，有超过三分之一都在做鸡，当中又以炸鸡为首：华莱士、正新鸡排、肯德基门店数分别排名“做鸡餐饮”前三。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**炸鸡如此受追捧，最直接的原因就是“好吃”和“便宜”。**

鸡肉在高温中释放出肉类特有的鲜味，油炸的过程让炸鸡表面裹着的淀粉糊化，把含有这些鲜味物质的肉汁锁在了鸡肉中。**炸鸡还具有一定的“成瘾性”，可能让人难以抗拒**——淀粉和油脂的混合，能激活大脑中控制成瘾机制的伏隔核，触发“多巴胺”的分泌，带来快感。

再加上鸡肉比猪肉、牛肉的价格都便宜，还蛋白质丰富，自然能在各品类中脱颖而出。

美团数据显示，2021年大众点评用户评价中，排名前三的高频词汇就是好吃、性价比和实惠。2021年，炸物小吃以超过6.5亿单的单量，成为小吃第一大品类，**其中又以鸡排为首。**

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

认准炸鸡排，就相当于认准了一个庞大的、持续的消费需求，以及这背后庞大的消费群体。

正新鸡排最初叫正新小吃，售卖关东煮、烤肠、炸鸡等多种小吃，原因是品类越多，吸引的客户群体越多。

但问题随之而来：小吃品类越多，原料采购、物流、加工、储存等环节越复杂，不但原料供应复杂，还难以保证口味。2012年开始，正新鸡排开始在产品上做减法：简化产品线，砍掉90%的产品种类，只保留鸡排、烧烤类和饮品类，并将名字从“正新小吃”改为“正新鸡排”。

这之后，正新鸡排的门店迅速扩张，**2017年7月，正新连锁店破万，是快餐小吃品类中第一个门店破万的品牌。**

而同样被列为万店连锁“四大天王”的餐饮品牌：华莱士是在2018年门店破万，绝味鸭脖是2019年门店破万，蜜雪冰城是2020年6月。

在选对了炸鸡排这条赛道之后，正新鸡排是怎么率先开出万店规模的？

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**做鸡，也做鸡的供应链**

“做鸡”这条路之所以能撑起万店规模，不仅是因为鸡肉的消费需求大、食用场景广泛，更是因为鸡肉有非常完整和成熟的供应体系。

1987年，肯德基在北京开出第一家中国门店，它**不仅给中国带来了炸鸡，还带来了一套世界级的白羽鸡养殖标准和全产业链模式：**

相比较猪肉半年才能出栏，一只白羽肉鸡在出生后四十多天就已经足够大只，能被人们端上餐盘。

《一只炸鸡的中国旅行：肯德基的商业哲学》这样写道：

“所有饲料厂、孵化厂、祖代父母代种鸡场、商品代肉鸡场、屠宰厂均为公司自有。采用标准化喂养、大小均等、重量在2300～2500克的肉鸡会能通过全自动生产线进行加工。一只鸡需要经过90多道工序，并根据客户的具体需求切割成不同品类，每个品类切多长、多宽、多厚、多重，都有严格的标准。”

在肯德基供应链的影响下，从食品安全标准，到养殖、生产、屠宰、切割、加工；冷链运输、仓储到门店，再到配套供应服务商，鸡肉形成了非常成熟且完整、高效的上下游链条。

在此之后的“做鸡”餐饮企业，多多少少都吃到了这种供应链的红利，**相比较其他肉类——鸡肉的产出更高效、更稳定、也更便宜。**

而正新鸡排，也早早建立起了自己的鸡肉供应链，1999年，正新鸡排成立自家物流品牌圆规物流；2014年，正新鸡排第一个自有加工基地投产运营，2015年就开始推行全产业链模式。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

正新鸡排的创始人陈传武就在公开报道中提到：“正新之所以能成为拓店之王，因为工厂、物流、装修等各个环节均已打通。前端做大带动后端发展，后端发展支持前端。”

此外，正新的供应链还服务其他餐饮企业，根据正新鸡排官网报道，目前正新集团有7大中央库、50多个遍布全国的前置仓配中心，为总共集团内外2万多家餐饮门店提供贸易与供应链配套服务。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**疯狂开店，做炸鸡届蜜雪冰城**

坚实的供应链既是万店规模的保障，也是万店迅速扩张倒逼的结果。

在陈传武心中，“正新不是一个鸡排店，而是一个以鸡排为连接的产业平台。”至于“做鸡排”这件事，并不是一种厨艺或者技术，而更像是标准化流程中的一道“程序”，只要按部就班，人人都能做，也因此，开一家正新鸡排店的门槛并不高。

加盟一家正新鸡排的前期投资大概是20万元，主要用于加盟费用、开办经费、房屋租金、装修费、产品进货费用等，店主具备健康证并经过培训就能上岗：从门店选址装修到原料供应，细化到鸡胸重量、油温、油炸时间……正新都会对加盟商进行培训。

2013年，正新鸡排开放加盟，门店数狂增。2022年，正新鸡排的门店数就飞速扩张到了25000多家，在小吃快餐-炸鸡类中，不仅门店数遥遥领先其他品牌，还有低价优势。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

而正新鸡排的收入来源，除了加盟费，还有向加盟商兜售原料“赚一块鸡排的钱”。

这一点与茶饮品牌蜜雪冰城极为相似——蜜雪冰城绝大部分收入来源是原料供应，并且品类相对单一。（蜜雪冰城的菜单也许看上花里胡哨，但喝来喝去都是几种原料的排列组合，相比其他新茶饮，蜜雪冰城采用的鲜果只有容易保存的橘子，其他都用果酱。）

**它们的共同逻辑是：减少品类，降低原料供应成本，然后靠极致性价比的大单品（鸡排和柠檬水、冰淇淋）带动其他产品的销售。**

正新鸡排与蜜雪冰城的门店选址也极为相似。

根据红餐大数据，正新鸡排和蜜雪冰城在不同线级的门店比例相差不大——主要集中在三线城市和四线城市。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

复旦大学孙金云研究团队《2022餐饮特许加盟研究报告》对405个门店数大于100的连锁餐饮品牌进行研究，发现扎堆率最高（29.9%）的组合为正新鸡排对蜜雪冰城的扎堆，**也就是说，大概平均每3家蜜雪冰城，就有1家旁边开着正新鸡排。**

他进一步研究了喜欢“互相扎堆”的品牌，计算它们的平均扎堆率，正新鸡排和蜜雪冰城仍然名列第一。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

正新鸡排和蜜雪冰城就像是餐饮界的“游击队”，一家门店就是一个“档口”，它们的消费场景是走路、逛街顺便买，然后打包、边走边吃：“左手柠檬水，右手大鸡排”。

从这个角度来看，正新鸡排，也是炸鸡届的“蜜雪冰城”。

早早开放加盟并让自己的产品“像工业一样标准”，这就是**餐饮连锁化**，也是正新鸡排、蜜雪冰城能开出万店的原因：

不再追求极致的美味和高端的品质，只要达到“还不错的味道”和稳定的产出就行，而它们真正擅长的，是**用“不挑客”的选品、极致的效率与性价比，去服务最大众的群体。**

美团数据显示，在快餐小吃品类上，餐饮连锁化是大势所趋。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

不过，面对门店的逐渐饱和、增速放缓，2018年，正新鸡排推出了“森林计划”，想要突破边界，用做鸡排的方法做其他的产品，陈传武说：“如果正新鸡排能在螺蛳粉、烘焙或者是其它品类再开出来一万家，我们的故事就成功了。”

（题图来源：@正新食品官方微博 ）

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

1. 《2022餐饮特许加盟研究报告》

2.《一块炸鸡的中国之旅：肯德基的商业哲学》

3. 《万店时代，餐饮连锁化背后的中国故事》[https://mp.weixin.qq.com/s/dXgLr2W9txuup934YlCd\_w](https://mp.weixin.qq.com/s?__biz=MzIwMDY2NTgwMA==&mid=2247494182&idx=1&sn=1929350ffc68b6d0feb8a5a9fe859bb7&scene=21#wechat_redirect)

4. 《市场洞察专题 | 从蜜雪冰城看下沉市场逻辑》[https://mp.weixin.qq.com/s/sLZFWLx6yNYIOHj\_IUQRcQ](https://mp.weixin.qq.com/s?__biz=MjM5MTQ4NzI5OA==&mid=2650437663&idx=1&sn=87dd68774aab5bd5e4e23348ca8c0ab5&scene=21#wechat_redirect)

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)