# 国创IP商业大爆发，一个“新百亿市场”来了| 对话淘IP库

> 公众号: 娱乐资本论
> 发布时间: ref: <Node>
> 原文链接: https://mp.weixin.qq.com/s/U-bYlbHsSHBI7BJm1U8tFA

---

![图片](http://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd57YlXEA0EmeZP6NjOFhXPToYG4dln9jFWJQ3jxvZdovicBAY13eiciatCKNibAwBaLKFmGSgzMxH9ibpQ/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)

**作者 | 廿四**

“目前，在自有衍生品方面，我们淘宝天猫店铺每年会达到50%以上的增长，在外部授权方面营收也在逐年上涨。”旗下有“我不是胖虎”“小刘鸭”等国内原创IP的广州奇萌盾甲文化创意有限公司授权总监邓发三告诉剁主。

据介绍，“我不是胖虎”已经合作上百家品牌，授权产品销售额超10亿元；“小刘鸭”合作超80家品牌，授权产品销售额达7亿元，包揽“吃穿用住行”。近期，一直走高端路线的国际大牌欧莱雅和软萌逗趣IP小刘鸭合作，小金管联名防晒产品冲到天猫防晒霜3月热卖TOP 1。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

小刘鸭的火热正是国创IP在B端授权领域高速发展的侧写。而在C端衍生品开发领域，国创IP的价值更是在今年得到集中释放。

2023年开年，《流浪地球2》相关周边随着电影的热映，从目标10万元到众筹总额突破1.2亿元，成为最快破亿的影视IP衍生品。动画电影《深海》和B站热播动画短片《中国奇谭》的周边更是全网热卖。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

再到近期的新晋现象级顶流IP“熊猫和花”，在淘宝的销量七天飙升超906%，一款售价1500元上下的仿真熊猫玩偶月销量破千，包括熊猫图案的手机壳、钥匙扣等周边热卖。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

不难看出，IP衍生品，特别是国创IP，正在迎来一股大爆发。天猫数据显示，IP衍生品已在天猫成长为一个新百亿市场。风格迥异的各类IP谁增速最快？最招品牌霸霸的宠爱？在“消费”成为IP目前最大的商业化增长通道时，IP衍生品如何离消费又更进一步？剁椒TMT对话了淘IP库相关负责人及叠纸、小刘鸭、胖虎等一众IP版权方，尝试找到答案。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**哪些IP增速最快？**

To C端的IP衍生品市场走入上行期，最早可以追溯到2015年。《大圣归来》等国漫形成国民热度的同时，也直观地带动了电影周边的销量。

淘IP库负责人栌辛告诉剁主，也正在这个时期，整个天猫IP TOC端衍生品市场销售曲线向上昂扬。

2017年之后，大量IP方进入淘宝平台，开设自己的官方店铺，整肃市场，正版衍生品逐渐成为市场主流。

国创手游公司叠纸是下场最早的游戏公司之一。2017年，为满足粉丝对游戏的情绪和收藏需求，叠纸把天猫作为自有衍生品发售的核心渠道，售卖《恋与制作人》IP衍生的周边商品，包括徽章亚克力、文创海报、粘土等品类。其中，徽章成为当时的现象级爆款。2019、2020年，叠纸的自有衍生品销售增速翻倍，且保持持续增长。据其衍生品相关负责人初初介绍，自创立起，叠纸官方周边旗舰店“叠纸心意”的年收入持续增长，目前孵化的系列IP衍生品每一季新款销售额都在百万量级。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

这样的销量和粉丝沉淀也进一步吸引了国内其他游戏对衍生品领域的重视。2020年起，随着《明日方舟》《原神》等热门二次元手游在C端衍生品开发发力，国创游戏IP也成为衍生品领域的重要生力军，并在近两年实现规模化爆发。

另一头，国内IP授权的B端市场也从2019年开始进入上行期。这一年，新消费迎来投融资热，IP授权合作、联名逐渐成为茶饮、日用快消、彩妆、家居杂货等领域新消费品牌叩开消费市场的“敲门砖”。

有报告统计，从2019年到2021年，我国授权商品零售额连年保持两位数增长，已达数十亿级规模。而崛起中的国创IP市场，更是凭借较高的性价比，成为这一阶段品牌瞄准的香饽饽。

正是看到IP衍生品市场两端的增长趋势，2020年前后，淘宝天猫开始将潮玩类目进行独立运营，在前端调整了手办、国创IP关键词的搜索模式，同时增设榜单、选购指南、百科和经验分享等内容化手段，通过优化流量分发机制来拉动IP文化消费。

如今，淘宝天猫已经拥有了丰富的IP衍生品生态。业内关心的是，哪些IP增速最快？

第一类是迪士尼、万代这类的经典IP，有核心的影视综内容和长期优质消费人群的沉淀，一直是IP衍生品市场中的主力。

天猫新生活研究所联合淘IP库从成交维度和增长维度发布了两项IP排行榜。剁主发现，传统IP的自有衍生品业务增速飞快，开发类别也随之拓宽。以日本万代为例，在成交榜的前三甲中，由万代南梦宫主力运营衍生品的IP机动战士高达、宇宙英雄奥特曼就占据了两个位置。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

万代南梦宫EC部总经理贝吹宽光表示，就店铺的运营情况而言，借着淘宝天猫的一些场域，万代南梦宫每年实现了GMV双位数增长，“从全店来看，高达、奥特曼、假面骑士的占比是相对较高的。加上万代南梦宫拥有拼装模型、可动手办、景品、成人和儿童向的玩具、卡玩、潮流服饰及生活用品等丰富产品线，和IP一起牵引了过去几年店铺GMV的增长。”

第二类是爆火的影视类IP，其IP价值随影视内容热度飙升不断放大，用户对于IP衍生品的购买意愿也在逐年增强，今年年初，《流浪地球2》因超亿元众筹的成绩，冲到成交榜第2名。据了解，手握《三体》《流浪地球》授权的赛凡科幻，其衍生产品业务营收的一半以上来自于淘宝。

第三类则是以米哈游的《原神》、腾讯旗下的互动恋爱手游《光与夜之恋》为代表的游戏类IP，拥有高消费能力、高粘性、高互动性年轻玩家，成为不少品牌联名的首选。以高产的《原神》为例，2021年与肯德基的联动，让“异世相遇，尽享美味”这句话一度火出圈，在肯德基门店喊出这句口号的视频播放量最高超过了500万。

同时，随着《光与夜之恋》《恋与制作人》等女性向游戏成为游戏市场的主流类型之一，更多女性消费者对IP的情绪价值需求开始显现，此类IP的自有衍生品业务增势强劲，尤其在轻周边板块利润较高，商业化价值可观。

但随着游戏市场的竞争日趋激烈，徽章亚克力海报等衍生品已成为游戏行业的标配。不少拥有前瞻思维的游戏IP转变衍生品开发思维，拓宽产品线。以叠纸为例，在常规轻周边品类之外，其产品线还延伸至了戒指、香水、棉花娃娃、发圈等品类。

第四类是以“胖虎”“小刘鸭”“小蓝和他的朋友”为代表的国创轻IP，通过B端新消费品牌的销售爆发走红，他们的形象更有趣，二创空间更大，合作模式及周期更为灵活，同时粉丝的付费意愿也不容小觑。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

胖虎商业合作案例

典型例如欧莱雅，之所以和小刘鸭合作，就是在调研小刘鸭过往的跨界联名数据时发现，搞怪、软萌的小刘鸭，背后的粉丝消费力竟然是白领女性。

值得注意的是，与往年不同，国创IP首次在成交榜中占到50%；而在飙升榜中，国创IP的热度更为明显：除了迪士尼旗下潮流IP星黛露，其余9个热度飙升的IP均为国创IP。

不难看出，国创IP正在逐步崛起。同时，B端的IP商业授权、联名，已经成为不少国创IP衍生品业务的重中之重。同时，IP合作商业化倾向从“重IP”逐渐过渡到“轻IP”，以小刘鸭为例，在成交榜中排名第7、在飙升榜中排名第2。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**IP如何筛选消费粉？**

虽然有大量热度飙升的国创IP，但极为现实的命题是，对品牌方来说，越是国民度高的IP，面向的粉丝人群越泛化，哪个IP的受众更有商业价值，更匹配品牌核心需求的用户画像？这在从前，都很难量化。因此，品牌方很多时候是在“凭感觉”行动，只能参考IP的社交热度，合作周期短暂且可选IP范围也相对有限。

如今，已经有针对IP的数据中台出现。今年年货节，食品品牌趣多多和开心消消乐萌萌团IP出了一款定制礼盒，拉动了一波销售热潮。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

当时，基于大促期间新品需求，趣多多想通过跨界联名击穿亲子人群，强化新年期间产品的送礼心智，奇妙的是却选中了几乎涉及全年龄段玩家的开心消消乐。

这样的合作促成出自“淘IP库”之手。栌辛回忆，当时在淘IP库中筛查发现，偏休闲游戏的开心消消乐，有最大购买潜力的是妈妈人群，加上IP形象软萌，刚好契合趣多多的需求，双方一拍即合。

淘IP库的定位是IP孵化与成长的中台，核心是为版权方、运营方、品牌解决商业匹配性的问题，快速实现互联互通。

在原有传统模式下，三者都是一对一单独沟通，只能通过自己的信息去获取到对方的状态，交流成本高、交易需求散。淘IP库则能极大提高IP授权匹配效率，降低双方的沟通成本。据剁主了解，趣多多和开心消消乐从对接到互联，整个合作周期不到两个月。相比品牌方自主寻觅IP方时动辄半甚至更久的合作周期，时间效率上极大提升。

据悉，如今淘IP 1.0版本已经搭建完成，涵盖十大IP类型，包括动画、漫画、游戏、影视、潮玩、表情包、文创、艺术家、设计师、乐园、赛事，有700家IP版权已经入驻。

对于IP方来说，基于淘IP库的数据能力所刻画的人群消费属性，还可以反哺自有衍生品开发端，进一步契合市场需求。

当前，IP方入驻淘IP库后，可以自行查看其拥有版权的所有IP作品的信息及部分数据，如分销的店铺、商品、成交排名、IP评级等，还可以查阅与自己同类型的IP在各个品类下的成交排名，以此了解品类机会。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

不少IP方因此拉大了人群、品类辐射的视角，突破了固有的消费粉丝圈。

胖虎就是典型的代表。邓发三告诉剁主，他们通过淘IP库发现，前年胖虎推出的虎宝宝毯子，在去年6、7月份突然爬到母婴品类的TOP3。胖虎的潮玩盲盒也获得了“淘宝”玩具行业潜力IP大奖。受此启发，结合胖虎的内容属性和胖虎的用户群，2023年他们针对胖虎推出“一起长大”的营销主题，除了一起长大的朋友来适配更多潮玩品类外，也有一起长大的亲子，同时推出“父与子”的系列盲盒与婴童用品。

当然，IP方离消费更进一步的同时，衍生品开发依然要回归用户，从兴趣内容和兴趣产品出发。

如今，大众兴趣消费多元，用户行为多样，流量分散在各个端口，而目前电商平台大多以货品销售数据挖掘为主，单一维度尚不足以支撑用户洞察。

淘宝天猫玩具潮玩行业总经理摩萨指出，淘IP库初期整合的就是IP内容分发和衍生品销售两个重要端口的人群偏好，找到潜在圈层和泛IP群体。通过对用户兴趣偏好标记兴趣标签，将标签化数据整合到算法模型中，在流量分发上更精准。

她表示，这些商品在平台上的消费者偏好可以沉淀成为IP偏好人群的标签，并在各个场域中被应用，验证它的商业化价值。而当这一套人群标签沉淀下来以后，未来在授权商品新品上线的阶段，平台可以通过更精准的人群推荐，在新品冷启动阶段就提升商品效率，从而提升IP爆品打造的成功率。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**不止于数据中台**

有了数据匹配能力后，对于品牌方来说，单次合作的热度是有限的，如何持续性地做大做强做出圈，并不简单。对于IP方来说，IP的长线开发不仅需要有商业化的回馈，还需要同步实现IP内容价值的放大，避免纯粹的单向消耗。

作为连接两端的平台，淘IP库充分利用平台营销能力，积极响应两方痛点。一方面对品牌方，通过更全链路的服务方案，从开发、生产、上架到营销、销售端深入参与，为产品销售赋能。另一方面，淘IP尝试把IP作为独立角色引入淘宝天猫生态，试图推进IP核心衍生品的规模化增长，塑造出独特的IP用户群体。

对品牌来说，一方面是货品开发端，淘IP库会站在用户、IP方、品牌等多方诉求上，为新品开发提供思路。

“与消消乐合作时，趣多多想把饼干的形状变成游戏中角色IP的样子，我们建议第一次跟IP合作，一定要轻量化，可以在外包装盒和礼赠上面做联动，减轻供应链的压力。最终，大家想到把消消乐三消的玩法套用在礼盒上做布局，小朋友们都很喜欢。”栌辛也建议品牌，在和IP初次合作可以先有一个轻量化的试水过程，收效良好后，第二波再去做深入联动。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

另一方面，针对营销端，淘IP同样有一系列核心的解决方案。还以趣多多为例，流量端，其联名新品会进入年货节大促的新品池，可获取更多流量和曝光；搜索端，消费者在搜索时，就会看到有IP联名的标识；种草端，首页猜你喜欢、逛逛等场域也展示了个性化主题活动的联动。这样全面的资源矩阵，也将给到联名品牌和IP更全面的转化回馈。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

在IP端，淘IP库也在尝试将IP作为营销的大主题，串联和整合平台资源，达成深度的内容共创。以去年双11为例，线上，众多IP入驻淘IP库时推出了限定联名商品，达成了高举高打的矩阵型传播，同时IP主题直播会场也推动了相关直播间成交量的大幅增长，其中迪士尼、南派三叔、原神等IP均表现突出。

除了线上营销资源、专属营销场域等，淘IP库还通过主导线下联动活动、社媒话题传播等途径提升IP曝光度，为IP价值链条拓展赋能。

同样在去年双11，淘IP库与天猫吉祥物猫天天合作，猫天天集结了三丽鸥、小蓝和他的朋友、LINE FRIENDS、我不是胖虎、小刘鸭等10家IP，把IP方作为二次元明星，拍摄了城市大片，给他们在平台更多内容参与感和曝光机会。这样线上+线下联动的玩法，也促进IP方通过与其他IP、用户的深度互动，共创大事件营销，实现内容增值。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

从功能上看，淘IP库通过数据分析和工具辅助，一方面为品牌企业和IP版权方建立了更好的价值连接，帮助衍生品流通市场；另一方面反哺IP方产品开发，为市场带来新的品类，同时，在生意场上更有人味地考虑到品牌、IP的内容化和用户沉淀的诉求，推进IP的可持续性延展，从而建立一个更为健康的良性循环生态。

据悉，新的一年，淘IP库计划邀请更多的国内外IP入驻，同时，各路IP也正摩拳擦掌，瞄向更强的衍生品增长。针对这一冉冉升起的新百亿市场，无论是IP方，还是品牌方，都有着更多寻求增量的空间。

**话题互动：**

**你关注过哪些IP？**

**推荐阅读**

[![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247574225&idx=1&sn=feac342bbb9c0703dea8c44a12d7255f&chksm=c058b70af72f3e1ca5d4650b37fe9af6c5f80b9b9763aba29d638208379f5f5ec2d38d2af21a&scene=21#wechat_redirect)

[![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247575199&idx=1&sn=e42bf5edba0be7db8ac01a2a37471f86&chksm=c058b344f72f3a526e76172a66e4aaed330ca1436e3dee53794f1bf0601bf31ce0ec38425ecc&scene=21#wechat_redirect)

**选秀节目消亡后，秀人和公司如何求生？**

**点击观看**

**↓↓↓**

**如需商务合作后台回复【商务】**

**如有转载需求后台回复【转载】**

**更多文娱产业背后的经济逻辑，来关注↓↓↓**