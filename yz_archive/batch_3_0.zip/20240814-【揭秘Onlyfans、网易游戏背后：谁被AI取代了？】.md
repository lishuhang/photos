# 揭秘Onlyfans、网易游戏背后：谁被AI取代了？

> 公众号: 娱乐资本论
> 发布时间: 2024年8月14日 14:12
> 原文链接: https://mp.weixin.qq.com/s/Iitl0G3E5jE0P2Zkr9PyZg

---

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd6f3KNDhUwZznxKeBJDjjHDmly4iaLNP38j6gfeCN52MEp2qYcnUVW4cIEE8Zhg5S7DvJChmQ6icQyw/640?wx_fmt=jpeg&from=appmsg#imgIndex=0)

**作者|James**

如果对过去几年的315晚会还有印象，就知道在秀场直播、氪金网游等领域，存在的大量的“托”——比如在秀场直播里面，那些让大哥心动不已的女主播，其实都是抠脚大汉；另一方面，则是在SLG、MMO等氪金类型游戏里面为了刺激大R消费而长期存在的“狗托”现象。

令人想不到的是，**现在这些人人喊打的抠脚大汉、狗托，许多都完全不再是真人，而是“AI”。**

在这里面的参与者，还**不乏Onlyfans、网易这样的顶级互联网企业**……有行业从业者向小娱开玩笑：“同样都是‘托’，现在换成AI之后，就可以从315晚会转到互联网大会了。” 

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6F6Y83LIszsXQfh29diaibTr3TeAhEqwPmVIbTLr28yAn6FmQQNdkUeBcoWGHia8WCTglcRCuWTXjUg/640?wx_fmt=png&from=appmsg#imgIndex=1)

## **Onlyfans上，AI聊天“月入过万”**

刚刚结束的巴黎奥运会，有一个鲜为人知的事情是，大部分运动员仍得自掏腰包去参赛。有运动员国际组织的代表甚至说，不少的运动员甚至“几乎付不出房租”。

于是，我们发现越来越多的运动员从一个另类的筹款平台——OnlyFans发现粉丝，以圆他们的奥运金牌梦。

这里面就包含在巴黎奥运跳水男子双人3米板，拿下铜牌的英国跳水选手劳格赫（Jack Laugher）。**他的OnlyFans帐号每月订阅价格为10美元，发布内容为他身穿“泳裤、三角裤、四角裤等可在工作场所安全观看”的影像。**

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6f3KNDhUwZznxKeBJDjjHDicvLAAFVgnGCovIOlzoPBTawq5d0eMUGHBme9JibfkOw9WSxq7dbtcxA/640?wx_fmt=png#imgIndex=2)

来自澳大利亚的跳水选手米查姆（Matthew Mitcham）也开始在OnlyFans上传上半身正面裸照等影像，他**借此赚得的收入，是作为顶尖运动员收益的3倍。**

只要跟懂行人士说起“OnlyFans”这个词，他们都会不由自主地浮现出“你懂的”那种笑容。确实，它也拥有来自健身、音乐和烹饪等其他类型的创作者，但这个平台正是因其对成人内容的宽容而广为人知。订阅者支付月费以访问他们最喜欢的创作者的独家内容，他们还可以通过打赏和按次付费的帖子赚钱。

OnlyFans 提供私信功能，允许创作者与花钱订阅的用户聊天。**一对一的对话和个性化内容，是创作者重要的创收工具，既可以用来与粉丝建立更紧密的关系，也可以提高粉丝的忠诚度和收入。**

一直以来，OnlyFans以真人回复消息作为其最大的卖点之一。对于许多 OnlyFans 创作者来说，与粉丝聊天并建立融洽关系，以推销“独家”内容，占他们收入的 50% 以上。

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6f3KNDhUwZznxKeBJDjjHD1kic8afuEQVvs6YLroF6dPrWJcfz5Y2lFZfIZS15U04J5LnNHcmU4ibg/640?wx_fmt=png&from=appmsg#imgIndex=3)AI作图  by娱乐资本论

然而，**现在已经出现了一些管理真人明星的MCN机构，他们使用AI假扮这些“明星”与用户聊天**。这些第三方服务使创作者能够管理大量订阅者，而无需亲自参与每次互动。

总部位于美国的NEO Agency网站设计了一个AI聊天机器人，希望可以绕过真人交谈，或最大限度地减少对人类聊天的需求。

这款名为FlirtFlow的聊天机器人“抓住了建立人机关系专业知识的多年精髓，确保每一次互动都是真实而有意义的”。公司表示，**“它不仅发送消息，更创造了真实的联系”。**

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6f3KNDhUwZznxKeBJDjjHDYh5J9hiasLuPwuRAtuM0FhcJ0jU4Evdw1RwfJOHhJAUPJmDUqcaHFpA/640?wx_fmt=png#imgIndex=4)

公司表示，目前大概有1500多个活跃使用的创作者，由此催生的人均月收入在5万美元左右。NEO Agency 首席执行官 Luc Jaris 说，他们自己作为MCN管理着大约 70 名 OnlyFans 色情创作者，其中可能有一半使用 FlirtFlow，其他20家左右的机构，还有数十名个人创作者也是如此。

网站上还提供公开定价——**如果是个人使用，可以将自己日后收入分成的20-25%用作该产品的抽成即可。**

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6f3KNDhUwZznxKeBJDjjHD90c5uRLf8JHNYEqdUEMToHoffBFnicAkFFWCOjMZJZeIFMpeANsL3eg/640?wx_fmt=png#imgIndex=5)

但是，粉丝们在付费时，当然期望获得真正的互动，如果不透明地披露使用AI，可能会被视为欺骗。

同样采用人工智能的还有 Botly，这是一家成立于 2023 年的澳大利亚公司。它每月向创作者收费 15 美元，用于分析订阅者的问题和聊天记录，以在 OnlyFans 消息框中生成响应。Botly表示，该技术每月用于超过10万次聊天。因为人类仍然必须手动发送AI生成的消息，所以软件绕过了OnlyFans的机器人禁令。

**OnlyFans 的服务条款明确禁止其创建者使用 AI 聊天机器人。**但是，这款应用可以不用向 OnlyFans 订阅者披露，而且也没有什么特别好的检测办法，所以用户只能假设他们正在与明星们实时聊天。

看到这里，不少人都想起了曾经被315晚会曝光过的“男运营冒充女主播喊粉丝老公”事件。

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6f3KNDhUwZznxKeBJDjjHDubQLDwP6vzbRAsSGFwz2KujqRMVdUicrv7EJ4tJTvD3OnbHZw0mnusw/640?wx_fmt=png#imgIndex=6)

那么这些AI陪聊服务，是否也会进入到直播秀场领域呢？娱乐资本论询问一位知情者，他推测在中文圈这么玩的不会太多。

“OnlyFans的欧美用户，主要是月费订阅模式，他们核心是买图包视频，聊天只是增值服务，AI的出现不会降低他们的付费率。”

但**国内的秀场直播不一样，加好友通常只是第一步，刷礼物、私下送礼、骗其为见面付费才是核心**，“不把你吃干抹净了不罢休的。这种情况下全用AI回复有风险，有时候本来他问你爱不爱他、能不能见面，万一AI比较‘大方’，轻轻松松就同意了，那他就不愿意再花更多钱了。”

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6F6Y83LIszsXQfh29diaibTr22R5h68ra6cKETkiaMiac8OxkOc6r74Zqicw4rVbKCVjrFkL2RRQq5gNQ/640?wx_fmt=png&from=appmsg#imgIndex=7)

## **AI模拟玩家，在SLG攻城略地**

除了一对一聊天，不少互联网公司发现原来在氪金网游里面，也可以用AI去满足用户的需求。

当然，这源于网游领域早就存在的“狗托”现象。

**在诸多页游和手游中，尤其是SLG和MMO两大品类里面，都有仅靠极少数人民币玩家维持运营的共同点**。为了维护好和“氪金大佬”的关系，运营方一般需要仔细操作，用他们看不出来的方式，雇佣真人玩家或调整游戏参数，进行陪玩服务；或者在人数较多的服务器中，或制造对立阵营，或制造公会小弟，让他们满足于“号令天下”的快感，大杀四方。

传统上，陪玩服务可能会包括两个角色：**一个是扮演游戏中的BOSS，另一个则是敬仰玩家的“小弟”角色。**

此前就有人匿名在知乎发帖回忆，他所在的游戏公司曾经收到一个大佬投诉，说自己投了极多的钱，但也无法开到一个宝箱，威胁再开不出来就退服。为了不破坏游戏的公平性，公司只好连夜安排员工进入他的战场，在他马上要输掉本局的一瞬间扔出宝物，结果他看到了，但没有捡到。这才把他留在了游戏里面。

还有前陪玩者向河豚君回忆说，自己每天的任务，就是拿着公司直接发的游戏币，不断提升战力，冲击排行榜，给服务器里的大R（氪金的大玩家）制造压力；甚至会“追杀”大R，不过得讲究分寸。而在玩家进行充值变强后，游戏托会略微示弱，满足玩家的成就感，如此循环往复。毕竟，在游戏里变强只需要改动一串代码。

**随着AI技术的发展，上述“代打”行为都已经从人力操作，逐渐转向了由AI自动完成。**

今年 ChinaJoy 上，娱乐资本论在网易数智CJ展台，看到它们的SLG智能体宣传展板格外醒目。其目的也一目了然地写在展板上：

**“取代80%低活玩家，锁定并激发高活玩家”。**

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd6f3KNDhUwZznxKeBJDjjHDZ7UldXMcjUopGezNUMdIXnzPRULWkMEbAvLsyoGicXOVzW9gEPAIzicQ/640?wx_fmt=jpeg#imgIndex=8)

据称，**网易的SLG智能体可以对端游、手游甚至微信小游戏接入，提供“主动社交、自我成长”等特性。**

网易公司副总裁庞大智透露，在AI技术的加持下，《逆水寒》手游玩家，可以随时“路遇”一群没有固定剧本、会自主思考的智能NPC。他预测，今后在游戏里，碰到几乎和真人无异的AI角色，会是大概率事件。**“游戏行业一直被公认为AI技术最好的试验田，也是最早感知、适应AI冲击的前哨。”**

去年以来，网易游戏“伏羲实验室”的相关技术目前已有数十款旗下游戏采用。在网易数智的官网，我们也可以看到其中涵盖了大量的游戏类型。

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6f3KNDhUwZznxKeBJDjjHD2wphIzibJOD5g4eeciadbR94U88a8AVqYicibVag7yTMgrYvQiaKwEwkLdQ/640?wx_fmt=png#imgIndex=9)

比如说在一些MOBA类目中的玩法“超强人机”，巅峰时候每天对局的峰值超过千万。据介绍，在这一过程中，**AI通过深度学习与强化学习，在对局中维持着“要让玩家感到有难度，同时也要玩得爽”的微妙平衡。**

**AI可以生成类似于人类玩家的决策路径，从而代替真人玩家进行游戏**。即使在真人玩家数量不足的情况下，这种AI也能帮助保持游戏的活跃度。

在另一些场合，AI会分析玩家的操作和决策，自动调整敌人的策略和强度，使得游戏难度始终与玩家的水平相匹配，以保持玩家的兴趣。

2022 年，流行的策略棋盘游戏 Diplomacy 的玩家聚集在“元宇宙”中，参加该游戏的在线锦标赛。他们遍布全球。没有一个玩家可以看到彼此，只能在游戏中互动。

因此，他们没有人知道其中一个玩家是一台计算机——由Facebook、Instagram等母公司Meta制造的，一个名为西塞罗（CICERO）的AI程序。

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6f3KNDhUwZznxKeBJDjjHDvSdDZF1jme15qud8GfzB424ubmBrUdwHiaVZ3cCtLArMbia2k6a0pXdQ/640?wx_fmt=png#imgIndex=10)

即使在大模型出现之前，西塞罗在 Diplomacy 中的胜利已经代表了一个巨大的飞跃——**在多人联机对战游戏中，AI可以智能管理大量资源，甚至跟其它参与者临时结盟，然后在最合适的时机“跳反”，跟另一拨人结盟并“反杀”原盟友。**

几十年来，计算机一直在国际象棋和围棋等策略游戏中击败人类。但是西塞罗非常不一样，它不是那种“白棋往下走3步”的智能形式，它的动作在玩家那里“通过了图灵测试”。在那之后，一切只会更不一样。

例如，**《逆水寒》去年宣布运用AI NPC以后，在宣传自己是个AI游戏的道路上蒙眼狂奔。**它们的公众号这样写道：

“备受好评的AI助战，为您的副本之旅排忧解难；AI文字捏脸，打打字生成绝品容颜；剧组模式AI动捕，您可以在游戏里‘为所欲为’做动作；高智能NPC，已经彻底成为了这个江湖的一部分。” 

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6F6Y83LIszsXQfh29diaibTrSehp43ribpQjVk5Jlod5NKE3rr828WF1U3ONJvMm3nxR6rmibFJXyLSQ/640?wx_fmt=png&from=appmsg#imgIndex=11)

## **为什么要有AI**

看到这么多场景都偷偷的使用了AI，大家不禁怀疑，为什么各种娱乐方式，都争着抢着要用AI？

让我们擦干眼泪，冷静地看看在AI出现之前，OnlyFans的作者和游戏开发商们都在干什么。

**对于许多 OnlyFans 创作者来说，与粉丝聊天并建立融洽关系，以推销“独家”内容，占他们收入的 50% 以上。**

而且这玩意是停不下来的，就是你回复得越频繁，粉丝越上瘾，赚的钱就越多。

但是很显然，如果是这个偶像真人去面对成千上万的粉丝，ta也绝不可能做到对每一个粉丝的具体情况都如数家珍。

所以这就像回复粉丝来信一样。优秀的偶像也有经纪人和工作室，当然需要团队来帮忙撰写这些回复消息。

有的时候，一两个人不够用。他们就得大量找外包员工。而这些外包员工其实有很大一部分是来自发展中国家的低薪工人，特别是菲律宾、尼日利亚、印度和巴基斯坦等国。

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6f3KNDhUwZznxKeBJDjjHDCU2wUlkeYtCfgSDQ2Gq7WXLlOvvia0rABdom0z4IVF4jKxn1RO3UE4A/640?wx_fmt=png#imgIndex=12)

据报道，他们每周工作六天，轮班工作长达 12 小时，每小时约 3 美元。

（现在你知道人家介绍里为什么要说“告别旷工的陪聊”了……）

但就算是全找便宜的境外劳动力外包，成本上也是一笔高额支出。尤其是国内的直播行业，运营又要会说话，又得套路多，月收入蹭蹭蹭的过万…… 

这个时候吧，就显出了大模型的好。

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6f3KNDhUwZznxKeBJDjjHDxXp6Y64VibuNK4drNBUevwiaaPrgVBeMydIkF0KSu23xHJRfK4Q8jHNg/640?wx_fmt=png#imgIndex=13)

再看看游戏那边，咱其实也知道之前的MMO、SLG里面大量的托，这没啥好说的。 

像这种游戏公司招聘网站公开的岗位需求，说白了有些就是在招聘游戏狗托。此前有报道称，绝大部分游戏托是游戏公司自己雇佣的，有些公司甚至到了除少量研发人员外“全员皆托”的地步。

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6f3KNDhUwZznxKeBJDjjHDW4F1FaoslsVM4berXldFR7tarAbK5SwoONS9tRpANIOP68XvLDAzJw/640?wx_fmt=png#imgIndex=14)

**实际上，如果不想欺骗粉丝或玩家把AI当作真人，网上也有虚拟伴侣产品说明自己就是AI，而且售价比直接用真人低得多。**

LushAI 自称是世界上第一家由 AI 驱动的粉丝经济机构，旨在与 OnlyFans 竞争。**该网站由默认的服务对象Jenny以及其它AI模型组成**。Jenny长这样：

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6f3KNDhUwZznxKeBJDjjHDtzmHLwcL7vbKtOHeZ0GuIp86ibic35X6EMD9Y0Rbr2RvMH2X7E3hA3OA/640?wx_fmt=png#imgIndex=15)

Jenny 们提供的服务与组成 OnlyFans 的人类内容创作者基本相同，只是她由算法驱动，可以7x24不间断回应。她们的服务定价也很实惠——作为“花魁”，Jenny的内容费用每月相当于 10 美元，粉丝可以访问“照片、视频和私人聊天”。

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6f3KNDhUwZznxKeBJDjjHDiboR83GcDwzgLUJo8flIce5cJBGiaU3ouVk9GERKZoQyicdKick7LrQopg/640?wx_fmt=png#imgIndex=16)

LushAI 还提供“独家社交消息平台”Kupidly，用户可以在其中与 Jenny 和其他 AI 模型连接和聊天。LushAI 的面孔是用 Stable Diffusion 创建的，聊天能力是由开源模型enqAI 提供。

这个平台也吸引了一些真人加入阵营，美国大学生、模特和内容创作者 Demi Zhang，与LushAI分享了她的肖像，为她的社交媒体账户创建了一个独特的角色，她在 Instagram 上积累了 21800 名粉丝。

然而，**之所以在有纯AI平台的时候仍有人去OnlyFans浑水摸鱼，纯粹是因为如果直球标榜自己是AI，可能就赚不到那么多钱了。**

有调查表明，如果商品或服务在宣传语中强调自己的AI属性，反而会招致消费者的反感。而且，一个产品如果标称是AI制作的，它会被认为是人类劳动含量更低，所以心理价位也应该比真人制作的更低。

LushAI 创始人Eunn 表示，他不认为 AI 伴侣和在 OnlyFans、Instagram 或 TikTok 上销售“数字化性行为”的真实女性之间存在根本区别。

“当你在网上或Instagram上看到一个所谓的'真人'时，你实际上并不是在看一个真人，你是在与一个真人的数字化表示进行互动。”

对这一点，很多内容创作者和消费者很难同意。

也不知道是好是坏，反正**未来AI进化的方向，是既要让你看不出来，同时又比实际的人类做得更好。**

所以，不要问那个ta是谁，好好享受游戏里的战斗或网红的嘘寒问暖吧。

**话题互动：**

**你遇到过在网上错把AI当作真人的情况吗？**

**作者**

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd7dicmXtX1ibncyeMRsqFP6PnUZZ5pUdYnDDy8oXeDjA0viaRZz9uEh3BHib25xsZYxLuHDbXwLics7nVQ/640?wx_fmt=jpeg#imgIndex=17)

**推荐阅读**

[![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd4CgsyNCRvrZ6icibyuRLhlicdnAC2l1OnBarziadRDVyt1z73Wq5lyQs3mFwicKstOicI1R2v9j4S7E6SA/640?wx_fmt=jpeg&from=appmsg&wxfrom=5&wx_lazy=1&wx_co=1&tp=wxpic#imgIndex=18)](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247641442&idx=1&sn=84610dbfe11fbd5fddd20fb50175c63c&chksm=c057bcb9f72035af9ceec1ef0dd91b6a4957667193792f1e2c564c5e63ce38100edf3548e0f0&scene=21#wechat_redirect)

[![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd4CgsyNCRvrZ6icibyuRLhlicdYDPGVQiaCxgXiaSYQ3rFYkWFRsdfIVwHHq2Ovg3gJUeqbNO2hthm4cGw/640?wx_fmt=jpeg&from=appmsg&wxfrom=5&wx_lazy=1&wx_co=1&tp=wxpic#imgIndex=19)](https://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247641487&idx=1&sn=9f3c3052960507707ccf2b3c4bd06ce8&scene=21#wechat_redirect)

**高捷称安佩到死都没有怀疑自己的侄子**

**点击观看**

**↓↓↓**

**如需商务合作后台回复【商务】**

**如有转载需求后台回复【转载】**

**更多文娱产业背后的经济逻辑，来关注↓↓↓**

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd6F6Y83LIszsXQfh29diaibTrLpWA6mYU7OBCKOiaScSWhmy5Xo4hoPAIlAvDPSfdicEHvOzZCEY4boJw/640?wx_fmt=jpeg&from=appmsg&wxfrom=5&wx_lazy=1&wx_co=1&tp=wxpic#imgIndex=20)
