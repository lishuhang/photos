# 2023年B站片单全解析：一切为了年轻人

> 公众号: 娱乐资本论
> 发布时间: 
> 原文链接: https://mp.weixin.qq.com/s/IZIuDEf9Uuk2Q3XuxGb72w

---

**![图片](http://mmbiz.qpic.cn/mmbiz_png/jNZszpkibXx9fK5DxyTD7AyeFpFRtOjibtXBxHxv9ibzVMWibiaric81WOFUJLW0R1iabhKNBDSeVExetG9DF1zviaEjew/640?wx_fmt=png&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)**

**作者｜夏周‍‍‍‍**

“当我们打开B站热门排行，我们会发现这里每天发生的是一个年轻人毕业踏入职场，或者第一次自己租房，或者第一次买车、第一次装修，又或者踏入婚姻。一个新的生活画面在缓缓打开，着急又笨拙地表达着自己的需求。只要人的成长不会倒退，那么满足这些新需求的商业机会就永远存在，”B站副董事长兼COO李旎说道。

12月27日下午，B站在上海举办了举办2022 AD TALK营销伙伴大会。这次 AD TALK营销伙伴大会着力向品牌主全面介绍了B站的营销能力，推出帮助品牌方精准定位消费者链路的“MATES人群模型”。大会的核心议题则是B站2023年内容片单，同时推出新一年度的招商地图。

![图片](http://mmbiz.qpic.cn/mmbiz_png/jNZszpkibXx9xTw5B9yj2q4nw7RqqasccMmu5iaRCNOmUp8l4ePLcIBZhISv1NqB3FdUThehsmAKjBYh1kIHugMA/640?wx_fmt=png&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=1)

梳理这份B站2023年内容片单小娱不难发现，无论是综艺、纪录片、影视剧或者国创，还是各个节点大事件，B站主要的内容布局正在围绕一个目标进行，那就是满足年轻人的成长需求。

年轻人面临毕业，夏日毕业歌会成为近几年B站的王牌IP。年轻人步入职场，那么《零零职介所》为代表的职场综艺开始在B站不断涌现。年轻人正在谈婚论嫁，《90婚介所》系列就为年轻人打造真实的恋爱场景。总之，年轻人成长的各个阶段的“困惑”都可以在B站找到答案。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

B站十二周年之时，B站董事长兼CEO陈睿曾经表示，B站的正向内容价值观包括了内容的有用性，提倡用户看了内容之后的获得感。平台希望用户在B站上得到提升成长，也希望B站能和用户一起成长。显然，B站制作内容的过程中，遵循的也是同样的思路。

通过深耕内容制作，B站意识到跟随年轻人的成长阶段来创造内容，最大的好处就是能够提升社区自制内容的丰富程度，帮助年轻人收获他们所需求的内容。与此同时，这种内容制作思路对于品牌主而言同样至关重要。

过去一年，B站成功地将内容生态与商业实现链路打通，品牌主可以轻松地接触到处于人生不同阶段的年轻人。传递品牌价值一直以来都是品牌主投放的主要目的，而B站的原创内容能够助推品牌与年轻消费者建立信任关系，最终实现品牌心智的建立。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)**2023片单目标只有一个，B站一切为了年轻人**

各个平台的内容片单是平台未来一年发展的晴雨表，这一点对于以视频内容为核心的平台来说更是如此。今年下半年爱奇艺、优酷、腾讯视频和芒果TV等四大平台已经纷纷发布过2023年影视剧综的内容规划，每一家的项目片单都有近百个项目作为一年平台运营的支撑。

整体观察下来，长视频平台仍然不愿放弃任何一个内容领域。虽然行业内同质化趋势越来越明显，降本增效是笼罩在所有平台头上的达摩克利斯之剑，但各家平台也都在努力地从已经形成红海的内容市场中寻找尚未开垦的处女地，以期脱颖而出。

相比之下，小娱发现B站2023年的内容安排非常有趣。正如文章开头所言，B站当下的内容布局围绕一个目标进行，那就是满足年轻人的成长需求。B站相比其他平台最大的优势莫过于理解年轻人，能够伴随年轻人成长，并深入其生命中的各种生活碎片。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

综艺节目是最能体现B站制作思路的原创内容品类。近年来B站取得成功，并能够持续推出续集的综艺，本质上都是牢牢抓住了年轻人的所思所想。

恋爱综艺现在是每个平台综艺储备的必选项。视频平台如果想要针对年轻群体策划一档成功的恋爱综艺，仍然需要在前期筹备过程中进行广泛调研。B站则有所不同，他们拥有大量的Z世代年轻用户，也能感知到年轻人旺盛的交友需求。今年第一季度B站站内有关“征婚”或者“求偶”的视频就高达256个，累计播放量3000万以上。正是基于对年轻人的了解，《90婚介所》才应运而生。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

2023年B站还会推出以火车旅行为场景的恋爱观察综艺《带朋友恋爱特快》，制作思路同样是根据年轻人需求生产内容。

B站新综艺也把目光投射到年轻人身上。2023年B站主推的几档全新综艺节目中，《盛夏之歌》最核心的标签就是大学生音乐竞演节目，《我真的会舞》主要比拼的项目是年轻人喜爱的“随机舞蹈”，《过招吧！甲方乙方》和《零零职介所》则是要解决年轻人如何面对职场的问题。总之，满足年轻人的胃口是B站综艺制作的第一要务。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

B站的影视剧内容创作逻辑同样是面向年轻人，最为典型的案例就是明年第一季度上线的《一天的英雄》。和以往主流的电视剧不同，《一天的英雄》采用的是时下年轻群体中非常流行的vlog形式，如此的编排设计，可以最大程度获得年轻人的共鸣。

电竞赛事作为B站内部深受年轻人关注的内容品类，明年也将和影视内容实现融合。根据AD TALK营销伙伴大会上公布的片单规划，明年B站将联手腾竞体育，推出以电竞为主题，融合多种风格和类型的“电竞剧场”，满足喜爱电竞和剧集的年轻受众口味。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

B站和其他视频平台最大的不同，莫过于每年都有各类节点大事件。这些节点性质的大事件，B站正在着力将其打造成新的IP。除了拜年纪和百大UP主颁奖这样较为成熟的活动，高考季和毕业季两个与年轻人紧密相关的重要节点，B站内部的重视程度越来越高。

今年的B站夏日毕业歌会总共时长两个小时，站内直播人气峰值高达5300万。夏日毕业歌会成为B站的王牌IP，这背后体现的自然是用户不断成长的过程中，更加年轻的新鲜血液进入B站，实现用户群体的拓展。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)**“新血”愿意消费，B站产出有生命力的流量**

今年的AD TALK营销伙伴大会上，B站营销中心总经理王旭明确地提出了“有生命力的流量”这一概念。她表示：“如何为流量注入生命力，又是如何让有生命力的流量帮助品牌成长。在这个过程中，内容都是不可或缺的。正是B站的丰富内容生态，让一切成为可能。”

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

以今年B站剧集中的爆款《三悦有了新工作》为例，片中的三悦是一个刚刚正式踏入社会的95后，从事的也是人们知之甚少的殡仪馆化妆师。三悦在成为殡仪馆化妆师之前，曾经经历了将近一年的“家里蹲”。随着各种人生的变故袭来，到底是“躺平”还是“卷起来”成了三悦需要面对的一道选择题。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

实际上，卷还是躺也是上B站的年轻人真正关心的话题。B站理解年轻人的所思所想，才能制作出引发年轻人共鸣的作品，最终占据他们的内容消费心智。同时，这批年轻人表达共鸣最好的方式就是制作一段感想视频发回到B站站内。这些感想不仅有对剧情的探讨，也有对生活的总结。由原创内容生发出来的讨论和流量，都是“有生命力的流量”。

UP主“不是猴头菇”就在看过《三悦有了新工作》之后发表了她的感想。她认为很多父母希望自己的孩子出人头地，从而产生了逼迫自己孩子去内卷的行动。这些当然可以归结为父母的本能，也可以归结为一种爱，但是如果疏于和孩子进行沟通，实际上是一种本末倒置。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

如果只是单纯创造流量，那么B站还很难被品牌主所很真正重视。事实上，根据B站给出的数据，B站用户的“新鲜血液”平均年龄在20岁左右，他们对站内广告表现出更高的转化意愿，单个用户贡献的ECPM比两年前的新用户高出20%以上。这一批愿意表达且能够帮助品牌主转化的用户，正是品牌主们追求有生命力的流量的核心驱动。

明确了“有生命力的流量”意义所在，那么B站下一步就需要基于内容与用户，促使这些“有生命力的流量”带动品牌推广。

B站的推广方式之一是多场景覆盖。李旎表示，把品牌推广覆盖全视频场景，是B站打通社区生态与商业链路过程中决心去做的事情。B站是为数不多的覆盖PUGV、OGV、直播、story和OTT等所有视频形式的平台。因此，多种形态的视频形式交织在一起，对于视频内容以及其中的品牌传播都是大有好处的。

竖屏视频是B站今年业务中的一个亮点所在，根据B站Q3财报显示，竖屏视频日均播放量同比增长 473%，也是今年B站增速最快的业务之一。这种惊人的增长速度意味着，即便是在B站社区内部，长视频内容剪辑成竖屏视频，所带来的破圈效应会更为明显。

比如今年上线的《守护解放西第三季》，把节目中大量的段落输出成为竖屏视频。其中，每个竖屏视频里都会带有赞助商沃尔沃S60的标识。罗翔老师驾驶沃尔沃S60拍摄的短片也通过竖屏视频的方式，得以实现破圈传播。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

除了把品牌推广覆盖全视频场景，B站还在提升整合营销的能力，为不同垂直行业客户提供更高效的行业解决方案。也只有这些高效的行业解决方案，才能和有生命力的流量产生化学反应，最终迸发出惊人的破圈势能和销售转化。

最近两年，统一果汁一直在与B站独播动画《天官赐福》进行合作，今年更是把这种合作从线下延展到了线上。统一果漾今年7月推出了官方小程序。为了提升官方小程序的热度，统一在微博开展了盖楼送好礼的引流活动，奖品正是《天官赐福》的相关周边。通过动画的植入以及动态的推广，统一金桔柠檬的销量得到了4-5倍的提升。

统一果汁事业部的品牌总监戴志林在圆桌讨论时表示，统一通过B站的原创内容实现了话题的聚集，在相对更精准的收众群中建立了非常好的品牌联系，在目标人群中建立起了热爱的种子，基于此不断延展出新的内容出来，而这一切都要归功于B站完善的整合营销策略。

B站仍然是一个比较年轻的平台，跟随用户一同成长其实是一个非常美妙的过程。用户的关注点从娱乐消费开始转向生活消费的当口，B站如何通过自制内容服务好品牌主是尤为重要的。抓住消费者成长的机遇，B站希望能够利用手中的原创内容助力合作伙伴释放增长新势能。