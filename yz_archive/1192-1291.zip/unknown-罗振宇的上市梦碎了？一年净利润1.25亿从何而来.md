# 罗振宇的上市梦碎了？一年净利润1.25亿从何而来

> 公众号: 娱乐资本论
> 发布时间: 
> 原文链接: https://mp.weixin.qq.com/s/6nS50DTKVPr5LXYWCPjG_A

---

![图片](http://mmbiz.qpic.cn/mmbiz_gif/HKEDX7MqXK0nTTS7DaVdWJfbK1TSibe1dD50L92xaTqS3AzbWDg1cHUtKzZXBFYhYLR7BlUdns6PNVAArMPF9Jw/640?wx_fmt=gif&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)

**作者｜夏天**

随着近日思维造物主动申请撤回上市，其知识付费第一股的“争夺”暂时告一段落。

实际上，在为期两年的IPO进程里，思维造物先后经历了三次深交所问询，并七次更新招股书，意在快速进入资本市场。

因此，思维造物此次主动撤回上市的消息引发了业内一片哗然。一时间“是知识付费做不下去了么？”、“罗胖的上市梦碎了”、“鸡汤讲不下去了”等质疑扑面而来。

随后，思维造物董事长罗振宇发表的内部信曝光，间接回应了撤回上市的原因。他表示从做出“这个”决定起，就有身边的同事问他“你难受么”？面对现状罗振宇直言“一切都是最好的安排”。记得罗振宇曾在时间的朋友演讲中提到，自己以前看电影印象最深的台词是：“行就行，不行我再想想办法”。这句话用在思维造物的上市路似乎挺“应景”。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

来源：得到公众号截图

罗振宇在信中解释称，撤回上市是公司基于和监管部门的沟通，以及当前市场环境等多方面因素的综合考量而做出的决定。并且公司的目标永远不是上市，而是为用户持续创造价值。

不过对于这个官方味道的“回答”，一些网友却并不买账，“速食知识如何上市”、“得不到的永远在骚动”、“是不赚钱了么”等言论层出不穷。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

来源：微博截图

不过，有一点可以肯定，思维造物还是赚钱的。思维造物2021年共实现营收8.43亿元，同比增长25%，其净利润为1.25亿元，同比增长212%。

这其中，包含了79.45%归属公司所有的线上课程销售、线下招生翻倍的高研院课程，以及罗振宇跨年演讲所带来的赞助费用。

那么，到底是为何让“7冲”资本市场的思维造物搁浅了上市呢？

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**两年7冲IPO，去年营收8个亿，  
依旧没能成功上岸**

2016年，知识付费赛道成为风口，资本也开始了蜂拥而至的下注。也是得益于此“机会”思维造物在上市之前就得到了红杉中国、真格基金、顺为资本等明星投资机构的青睐，并且在2017年D轮融资后，其估值就已经超过了10亿元。

并且，思维造物还受到了多位商业大佬们的鼎力支持，其中，《经济观察报》主笔李翔、“中国比特币首富”李笑来、新东方俞敏洪、联想柳传志都间接持股思维造物。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

来源：招股书

也正是因为有了这些雄厚的背景，思维造物更有底气了，公司也从知识付费领域的代表选手上升到从事终身教育的企业，并且开始计划冲击资本市场。早在2019年的时候，思维造物首先是把目光放在了科创板上，而后2020年开始转战创业板，一冲就是7次更新。此外，在招股书中思维造物引用2018年艾瑞咨询数据把自己与“知乎”一并归结在行业的第一梯队里，这也能看出公司对未来市场“寄予厚望”。虽然，现今公司已经主动撤回了IPO，不过正所谓留得青山在不愁没柴烧，思维造物未来仍有机会“再战”资本市场，至于公司未来的发展规划，思维造物表示暂时不方便透露。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

来源：《招股书》

毫无疑问的是，思维造物是赚钱的，但是其业绩情况有些“过山车”。

据《招股书》显示，2019年—2021年期间，思维造物的净利润分别为为1.17亿元、4006.35万元、1.25亿元。其中，2020年同比下滑66%，主要是因为公司投资亏损增加所致，而2021年同比增长212%，主要是由于公司经营效率上升，使得收入规模和毛利率双重上涨。同期，公司的营业收入分别约为6.28亿元、6.75亿元、8.43亿元，也均呈上涨趋势。

**思维造物的营收主要来自三部分内容。**一是线上知识服务占比为64.03%，也就是通过得到APP的交付课程、听书及电子书产品等；二是占比为20.4%的线下知识服务业务，包括线下演讲门票、广告赞助收入，以及“高研院”课程；三是占比为14.19%的实体书、得到阅读器等电商收入。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

从业务层面来看，最赚钱的肯定是其线上APP——得到的付费课程。2021年，其占比达到线上知识服务的76.20%，其中，单次课程更受欢迎，其收入占比为61.71%。

虽然与名师合作的《薛兆丰的经济学课》、《熊逸讲透资治通鉴》、《香帅的北大金融学课》等大受欢迎，但思维造物也在提高其自研课程的布局。

在2019—2021年期间，分别有95.75%、96.8%、98.48%课程收入来自知识产权归属公司所有或者是由公司与创作者共有的课程。并且，在2021年收入贡献前五大课程中，有三门都是来自公司员工主讲，累计收入0.89亿元。在2019-2020年，收入贡献前五大课程中基本全部为名师课程。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

来源：《招股书》

而用户之所以买账其线上课程，则是因为思维造物课程的权威性。用户小吴对**剁椒TMT（ID:ylwanjia）**表示，得到APP的课更权威，而且都是名家讲的，有根据来源，听完后能够共情，自己愿意付费。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

来源：得到APP截图

其次赚钱的，是思维造物线下高研院的课程。2021年，公司高研院收入为9280万元，同比上涨95.55%，主要是因为招生扩大所致。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**一个班118万学费的高研院成为新增长曲线？**

疫情期间还能收入大幅上涨，思维造物的**高研院**引起了剁椒君的注意。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

来源：高研院公众号截图

从2018年开始推出的高研院，凭借着学员们口口相传推荐，其招生名额大幅增加。从2018年第0期的286位学员，扩大至2021年一期最多可达2958位学员。截至2021年底，“得到高研院”线下校区已覆盖国内10个城市，成功开设了 198 个班次，录取学员超过 15000人。

那么，有人要问了这个高研院到底是什么？其实，就是通过面试把很牛的人筛选进来，然后组成一个“很哇塞”的分享会。而参加过高研院的一位往届学员这样评价：“高研院让我认识到许多，可能一辈子都没有机会认识的人。大家基于学习这个共同点，突破了固有的圈层，形成了再组合。”

经剁椒君了解，高研院的课程为全国统一价格为**1.98万元一期**，由直播、录播和线下交流课共同组成。今年秋季是第13期，目前计划在5个城市开课，已经确定的城市有北京、成都、深圳，并且每个班级最少60人。按此计算，高研院一个班级的课程费用为118.8万元，而每个城市具体几个班目前还不得而知。而学员在报名通过初审后，就可以准备15分钟的线上面试了，面试通过后缴纳学费等待分班即可。

其实，面试的部分，主要就是高研院进行的筛选调查，也就是围绕着“学员能为其他同学带来什么”为主题，来判断你是否有资格进入高研院。据剁椒君了解，一些没有通过的学员，主要为以下三个原因，其一可能是对行业的理解和工作经验不符合，其二是刚毕业不久还没有形成一定的职业积累的人，其三是期待的课程和服务，高研院现阶段无法满足。

据以往高研院的学员表示，想要尽快“入学”最好要有推荐人，可以是往届的学员或者是行业优秀人士引荐，而在北京参加高研院的学员还有机会见到创始人罗振宇。其中一位学员还表示自己通过罗振宇的直播课受到了很多启发，就拿塑造自己的朋友圈为例子，要尽量用自己的实名。因为不管一个人的花名用了多久，实名是个人IP职业化第一个步骤。并且通过在朋友圈中多多发表阶段性的议题，来加强互动。

除此之外，高研院的另一个属性就是分享，就像企业家讲好资本故事一样，每个行业的红利，都集中到那些会分享的人身上。其课程深受创业者和各领域中级职场人士喜欢，像公司创始人、数字化营销专家、投资人、医学专家、地产创业者、产品经理、技术IT、设计总监等等都是往期的学员。因此，随着越来越多各行各业的人群不断加入，未来高研院的课程收入，有望成为思维造物的新增长曲线。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**错过上市时机是“一切最好的安排”么？**

梳理完了思维造物的业绩，再来看看公司的欠款情况。截止2021年末，公司负债总额为5.94亿元，同期公司现金等价物为5.51亿元。虽然小于负债，但只有0.43亿元的差额，偿债压力不算太大。

而此前公司IPO拟募集资金10.4亿元，该笔费用全部用于平台的建设与项目升级，并没有设置公司补充流动资金。

不过，此前深交所的第三次问询，有质疑其业绩成长性的具体体现、主营业务的成长空间以及与行业相比的创新性等问题。

因此，不同于罗振宇“一切是最好的安排”，对于思维造物此次撤回上市，艾媒咨询首席分析师张毅认为：“这家企业已经错过了IPO的最佳时机，现在撤回，一方面可能是财务数据超期问题，另一方面是未来的成长性，尤其是今年的延续数据应该不会太好。A股上市要讲究财务数据的持续上涨以及持续盈利的趋势和能力，从这点来说，思维造物有可能会瑕疵。”

除此之外，思维造物没能上市还与创始人罗振宇的过度IP化有关。

并且，思维造物在《招股书》中也提到了，对罗振宇的依赖风险。思维造物进一步表示，虽然跨年演讲、启发俱乐部内容是公司课程研发团队共同创作而成，但罗振宇作为其主讲人，进而在宣传及活动组织上存在一定程度的依赖。因此，如果未来罗振宇不再参与公司业务宣传或跨年演讲、启发俱乐部等活动，其业绩可能会受到影响。

另外，公司线下知识服务业务，除了高研院之外还有“时间的朋友”跨年演讲所带来的收入。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

来源：得到公众号截图

从2018—2021年，其跨年演讲赞助费共计1.7亿元，是期间2719万元门票的5倍左右。由此看来，跨年演讲的主要收益来自于赞助费。而2021年，罗振宇以及李天田（也是公司的股东）参与的线上知识服务课程收入为8374.24万元，再加上同年跨年演讲赞助的3658.28万元（2021年受疫情影响，演讲是空场举办的，所以门票没有收入），罗振宇个人IP创造的营收至少达1.2亿元。

更神奇的是，2019—2021年期间公司的第一大客户销售均来自跨年演讲赞助，甚至2019年前五大客户，有4家的销售收入都来自跨年演讲赞助，足以看出罗振宇个人IP的影响力。

此前，吴晓波推动巴九灵上市，也同样涉及到了IP依赖问题。并且为了降低依赖风险吴晓波还将个人频道改为890新商学。

不过于依赖个人IP也有“翻车”的风险，而罗振宇也被扣上了“毒奶”的帽子。这主要是因为他之前在“时间的朋友”被当做正面案例的企业，如今都没能接受住时间的考验。像罗永浩的锤子科技、共享单车OFO、煎饼品牌黄太吉、贾跃亭的乐视等等，夸一个翻车一个。值得一提的是，罗振宇还在其演讲中解读了拼多多的成功“秘笈”，因此网友们纷纷表示，现在罗振宇把压力给到了拼多多。

不过，根据此前拼多多公布的2022年Q1业绩情况来看，其业绩还是较为稳健的，并且业绩涨幅超市场预期。截止今年3月底，拼多多实现营收238亿，同比增长7%，对比阿里和京东一季度的净亏损来看，拼多多不降反增的业绩，让人眼前一亮。如今，阿里“率先”发布了中报业绩——营收同比持平，净利润下降30%，不知道拼多多的中报能否维持其一季度的“高光”，就让我们静待时间的检验吧。

# 

# 

**话题互动**

**你觉得未来罗振宇会重启上市么？**

**\*我们将在留言区中选取一条优质留言送出神秘礼品****![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)，欢迎大家留言讨论！**

**剁主建群啦！****扫下方二维码****添加运营人员，备注公司-姓名-职位便可入群****获取一手资讯，还有剁主准备的专属小福利哦！**

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)