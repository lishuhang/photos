#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
unsplash_update.py — Unsplash 照片库管理工具 (v1.0)

功能:
  1. 检查 Unsplash 用户已有照片
  2. 对比 GitHub 图片仓库 (modem-56k/img) 找出未上传的照片
  3. 通过 Unsplash API 上传新照片 (需 Bearer Token + write_photos 权限)
  4. 管理照片集合 (创建/更新/添加照片)
  5. 严格遵守 Demo 等级限额: 50 请求/小时 (脚本内预留为 40 次/小时)

认证方式 (无需 Cookie):
  - 公开读取: Authorization: Client-ID <Access Key>
  - 用户操作: Authorization: Bearer <Bearer Token>
    · Bearer Token 通过 OAuth 授权流程获取 (一次性操作)
    · 需要权限范围: public read_user write_photos

获取 Bearer Token:
  1. 在 Unsplash 应用设置中确保 Redirect URI 为 urn:ietf:wg:oauth:2.0:oob
  2. 在浏览器中访问以下 URL (替换 YOUR_ACCESS_KEY):
     https://unsplash.com/oauth/authorize?client_id=YOUR_ACCESS_KEY&redirect_uri=urn:ietf:wg:oauth:2.0:oob&response_type=code&scope=public+read_user+write_photos
  3. 授权后页面显示授权码 (code)
  4. 运行: python unsplash_update.py auth <code>
     脚本将自动用 code 换取 Bearer Token 并保存到 .env

用法:
  python unsplash_update.py                          # 自动模式: 对比并上传新照片
  python unsplash_update.py auth <code>              # 用授权码换取 Bearer Token
  python unsplash_update.py status                   # 查看用户状态和上传配额
  python unsplash_update.py list                     # 列出已上传的照片
  python unsplash_update.py collections              # 列出收藏集
  python unsplash_update.py upload <image_path>      # 上传单张照片

环境变量 (在 .env 文件中配置):
  UNSPLASH_ACCESS_KEY   — 应用 Access Key (必填)
  UNSPLASH_SECRET_KEY   — 应用 Secret Key (获取 Bearer Token 时需要)
  UNSPLASH_BEARER_TOKEN — OAuth Bearer Token (上传/写操作必填)
  UNSPLASH_REDIRECT_URI— OAuth 回调 URI (默认 urn:ietf:wg:oauth:2.0:oob)
  GITHUB_TOKEN          — GitHub Token (读取图片仓库时需要)

版本: 1.0 (2026-06-13)
"""

import os
import sys
import json
import time
import re
import base64
from datetime import datetime
from pathlib import Path
from collections import defaultdict

import requests

# ================= Windows 编码修复 =================
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except AttributeError:
        import codecs
        sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
        sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())
# ====================================================

# ─── 配置 ─────────────────────────────────────────────
UNSPLASH_API_BASE = "https://api.unsplash.com"
GITHUB_API_BASE = "https://api.github.com"

# 图片仓库 (与 photos_update.py 一致)
IMG_REPO = "modem-56k/img"

# Demo 等级限额: 50 请求/小时
# 预留 10 次缓冲给其他可能的 API 调用, 脚本自身限制 40 次/小时
RATE_LIMIT_PER_HOUR = 40
RATE_LIMIT_BUFFER = 10  # 总限额 50, 预留 10

# 每次运行最大上传数量 (每次上传至少消耗 2 次 API: 1次检查 + 1次上传)
MAX_UPLOADS_PER_RUN = 15

# 请求间隔 (秒): 3600 / 40 = 90 秒/次 (确保不超限额)
MIN_REQUEST_INTERVAL = 90

# ─── 加载 .env ──────────────────────────────────────────
def load_env():
    """从脚本同级 .env 文件加载环境变量"""
    env_path = Path(__file__).resolve().parent / ".env"
    if env_path.exists():
        with open(env_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, value = line.split("=", 1)
                    os.environ[key.strip()] = value.strip()

load_env()

# ─── 凭证 ──────────────────────────────────────────────
ACCESS_KEY = os.environ.get("UNSPLASH_ACCESS_KEY", "")
SECRET_KEY = os.environ.get("UNSPLASH_SECRET_KEY", "")
BEARER_TOKEN = os.environ.get("UNSPLASH_BEARER_TOKEN", "")
REDIRECT_URI = os.environ.get("UNSPLASH_REDIRECT_URI", "urn:ietf:wg:oauth:2.0:oob")
GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "")

# ─── 速率限制追踪 ──────────────────────────────────────
RATE_TRACK_FILE = Path(__file__).resolve().parent / "unsplash_rate_limit.json"


class RateLimiter:
    """Unsplash API 速率限制追踪器 (Demo: 50 请求/小时)"""

    def __init__(self, limit_per_hour=RATE_LIMIT_PER_HOUR):
        self.limit = limit_per_hour
        self.timestamps = self._load()

    def _load(self):
        """加载历史请求时间戳"""
        if RATE_TRACK_FILE.exists():
            try:
                with open(RATE_TRACK_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    # 只保留最近 2 小时的时间戳
                    cutoff = time.time() - 7200
                    return [t for t in data.get("timestamps", []) if t > cutoff]
            except (json.JSONDecodeError, OSError):
                pass
        return []

    def _save(self):
        """保存请求时间戳"""
        try:
            with open(RATE_TRACK_FILE, "w", encoding="utf-8") as f:
                json.dump({"timestamps": self.timestamps}, f)
        except OSError:
            pass

    def check(self):
        """检查是否可以发送请求, 不行则等待"""
        now = time.time()
        one_hour_ago = now - 3600

        # 清理过期时间戳
        self.timestamps = [t for t in self.timestamps if t > one_hour_ago]

        if len(self.timestamps) >= self.limit:
            # 计算需要等待的时间
            oldest = self.timestamps[0]
            wait_seconds = max(oldest + 3600 - now + 5, 5)
            print(f"  ⏳ 接近 API 限额 ({len(self.timestamps)}/{self.limit} 次/小时)，"
                  f"等待 {wait_seconds:.0f} 秒...")
            time.sleep(wait_seconds)
            # 重新清理
            self.timestamps = [t for t in self.timestamps if t > time.time() - 3600]

    def record(self):
        """记录一次 API 请求"""
        self.timestamps.append(time.time())
        self._save()

    @property
    def remaining(self):
        """当前小时内剩余可用请求数"""
        one_hour_ago = time.time() - 3600
        recent = [t for t in self.timestamps if t > one_hour_ago]
        return max(0, self.limit - len(recent))


rate_limiter = RateLimiter()


# ─── Unsplash API 工具函数 ─────────────────────────────

def api_get_public(path, params=None):
    """公开 API 请求 (使用 Client-ID / Access Key)"""
    url = f"{UNSPLASH_API_BASE}{path}"
    headers = {
        "Authorization": f"Client-ID {ACCESS_KEY}",
        "Accept-Version": "v1",
        "User-Agent": "unsplash-update-script/1.0"
    }
    rate_limiter.check()
    resp = requests.get(url, headers=headers, params=params, timeout=30)
    rate_limiter.record()

    if resp.status_code == 401:
        print("\n❌ Unsplash 认证失败 (401 Unauthorized)")
        print("  UNSPLASH_ACCESS_KEY 无效，请检查 .env 配置")
        sys.exit(1)

    if resp.status_code == 403:
        print("\n❌ Unsplash 访问被拒绝 (403 Forbidden)")
        print("  可能已超出 Demo 限额 (50 请求/小时)")
        # 输出限额信息
        _print_rate_limit_headers(resp)
        return None

    if resp.status_code == 429:
        print("\n❌ Unsplash API 速率限制 (429 Too Many Requests)")
        _print_rate_limit_headers(resp)
        return None

    resp.raise_for_status()
    return resp.json()


def api_get_authed(path, params=None):
    """用户认证 API 请求 (使用 Bearer Token)"""
    if not BEARER_TOKEN:
        print("❌ 需要 Bearer Token 才能执行此操作")
        print("  请运行: python unsplash_update.py auth <code>")
        print("  获取授权码: 在浏览器中访问以下 URL:")
        auth_url = (
            f"https://unsplash.com/oauth/authorize?"
            f"client_id={ACCESS_KEY}&"
            f"redirect_uri={REDIRECT_URI}&"
            f"response_type=code&"
            f"scope=public+read_user+write_photos"
        )
        print(f"  {auth_url}")
        return None

    url = f"{UNSPLASH_API_BASE}{path}"
    headers = {
        "Authorization": f"Bearer {BEARER_TOKEN}",
        "Accept-Version": "v1",
        "User-Agent": "unsplash-update-script/1.0"
    }
    rate_limiter.check()
    resp = requests.get(url, headers=headers, params=params, timeout=30)
    rate_limiter.record()

    if resp.status_code == 401:
        print("\n❌ Bearer Token 无效或已过期 (401)")
        print("  请重新获取: python unsplash_update.py auth <new_code>")
        return None

    if resp.status_code == 403:
        print("\n❌ 权限不足 (403 Forbidden)")
        print("  需要 write_photos 权限才能上传照片")
        return None

    resp.raise_for_status()
    return resp.json()


def api_post_authed(path, data=None, files=None):
    """用户认证 POST 请求 (上传照片等)"""
    if not BEARER_TOKEN:
        print("❌ 需要 Bearer Token 才能执行此操作")
        return None

    url = f"{UNSPLASH_API_BASE}{path}"
    headers = {
        "Authorization": f"Bearer {BEARER_TOKEN}",
        "Accept-Version": "v1",
    }
    rate_limiter.check()
    resp = requests.post(url, headers=headers, data=data, files=files, timeout=120)
    rate_limiter.record()

    if resp.status_code == 401:
        print("\n❌ Bearer Token 无效或已过期 (401)")
        return None

    if resp.status_code == 403:
        print("\n❌ 权限不足 (403 Forbidden)")
        print("  需要 write_photos 权限")
        return None

    if resp.status_code == 422:
        print(f"\n❌ 请求参数错误 (422)")
        try:
            errors = resp.json().get("errors", [])
            for e in errors:
                print(f"  - {e}")
        except Exception:
            print(f"  响应: {resp.text[:200]}")
        return None

    resp.raise_for_status()
    return resp.json()


def _print_rate_limit_headers(resp):
    """打印 API 限额响应头信息"""
    limit = resp.headers.get("X-Ratelimit-Limit", "?")
    remaining = resp.headers.get("X-Ratelimit-Remaining", "?")
    print(f"  API 限额: {remaining}/{limit} 次/小时")


# ─── GitHub API 工具函数 ─────────────────────────────

def github_api_get(url, params=None):
    """发送 GET 请求到 GitHub API"""
    headers = {
        "Authorization": f"token {GITHUB_TOKEN}",
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "unsplash-update-script"
    }
    resp = requests.get(url, headers=headers, params=params, timeout=30)
    if resp.status_code == 401:
        print("❌ GitHub 认证失败 (401)")
        return None
    if resp.status_code == 403:
        reset_time = int(resp.headers.get("X-RateLimit-Reset", time.time() + 60))
        wait_seconds = max(reset_time - int(time.time()), 5) + 2
        print(f"  ⏳ GitHub API 速率限制，等待 {wait_seconds} 秒...")
        time.sleep(wait_seconds)
        resp = requests.get(url, headers=headers, params=params, timeout=30)
    if resp.status_code != 200:
        return None
    return resp.json()


def github_list_dir(repo, path=""):
    """列出 GitHub 仓库中指定路径的目录内容"""
    url = f"{GITHUB_API_BASE}/repos/{repo}/contents/{path}"
    items = github_api_get(url)
    if not items or isinstance(items, dict):
        return []
    return [item["name"] for item in items if item["type"] == "dir"]


def github_list_files(repo, path):
    """列出 GitHub 仓库中指定路径的文件"""
    url = f"{GITHUB_API_BASE}/repos/{repo}/contents/{path}"
    items = github_api_get(url)
    if not items or isinstance(items, dict):
        return []
    return [item["name"] for item in items if item["type"] == "file"]


def github_get_file_url(repo, path):
    """获取 GitHub 仓库文件的 raw URL"""
    return f"https://raw.githubusercontent.com/{repo}/main/{path}"


def github_download_file(repo, path, local_path):
    """从 GitHub 仓库下载文件到本地"""
    url = github_get_file_url(repo, path)
    resp = requests.get(url, timeout=60, stream=True)
    if resp.status_code != 200:
        return False
    with open(local_path, "wb") as f:
        for chunk in resp.iter_content(chunk_size=8192):
            f.write(chunk)
    return True


# ─── OAuth 授权 ────────────────────────────────────────

def exchange_code_for_token(code):
    """用授权码换取 Bearer Token"""
    url = f"{UNSPLASH_API_BASE}/oauth/token"
    data = {
        "client_id": ACCESS_KEY,
        "client_secret": SECRET_KEY,
        "redirect_uri": REDIRECT_URI,
        "code": code,
        "grant_type": "authorization_code"
    }
    print("🔄 正在用授权码换取 Bearer Token...")
    resp = requests.post(url, data=data, timeout=30)

    if resp.status_code != 200:
        print(f"❌ 获取 Token 失败 (HTTP {resp.status_code})")
        try:
            errors = resp.json().get("errors", resp.json().get("error", ""))
            print(f"  错误: {errors}")
        except Exception:
            print(f"  响应: {resp.text[:200]}")
        return None

    result = resp.json()
    token = result.get("access_token", "")
    if not token:
        print("❌ 响应中没有 access_token")
        print(f"  响应: {json.dumps(result, indent=2)}")
        return None

    print("✅ 成功获取 Bearer Token!")
    print(f"  Token: {token[:10]}...{token[-5:]}")
    if result.get("scope"):
        print(f"  权限范围: {result['scope']}")

    # 保存到 .env 文件
    _save_token_to_env(token)
    return token


def _save_token_to_env(token):
    """将 Bearer Token 保存到 .env 文件"""
    env_path = Path(__file__).resolve().parent / ".env"

    lines = []
    if env_path.exists():
        with open(env_path, "r", encoding="utf-8") as f:
            lines = f.readlines()

    # 更新或添加 UNSPLASH_BEARER_TOKEN
    token_line_found = False
    new_lines = []
    for line in lines:
        if line.strip().startswith("UNSPLASH_BEARER_TOKEN="):
            new_lines.append(f"UNSPLASH_BEARER_TOKEN={token}\n")
            token_line_found = True
        else:
            new_lines.append(line)

    if not token_line_found:
        # 在第一个 UNSPLASH_ 行之后插入
        inserted = False
        for line in new_lines:
            if not inserted and line.strip().startswith("UNSPLASH_"):
                # 在这一行后面添加
                pass
            new_lines_clean = []
            for l in new_lines:
                new_lines_clean.append(l)
                if not inserted and l.strip().startswith("UNSPLASH_"):
                    # 不插入, 继续找最后一个
                    pass
            break
        # 如果没找到合适位置，追加到末尾
        new_lines.append(f"UNSPLASH_BEARER_TOKEN={token}\n")

    try:
        with open(env_path, "w", encoding="utf-8") as f:
            f.writelines(new_lines)
        print(f"  Token 已保存到 {env_path}")
    except OSError as e:
        print(f"  ⚠️ 保存 Token 到 .env 失败: {e}")
        print(f"  请手动添加: UNSPLASH_BEARER_TOKEN={token}")


def print_auth_url():
    """打印 OAuth 授权 URL 供用户手动访问"""
    print("\n📋 获取 Bearer Token 步骤:")
    print("=" * 60)
    print("1. 确保在 Unsplash 应用设置中 Redirect URI 为:")
    print(f"   {REDIRECT_URI}")
    print()
    print("2. 在浏览器中访问以下 URL 并授权:")
    auth_url = (
        f"https://unsplash.com/oauth/authorize?"
        f"client_id={ACCESS_KEY}&"
        f"redirect_uri={REDIRECT_URI}&"
        f"response_type=code&"
        f"scope=public+read_user+write_photos"
    )
    print(f"   {auth_url}")
    print()
    print("3. 授权后页面会显示授权码 (code)")
    print()
    print("4. 运行以下命令换取 Token:")
    print(f"   python unsplash_update.py auth <授权码>")
    print("=" * 60)


# ─── 核心功能 ──────────────────────────────────────────

def get_user_profile():
    """获取当前认证用户的个人信息"""
    result = api_get_authed("/me")
    if result:
        print(f"\n👤 用户信息:")
        print(f"  用户名: {result.get('username', 'N/A')}")
        print(f"  姓名: {result.get('first_name', '')} {result.get('last_name', '')}")
        print(f"  照片数: {result.get('total_photos', 0)}")
        print(f"  收藏集: {result.get('total_collections', 0)}")
        print(f"  下载量: {result.get('downloads', 0)}")
        uploads_remaining = result.get('uploads_remaining', 'N/A')
        print(f"  剩余上传配额: {uploads_remaining}")
        return result
    return None


def list_user_photos(username=None, page=1, per_page=30):
    """列出用户的已上传照片"""
    if username:
        path = f"/users/{username}/photos"
        result = api_get_public(path, params={"page": page, "per_page": per_page})
    else:
        # 使用认证接口获取自己的照片
        result = api_get_authed("/users/me/photos", params={"page": page, "per_page": per_page})

    if not result:
        return []

    photos = []
    for photo in result:
        photos.append({
            "id": photo.get("id"),
            "description": photo.get("description") or photo.get("alt_description") or "",
            "created_at": photo.get("created_at", ""),
            "width": photo.get("width", 0),
            "height": photo.get("height", 0),
        })

    return photos


def list_collections(username=None, page=1, per_page=20):
    """列出用户的收藏集"""
    if username:
        path = f"/users/{username}/collections"
        result = api_get_public(path, params={"page": page, "per_page": per_page})
    else:
        result = api_get_authed("/users/me/collections", params={"page": page, "per_page": per_page})

    if not result:
        return []

    collections = []
    for coll in result:
        collections.append({
            "id": coll.get("id"),
            "title": coll.get("title", ""),
            "description": coll.get("description") or "",
            "total_photos": coll.get("total_photos", 0),
            "private": coll.get("private", False),
        })

    return collections


def upload_photo(image_path, description="", tags=None):
    """上传一张照片到 Unsplash

    注意: 官方 Unsplash API 文档未公开上传端点 (POST /photos)。
    此功能尝试通过 API 上传，如果失败则会给出提示。

    参数:
        image_path: 本地图片文件路径
        description: 照片描述
        tags: 标签列表 (字符串, 逗号分隔)
    """
    if not os.path.isfile(image_path):
        print(f"❌ 文件不存在: {image_path}")
        return False

    file_size = os.path.getsize(image_path)
    if file_size > 25 * 1024 * 1024:  # 25MB 限制
        print(f"❌ 文件过大 ({file_size / 1024 / 1024:.1f}MB)，Unsplash 限制 25MB")
        return False

    ext = Path(image_path).suffix.lower()
    if ext not in ('.jpg', '.jpeg', '.png', '.gif', '.webp'):
        print(f"❌ 不支持的格式: {ext}")
        return False

    filename = Path(image_path).name

    print(f"  📤 上传: {filename} ({file_size / 1024:.0f}KB)")

    try:
        with open(image_path, "rb") as f:
            files = {"file": (filename, f, f"image/{ext.lstrip('.')}")}
            data = {}
            if description:
                data["description"] = description

            result = api_post_authed("/photos", data=data, files=files)

        if result:
            photo_id = result.get("id", "?")
            print(f"  ✅ 上传成功! Photo ID: {photo_id}")
            return True
        else:
            print(f"  ❌ 上传失败 (API 未返回有效响应)")
            print("  提示: 如果 API 不支持上传，请通过网页手动上传:")
            print("  https://unsplash.com/submit")
            return False

    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 404:
            print(f"  ❌ 上传端点不可用 (404 Not Found)")
            print("  Unsplash 官方 API 可能不支持通过 API 上传照片")
            print("  请通过网页上传: https://unsplash.com/submit")
        elif e.response.status_code == 405:
            print(f"  ❌ 上传方法不被允许 (405 Method Not Allowed)")
            print("  Unsplash 官方 API 不支持 POST /photos 上传")
            print("  请通过网页上传: https://unsplash.com/submit")
        else:
            print(f"  ❌ 上传失败: {e}")
        return False
    except Exception as e:
        print(f"  ❌ 上传异常: {e}")
        return False


def scan_github_photos():
    """扫描 GitHub 图片仓库中最近的图片

    返回: [(relative_path, filename), ...] 列表
    """
    if not GITHUB_TOKEN:
        print("❌ 未配置 GITHUB_TOKEN，无法扫描 GitHub 图片仓库")
        return []

    print(f"🔍 扫描 GitHub 图片仓库: {IMG_REPO}")

    # 获取最近 3 个月的图片
    now = datetime.now()
    photos = []
    image_extensions = {".jpg", ".jpeg", ".png", ".gif", ".webp"}

    # 只检查最近 3 个月
    for month_offset in range(3):
        check_date = datetime(now.year, now.month - month_offset, 1) if now.month - month_offset > 0 else datetime(now.year - 1, 12 + now.month - month_offset, 1)
        year = str(check_date.year)
        month = f"{check_date.month:02d}"

        days = github_list_dir(IMG_REPO, f"{year}/{month}")
        if not days:
            continue

        for day in sorted(days, reverse=True):
            if not re.match(r"^\d{2}$", day):
                continue
            day_path = f"{year}/{month}/{day}"
            files = github_list_files(IMG_REPO, day_path)
            image_files = [f for f in files if Path(f).suffix.lower() in image_extensions]
            for img_file in sorted(image_files):
                photos.append((day_path, img_file))

    print(f"  📷 发现 {len(photos)} 张最近 3 个月的图片")
    return photos


def get_unsplash_photo_filenames():
    """获取 Unsplash 上已上传照片的文件名列表 (通过描述匹配)"""
    print("🔍 检查 Unsplash 已有照片...")

    # 获取自己的照片
    all_photos = []
    page = 1
    while True:
        photos = list_user_photos(page=page, per_page=30)
        if not photos:
            break
        all_photos.extend(photos)
        if len(photos) < 30:
            break
        page += 1
        if page > 10:  # 最多查 10 页 (300 张)
            break

    print(f"  📷 Unsplash 上已有 {len(all_photos)} 张照片")
    return all_photos


def auto_upload():
    """自动模式: 对比 GitHub 图片仓库和 Unsplash，上传新照片"""
    print("=" * 60)
    print("🖼️  Unsplash 照片自动同步工具")
    print("=" * 60)
    print(f"  API 限额: Demo (50 请求/小时)")
    print(f"  脚本预留: 40 请求/小时 (缓冲 10)")
    print(f"  剩余请求: {rate_limiter.remaining}")
    print()

    # 1. 检查凭证
    if not ACCESS_KEY:
        print("❌ 未配置 UNSPLASH_ACCESS_KEY")
        print("  请在 .env 文件中配置 Unsplash 凭证")
        return False

    # 2. 获取用户信息
    profile = get_user_profile()
    if not profile:
        return False

    username = profile.get("username", "")
    uploads_remaining = profile.get("uploads_remaining", 0)
    print(f"\n  用户: {username}")
    print(f"  剩余上传配额: {uploads_remaining}")

    if uploads_remaining == 0:
        print("\n⚠️ Unsplash 上传配额已用尽，今日无法上传")
        print("  Unsplash 对每日上传数量有限制，请明天再试")
        return False

    # 3. 获取已上传照片
    existing_photos = get_unsplash_photo_filenames()

    # 构建已上传照片的描述集合 (用于去重)
    existing_descriptions = set()
    for p in existing_photos:
        desc = p.get("description", "")
        if desc:
            existing_descriptions.add(desc.lower())

    # 4. 扫描 GitHub 图片仓库
    github_photos = scan_github_photos()
    if not github_photos:
        print("\n✨ GitHub 图片仓库中没有最近的照片")
        return True

    # 5. 找出需要上传的照片 (简单去重: 通过文件名匹配描述)
    to_upload = []
    for day_path, filename in github_photos:
        # 用文件名 (不含扩展名) 作为描述
        name_without_ext = Path(filename).stem
        if name_without_ext.lower() not in existing_descriptions:
            to_upload.append((day_path, filename))

    if not to_upload:
        print("\n✨ 所有照片已上传，无需同步")
        return True

    print(f"\n📋 需要上传 {len(to_upload)} 张新照片")

    # 6. 限制上传数量
    max_upload = min(MAX_UPLOADS_PER_RUN, uploads_remaining, rate_limiter.remaining // 2)
    if max_upload <= 0:
        print("\n⚠️ API 请求配额不足，无法上传")
        print(f"  剩余 API 请求: {rate_limiter.remaining}")
        return False

    if len(to_upload) > max_upload:
        print(f"  ⚠️ 本次最多上传 {max_upload} 张 (受 API 限额/上传配额限制)")
        to_upload = to_upload[:max_upload]

    # 7. 下载并上传
    tmp_dir = Path(__file__).resolve().parent / "tmp"
    tmp_dir.mkdir(exist_ok=True)

    uploaded = 0
    failed = 0

    for i, (day_path, filename) in enumerate(to_upload, 1):
        print(f"\n[{i}/{len(to_upload)}] 处理: {day_path}/{filename}")

        # 下载到临时目录
        github_path = f"{day_path}/{filename}"
        local_path = tmp_dir / filename

        print(f"  ⬇️  下载: {github_path}")
        if not github_download_file(IMG_REPO, github_path, str(local_path)):
            print(f"  ❌ 下载失败，跳过")
            failed += 1
            continue

        # 上传到 Unsplash
        name_without_ext = Path(filename).stem
        success = upload_photo(
            str(local_path),
            description=name_without_ext
        )

        if success:
            uploaded += 1
        else:
            failed += 1

        # 清理临时文件
        try:
            local_path.unlink()
        except OSError:
            pass

        # 速率限制: 请求间等待
        if i < len(to_upload):
            wait = MIN_REQUEST_INTERVAL
            print(f"  ⏳ 等待 {wait} 秒 (速率限制)...")
            time.sleep(wait)

    # 8. 汇总
    print(f"\n{'='*60}")
    print(f"📊 同步完成:")
    print(f"  ✅ 成功上传: {uploaded}")
    print(f"  ❌ 失败: {failed}")
    print(f"  📋 剩余待上传: {len(to_upload) - uploaded - failed}")
    print(f"  🔢 API 剩余请求: {rate_limiter.remaining}")
    print(f"{'='*60}")

    return uploaded > 0


# ─── 主入口 ──────────────────────────────────────────────

def main():
    if len(sys.argv) < 2:
        # 默认: 自动模式
        auto_upload()
        return

    command = sys.argv[1].lower()

    if command == "auth":
        # OAuth 授权码换取 Token
        if not ACCESS_KEY or not SECRET_KEY:
            print("❌ 请先在 .env 中配置 UNSPLASH_ACCESS_KEY 和 UNSPLASH_SECRET_KEY")
            sys.exit(1)
        if len(sys.argv) < 3:
            print("用法: python unsplash_update.py auth <授权码>")
            print()
            print_auth_url()
            sys.exit(1)
        code = sys.argv[2]
        exchange_code_for_token(code)

    elif command == "status":
        # 查看用户状态
        if not ACCESS_KEY:
            print("❌ 请先在 .env 中配置 UNSPLASH_ACCESS_KEY")
            sys.exit(1)
        print("=" * 60)
        print("📊 Unsplash 账户状态")
        print("=" * 60)
        profile = get_user_profile()
        if profile:
            print(f"\n  API 限额: Demo (50 请求/小时)")
            print(f"  脚本剩余请求: {rate_limiter.remaining}")

    elif command == "list":
        # 列出已有照片
        if not ACCESS_KEY:
            print("❌ 请先在 .env 中配置 UNSPLASH_ACCESS_KEY")
            sys.exit(1)
        print("=" * 60)
        print("📷 已上传照片列表")
        print("=" * 60)
        photos = list_user_photos()
        if photos:
            for i, p in enumerate(photos, 1):
                desc = p.get("description", "(无描述)")[:40]
                date_str = p.get("created_at", "")[:10]
                print(f"  {i:3d}. [{date_str}] {desc}")
            print(f"\n  共 {len(photos)} 张")
        else:
            print("  (空)")

    elif command == "collections":
        # 列出收藏集
        if not ACCESS_KEY:
            print("❌ 请先在 .env 中配置 UNSPLASH_ACCESS_KEY")
            sys.exit(1)
        print("=" * 60)
        print("📁 收藏集列表")
        print("=" * 60)
        colls = list_collections()
        if colls:
            for i, c in enumerate(colls, 1):
                priv = "🔒" if c.get("private") else "🌐"
                print(f"  {i}. {priv} {c['title']} ({c['total_photos']} 张)")
        else:
            print("  (空)")

    elif command == "upload":
        # 上传单张照片
        if len(sys.argv) < 3:
            print("用法: python unsplash_update.py upload <image_path>")
            sys.exit(1)
        image_path = sys.argv[2]
        desc = sys.argv[3] if len(sys.argv) > 3 else ""
        if not BEARER_TOKEN:
            print("❌ 需要 Bearer Token 才能上传")
            print_auth_url()
            sys.exit(1)
        upload_photo(image_path, description=desc)

    elif command == "help":
        print(__doc__)

    else:
        print(f"❌ 未知命令: {command}")
        print("可用命令: auth, status, list, collections, upload, help")
        print("或直接运行 (无参数) 进入自动模式")
        sys.exit(1)


if __name__ == "__main__":
    main()
