import feedparser
from datetime import datetime, timedelta
import re
import json
from difflib import SequenceMatcher
from bs4 import BeautifulSoup
import urllib.error
import ssl
import logging
import socket
import os
import sys

# ================= Windows 编码修复 =================
# Windows 默认控制台编码为 cp1252，无法输出中文等超出 Latin-1 范围的字符
# 在所有 print()/logging 输出之前，强制将 stdout/stderr 切换为 UTF-8
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except AttributeError:
        import codecs
        sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
        sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())
# ====================================================

# ================= 配置区域 =================
# 全局超时时间（秒）
GLOBAL_TIMEOUT = 60
socket.setdefaulttimeout(GLOBAL_TIMEOUT)

# 脚本所在目录
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# 临时文件目录 (v1.1: 中间结果输出到 tmp/)
TMP_DIR = os.path.join(SCRIPT_DIR, "tmp")

# 日志目录 (v1.1: 统一日志到 logs/)
LOG_DIR = os.path.join(SCRIPT_DIR, "logs")
# ===========================================

# 配置日志记录 (v1.1: 输出到 logs/)
os.makedirs(LOG_DIR, exist_ok=True)
log_name = datetime.now().strftime("%Y%m%d_%H%M%S") + ".log"
log_path = os.path.join(LOG_DIR, f"getrss_{log_name}")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s',
                    handlers=[
                        logging.FileHandler(log_path, encoding='utf-8'),
                        logging.StreamHandler()
                    ])
logger = logging.getLogger(__name__)

# 禁用SSL证书验证
ssl._create_default_https_context = ssl._create_unverified_context

# 从外部json文件中加载RSS feed列表和关键词列表
def load_config(file_path):
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logger.error(f"配置文件 {file_path} 未找到")
        raise
    except json.JSONDecodeError as e:
        logger.error(f"配置文件 {file_path} 格式错误: {e}")
        raise

def fetch_rss_entries(feed_tuples):
    entries = []
    for feed in feed_tuples:
        feed_url = feed["url"]
        if feed_url.startswith('//'):
            logger.info(f"跳过已注释的RSS源: {feed_url}")
            continue
            
        logger.info(f"正在获取RSS源: {feed_url}")
        
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            
            rss_feed = feedparser.parse(feed_url, request_headers=headers)
            
            if rss_feed.bozo:
                logger.warning(f"RSS源 {feed_url} 解析时出现问题: {rss_feed.bozo_exception}")
            
            if not rss_feed.entries:
                logger.warning(f"RSS源 {feed_url} 没有返回任何条目 (可能是网络超时或源为空)")
                continue
                
            logger.info(f"从 {feed_url} 获取到 {len(rss_feed.entries)} 个条目")
            
            for entry in rss_feed.entries:
                entry_datetime = None
                if hasattr(entry, 'published_parsed') and entry.published_parsed is not None:
                    entry_datetime = datetime(*entry.published_parsed[:6])
                elif hasattr(entry, 'updated_parsed') and entry.updated_parsed is not None:
                    entry_datetime = datetime(*entry.updated_parsed[:6])
                else:
                    entry_datetime = datetime.now()
                    logger.warning(f"条目 '{entry.title}' 没有时间信息，使用当前时间")
                
                if entry_datetime > datetime.now() - timedelta(days=1):
                    entries.append({
                        "title": entry.title, 
                        "link": entry.link,
                        "published": entry_datetime
                    })
        
        except socket.timeout:
            logger.error(f"获取RSS源 {feed_url} 超时 (超过 {GLOBAL_TIMEOUT} 秒)，已跳过")
            continue
        except (urllib.error.URLError, ConnectionResetError, ssl.SSLError) as e:
            logger.error(f"获取RSS源 {feed_url} 时发生网络错误: {e}")
            continue
        except Exception as e:
            logger.error(f"处理RSS源 {feed_url} 时发生未知错误: {e}")
            continue
            
    logger.info(f"总共获取到 {len(entries)} 个有效条目")
    return entries

def filter_by_keywords(entries, keywords):
    if not keywords:
        logger.warning("没有提供关键词，返回所有条目")
        return entries
        
    filtered = []
    for entry in entries:
        for keyword in keywords:
            if keyword.lower() in entry["title"].lower():
                filtered.append(entry)
                break
                
    logger.info(f"关键词过滤后剩余 {len(filtered)} 个条目")
    return filtered

def clean_text(text):
    text = BeautifulSoup(text, "html.parser").get_text()
    text = text.lower()
    text = re.sub(r'\s*[\[(].*?[\])]\s*', '', text)
    text = re.sub(r'\s*-\s*.*$', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    text = re.sub(r'[^\w\s]', '', text)
    text = re.sub(r'\bai\b', '', text)
    return text

def are_similar(entry1, entry2, threshold=0.85):
    return SequenceMatcher(None, entry1, entry2).ratio() > threshold

def process_entries(entries):
    if not entries:
        logger.warning("没有条目需要处理")
        return []
        
    unique_entries = []
    cleaned_titles = set()

    entries.sort(key=lambda x: x['published'], reverse=True)

    for entry in entries:
        title = entry['title']
        title = re.sub(r'<.*?>', '', title)
        title = re.sub(r'人工智能|artificial intelligence', 'AI', title, flags=re.I)
        title = re.sub(r'（.*?）$', '', title)
        cleaned_title = clean_text(title)

        is_duplicate = False
        if cleaned_title in cleaned_titles:
            is_duplicate = True

        if not is_duplicate:
            for existing_title in cleaned_titles:
                if are_similar(cleaned_title, existing_title):
                    is_duplicate = True
                    logger.info(f"跳过相似条目: 原 - '{existing_title}' | 新 - '{cleaned_title}'")
                    break
        
        if not is_duplicate:
            cleaned_titles.add(cleaned_title)
            unique_entries.append({
                "title": title.strip(),
                "link": entry["link"]
            })

    chinese_entries = sorted(
        [e for e in unique_entries if re.search(r'[\u4e00-\u9fff]', e["title"])],
        key=lambda x: x["title"]
    )
    english_entries = sorted(
        [e for e in unique_entries if not re.search(r'[\u4e00-\u9fff]', e["title"])],
        key=lambda x: x["title"]
    )
    
    result = chinese_entries + english_entries
    logger.info(f"处理后得到 {len(result)} 个唯一条目")
    return result

def to_markdown(entries):
    if not entries:
        return "暂无相关内容\n"
    
    return "\n".join(f"- [{entry['title']}]({entry['link']})" for entry in entries) + "\n"

if __name__ == "__main__":
    try:
        logger.info("开始执行RSS处理脚本")
        
        # v1.1: 从脚本目录读取配置文件
        rss_config = load_config(os.path.join(SCRIPT_DIR, "rss_feeds.json"))
        keyword_config = load_config(os.path.join(SCRIPT_DIR, "keywords.json"))
        
        all_keywords = []
        for category in keyword_config["keywords"]:
            all_keywords.extend(keyword_config["keywords"][category])
        all_keywords = list(set(all_keywords))

        logger.info(f"加载了 {len(rss_config['feeds'])} 个RSS源")
        logger.info(f"加载了 {len(all_keywords)} 个关键词")
        
        all_entries = fetch_rss_entries(rss_config["feeds"])
        filtered_entries = filter_by_keywords(all_entries, all_keywords)
        processed_entries = process_entries(filtered_entries)
        markdown_output = to_markdown(processed_entries)
        
        # v1.1: 中间结果输出到 tmp/ 目录
        os.makedirs(TMP_DIR, exist_ok=True)
        output_file = os.path.join(TMP_DIR, f"rss_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.md")
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(markdown_output)

        logger.info(f"处理完成，结果已保存到 {output_file}")
        print(f"Processed Markdown saved to {output_file}")
        
    except FileNotFoundError as e:
        logger.error(f"配置文件未找到: {e}")
        print(f"Config file not found: {e}")
    except Exception as e:
        logger.error(f"发生错误: {e}")
        print(f"An error occurred: {e}")
