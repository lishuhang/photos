# 泛内容领域，最大的一次入局机会丨本图文由AI生成

> 公众号: 娱乐资本论
> 发布时间: ref: <Node>
> 原文链接: https://mp.weixin.qq.com/s/6p2ONr9HJfj5PAWU5vJtPA

---

![图片](http://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd4r7pFn9tFEcS7TZEtXLR3yvvt00Miccx7KRtVCVSD8wdq94H9WYoUtM2Eed3BWk2BqrPibT2UiakVtw/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)

整个3、4月以来，可以说是AI一天，人间一年：前一天还和往常一样甜甜睡去，第二天醒来就发现AI扔了个炸弹颠覆自己的工作，甚至行业：

以ChatGPT为代表的语言模型，以Stable Diffusion（Midjourney只是其中一个应用）为代表的AI绘画产品，让世界见识了AI的效率及能力。之后，微软将AI应用到搜索引擎Bing，Office全家桶可以一键做PPT、Excel，Adobe的Firefly可以一键P图，Cursor更让小白也懂写代码……

世界变化太快，打工人忧心忡忡，AI会不会让我失业？而老板们则四处互相交流：AI来了，谁在偷偷使用，会不会把我们消灭？

不信，让我们问问ChatGPT，哪个行业会最先受到冲击：

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

好的，没想到精准的打击到了娱乐资本论的客户人群，当然也包括娱乐资本论自己。

实话说，娱资虽然是个文科生群体，但已经在全面转型AI，不说文章写作、图片美化这些最基础的，甚至老板都开始自己做视频、写贪吃蛇的代码了。（当然，可以先从买个电脑开始![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)）

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

AI到底有什么价值，要不让AI自己来说吧：

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

有时候不得不感慨，好像AI比我们都更知道AI对这个行业的变革，对我们工作的挑战、乃至对我们的人生的影响，你就算不相信AI，难道还不相信微软、谷歌、Adobe、华为这些大公司的顶级科学家，以及阅文侯晓楠、心动黄一孟、光线王长田、陆川导演等圈内人吗？

更可怕的是各种业内消息传来，真假莫辨，什么原画组砍了三分之二的人、什么山东农妇用AI一天产生自媒体团队一个月的工作量、什么几分钟生成的一张海报就能省几万元、什么大厂里的卷神用AI做了全组的Excel、什么免费小说网站开始AI写作……

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

但据我们内部调查，真正用过ChatGPT、Stable Diffusion（或Midjourney）的人，为什么在这个行业还是不足十分之一呢，即使这个行业已经都到了火烧眉毛的阶段？

几个原因：

1、没有账号

2、缺乏跨语言环境和网络环境

3、心理学的“信息过载”效应，导致行动力缺乏，看看ChatGPT怎么分析的：

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

实话说，我们曾经就是这样的人群，每天被AI新闻疯狂的侵袭，恐惧、害怕到最后不得不选择麻木，甚至还有人疯狂转发AI毁灭人类的言论，即使他从来没有使用过这些软件……直到，我们身边出现了玩AI很溜的朋友，他们愿意手把手交我们安装、借我们账号。

面对这样的困扰，我们经历过，也克服过，我们也想把这样的学习经验分享给到大家，而且为了更有效的学习，我们选了一种非常笨重的方式——线下保姆式教学。

面对随随便便线上开课就能有数千人参与的诱惑，我们觉得那样很多时候只能满足下单买课时的一种“即时满足”，但真正对学员有益的，仍是手把手教育，面对面交流，或许这也是这个AI时代，人类仅剩的温柔。不信你看ChatGPT怎么说：

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

当然，我们一定会找到这个行业最前沿的大咖，最实操的讲师，真正带大家，即涨了见识，又练了技能：

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

对了，本文标题也是参考了AI的文案。而AI生成的原始标题如下，您看看觉得是不是比现在的要好呢？

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**推荐阅读**

[![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247573088&idx=1&sn=814d0d11e8d94fbd7c590e2d47cf7418&chksm=c058cbbbf72f42ada0039b3530950c203f2599d3531a2e3cc16b5986ad546f63f3cc9421e434&scene=21#wechat_redirect)

[![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247573992&idx=1&sn=bf861d3333a72cefa805748c38dcb16c&chksm=c058b433f72f3d2519e6f37d609e626fcab346d68832c4d7d0caf75fd7b3c11f7254b1a4bf53&scene=21#wechat_redirect)

**选秀节目消亡后，秀人和公司如何求生？**

**点击观看**

**↓↓↓**

**如需商务合作后台回复【商务】**

**如有转载需求后台回复【转载】**

**更多文娱产业背后的经济逻辑，来关注↓↓↓**