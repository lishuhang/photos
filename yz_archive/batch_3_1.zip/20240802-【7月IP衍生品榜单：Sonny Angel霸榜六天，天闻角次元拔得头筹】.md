# 7月IP衍生品榜单：Sonny Angel霸榜六天，天闻角次元拔得头筹

> 公众号: 娱乐资本论
> 发布时间: 2024年8月2日 12:00
> 原文链接: https://mp.weixin.qq.com/s/iBwNpwdr4On2JpN3mE9McA

---

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd6F6Y83LIszsXQfh29diaibTrvdjPqibu60xsQU6ibS1dT8EPdb6tCiatlw2zaic62tkzcaicEmpWFcszUgg/640?wx_fmt=jpeg&from=appmsg#imgIndex=0)

**作者｜九橘**

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6F6Y83LIszsXQfh29diaibTr3TeAhEqwPmVIbTLr28yAn6FmQQNdkUeBcoWGHia8WCTglcRCuWTXjUg/640?wx_fmt=png&from=appmsg#imgIndex=1)

**盲盒和手办：泡泡玛特、SHONENJUMPSHOP二分天下，Sonny Angel霸榜六天**

首先来看本月的天猫盲盒热销榜。

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd5DSjage4O8SR5cmYDbvlibrbicIHcPk8FL1xGJnE7OPPc76e1363pz6FzVmlg7FH1DNoF3Hxex8JAA/640?wx_fmt=jpeg&from=appmsg#imgIndex=2)

**泡泡玛特凭借浪漫指尖系列场景手办排名第一。**泡泡玛特作为头部的潮流玩具品牌，一直是创意无限，上新速度非常快。

浪漫指尖系列作为泡泡玛特的七夕限定系列，在今年七夕前夕推出了第三代。浪漫指尖系列三代加入了新的IP形象CHAKA。并且为了迎合新系列中的太空元素，在盲盒的开启形式上也加入了新的设计，通过转动球体外环将隐藏在球体内的IP形象展示出来，颇具惊喜感。

此外，**Sonny Angel旗舰店推出的趴趴天使可爱盲盒连续六天霸榜前三**，该系列结合兔子、独角兽、奶牛等动物元素塑造人偶形象，共推出12个常规款+1个隐藏款，以“为你装饰身边事务，点缀生活亮点”为理念，戳中当代年轻人的萌点。

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd5DSjage4O8SR5cmYDbvlibrFXMp1ib1GfpWqKP7uQ27ticZIvaxpYaBZagKq5ZjIjicp5MiafJNVc81CQ/640?wx_fmt=jpeg#imgIndex=3)

再来看手办热销榜   

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd5DSjage4O8SR5cmYDbvlibrFKroiaraaEcoYQGj11Vf7k4urdpicJAX8he7w6xKoQp433ZpwRnUxkBA/640?wx_fmt=jpeg&from=appmsg#imgIndex=4)

本月的手办热销榜夺得**第一的是由锦鲤拿趣推出的《莲花楼》官方系列Q版手办，作为由电视剧衍生的周边手办，展示了《莲花楼》的超强IP属性与超长长尾效应。**

泡泡玛特虽然没能占据榜首，但是仍在前十占据三席之位。

**热销榜前十中，有三个席位都是从热门游戏中衍生出的IP形象，分别来自《崩坏》和《原神》。**

机甲模型方面，**天猫高达模型热销榜上，万代官方旗舰店和爱宝贝动漫专营店霸榜，分别占据三席之位**。其他上榜店铺分别是空格动漫专营点、X11旗舰店、闻巡旗舰店、艺模旗舰店。

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd5DSjage4O8SR5cmYDbvlibr3zDYwhicKDSzCLs8QzetN70mnnnmfSPzu88qzxD6tuMorq5rdUzDCQg/640?wx_fmt=jpeg&from=appmsg#imgIndex=5)

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6F6Y83LIszsXQfh29diaibTr22R5h68ra6cKETkiaMiac8OxkOc6r74Zqicw4rVbKCVjrFkL2RRQq5gNQ/640?wx_fmt=png&from=appmsg#imgIndex=6)

**IP衍生品：天闻角次元拔得头筹，经典IP长盛不衰**

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd5DSjage4O8SR5cmYDbvlibrS23JL0kHdd0P7wdia2KRYicKzq5ZfQCaI3RguH1Hg9dhqVXL5K3a8bIg/640?wx_fmt=jpeg&from=appmsg#imgIndex=7)

**在国创衍生品店方面，天闻角川次元基地排名榜首。**天闻角川次元基地的产品包括泛二次元文创品类。既有从日本引进的动漫IP周边，比如《刀剑神域》、《文豪野犬》等；也有国内的动漫衍生品，比如《全职高手》等；还有天角旗下的玩具品牌天角制造所，Lolita洋装Seino Kawa星河来信。

快看自营商店作为快看漫画在淘宝平台的正品周边店铺，拥有《难哄》、《二哈和他的白猫师尊》、《小蘑菇》等大热IP的正版周边授权，在国创衍生品店铺榜中稳居第二。

**本月的动漫IP衍生品店铺与国创衍生品上榜店铺高度重合。**

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd5DSjage4O8SR5cmYDbvlibrrFqSETIhp5y2CKuLaAyvEC2wvXcf9hQOjQpicUk4j5yibNYXdicBe0OMA/640?wx_fmt=jpeg&from=appmsg#imgIndex=8)

国创衍生品店铺排行榜中有五家店铺都在动漫IP衍生店铺中再度上榜，并且稳居前五。

其中，快看漫画登顶榜首，也让我们看到了大热IP正版周边授权的重要性。

除此之外，排名第七的阿狸的梦王国是一家专营阿狸IP形象的店铺，他的上榜展现了经典IP的超长生命力。

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd5DSjage4O8SR5cmYDbvlibrMRia4H7B3ALNnXIHm9ECUNcLOvxtibcmz66czS9gYbhHEz841SDyqyTg/640?wx_fmt=jpeg#imgIndex=9)

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd5DSjage4O8SR5cmYDbvlibrGlVcs1Grjia3fAwiauz1icLvhrUm12Xu64EXyibqLHgsfQaRnrZb5JlcFA/640?wx_fmt=jpeg&from=appmsg#imgIndex=10)

与五月份相比，**IP价值店铺榜头部表现稳定，南派泛娱继续霸榜**。大笨狗之家掉出榜外，秒吉原创替补出场。

mewji秒吉原创是一家专门做各种猫咪形象周边的原创店铺，店内有猫咪手提包、挂毯、衬衫、袜子、手机壳等多种类型的产品。以其萌萌的IP形象与柔软的触感俘获了大批的少女心。

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd5DSjage4O8SR5cmYDbvlibry3fPbibXqSJBr5Sl6QnzNhuX9MPka18wuNaxxxI1VPB9zXR45h9Mr1A/640?wx_fmt=jpeg#imgIndex=11)

![图片](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6F6Y83LIszsXQfh29diaibTrSehp43ribpQjVk5Jlod5NKE3rr828WF1U3ONJvMm3nxR6rmibFJXyLSQ/640?wx_fmt=png&from=appmsg#imgIndex=12)

**更多文创产品：头部店铺表现稳定，樱姬Lolita再登榜首**

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd5DSjage4O8SR5cmYDbvlibrSwoxNYSEoAibY6hvqicjOxPMwDj5hJiaTxBQD8OU6EEfFbQcSib0YGGtuw/640?wx_fmt=jpeg&from=appmsg#imgIndex=13)

**五月上榜的十家棉花娃娃店铺在7月份全部再次上榜**。这其中宇宙商店表现亮眼，从五月份的垫底一跃跻身店铺前五。

宇宙商店推出的“问题小动物”系列，借助小动物的形象映射人类世界，打出“有小情绪，但积极勇敢、一往无前”的理念，共情年轻人，收割一波粉丝。

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd5DSjage4O8SR5cmYDbvlibrccVp6C5ibwUJ4Hh6Hv6lILu7hK0Y3UaRRmLrYgpFaCxKDnnZWvYibx8w/640?wx_fmt=jpeg#imgIndex=14)

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd5DSjage4O8SR5cmYDbvlibrVKyJGjlOj3ib3zrSX2aRY1T1yoCtW1SQoXrHYryVyZGQJDNH5VicIvYA/640?wx_fmt=jpeg&from=appmsg#imgIndex=15)

本月古韵汉服店铺总体格局变化不大，**十三余 小豆蔻国风工作室、织造司、钟灵记等老牌汉服店铺稳定上榜**。本月新上榜的上遥居汉服，店内主打宋制汉服，夏季上新了更多纱料质感的汉服，风格更偏飘逸，柔软透气，受到更多消费者的青睐。

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd5DSjage4O8SR5cmYDbvlibrH4icTqAOC7ScRWlTxdOqNO5zAQM28fdF1cBtjKCLSfXviaJ5dQWDAXkg/640?wx_fmt=jpeg&from=appmsg#imgIndex=16)

**JK制服店铺榜中，前三仍是梗豆物语、火星institute JK制服馆、花千猪原创**。与五月相比梗豆物语依然霸榜第一，二三名排名调换。除此之外，日暮星河JK制服馆掉出榜外，木村叔dk jk 制服上榜。梗豆物语超季新品已经开始预售，上新了“一块甜薄荷”水手领西服，以及马海毛针织开衫。

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd5DSjage4O8SR5cmYDbvlibrEUIXhvfLfSHqBib2x59mK4Sd13Md1ogN4fAkINrdEzX17ATy97wV8mg/640?wx_fmt=jpeg&from=appmsg#imgIndex=17)

本月BJD玩偶店铺榜中，三万院长swdoll继续蝉联BJD玩偶店铺热卖榜榜首。

3月份排名第二的龙魂人形社，本月掉至第九名，粉丝量增长缓慢，两个月只增长了0.3万粉丝，近30日收藏数较五月份没有发生变化。

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd5DSjage4O8SR5cmYDbvlibrX0MZ8luCR2MiaTo0KW0ZC9EgrrEnxzibZDib8Xx1e0bUK3iaTXwWfems2Q/640?wx_fmt=jpeg&from=appmsg#imgIndex=18)

本月洛丽塔少女店铺榜中，**樱姬Lolita原创设计蝉联第一**。设计师的礼物和麻菟菟初次上榜，其中设计师的礼物店铺近30日收藏数破2.4万，表现亮眼。其余上榜店铺分别为豹了个猫、贵公主Your princess原创工作室、圆点点小姐lolita洋服社和babyblue婴儿蓝等。

![图片](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd6F6Y83LIszsXQfh29diaibTrLpWA6mYU7OBCKOiaScSWhmy5Xo4hoPAIlAvDPSfdicEHvOzZCEY4boJw/640?wx_fmt=jpeg&from=appmsg#imgIndex=19)
