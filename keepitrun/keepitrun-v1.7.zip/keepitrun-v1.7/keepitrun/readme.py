#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
keepitrun - 产品文档 (readme)
版本: 1.4
日期: 2026-06-12

本文件既是可执行脚本（运行后输出文档摘要），也是产品文档本身。
完整文档内容以多行字符串形式保存在 DOC 变量中。

用法:
  python readme.py          # 在控制台输出文档摘要
  python readme.py --full   # 输出完整文档
"""

DOC = r"""
================================================================================
  keepitrun - 全天候定时任务调度系统
  版本 1.4 | 2026-06-12
================================================================================

一、产品概述
────────────────────────────────────────────────────────────────────────────────

keepitrun 是一个基于 Python 的 24 小时常驻定时任务调度系统，运行于
Windows 11（或跨平台）环境。它通过 while True 循环每 30 秒检查一次当前
时间，到点自动触发对应的子脚本执行周期性任务。

核心功能:
  - RSS 订阅源抓取与关键词过滤（AI/科技领域）
  - 多次抓取结果合并、去重、翻译（中英双语）
  - 微信公众号 AIGC 早报自动爬取与发布 (v1.3 重新启用)
  - 微信公众号长文/短篇自动爬取与发布 (v1.2 重新启用)
  - GitHub Pages 照片库自动同步
  - 版本感知任务完成追踪 (v1.3 新增)
  - [已修复] 所有子脚本 Windows 控制台 UnicodeEncodeError (v1.4)
  - Unsplash 照片管理 (v1.7 重新启用，API 认证)

设计理念:
  - 简单可靠：纯 Python，无框架依赖，直接 python keepitrun.py 常驻运行
  - 容错优先：子脚本失败不崩溃主调度，异常后自动恢复
  - 安全清理：分级文件清理策略，误删风险极低
  - 可插拔：通过文件存在性判断启用/禁用任务，无需修改代码
  - 版本感知：升级后自动识别受影响的已完成任务并重做


二、目录结构
────────────────────────────────────────────────────────────────────────────────

keepitrun/
├── keepitrun.py              <-- 主调度脚本（常驻运行）
├── getrss.py                 <-- RSS 抓取与关键词过滤
├── combine-gemini.py         <-- RSS 合并、去重、翻译
├── convert_daily.py          <-- 微信公众号 AIGC 早报爬取 (v1.3 重新启用)
├── convert_blog.py           <-- 微信公众号长文/短篇爬取 (v1.2 重新启用)
├── model-process.py          <-- LLM 后处理（分类/去重/过滤，可选）
├── photos_update.py          <-- GitHub Photos 图片库自动同步 (v1.4 纳入发行包)
├── readme.py                 <-- 本文档（产品说明 + changelog + debug 指南）
│
├── disabled/                 <-- 已禁用的脚本（待修复后移回主目录即可启用）
│
├── .env                      <-- GITHUB_TOKEN 配置
├── keywords.json             <-- RSS 关键词配置
├── rss_feeds.json            <-- RSS 订阅源列表
├── last_blog_crawl.txt       <-- 上次 blog 爬取日期记录（自动维护）
│
├── logs/                     <-- 运行日志（分级清理）
│   ├── YYYYMMDD.log          <-- keepitrun 主日志
│   ├── getrss_*.log          <-- RSS 抓取日志
│   ├── daily_*.log           <-- AIGC 早报爬取日志
│   ├── blog_*.log            <-- 微信文章爬取日志
│   ├── task_completion.json  <-- 版本感知任务完成记录 (v1.3)
│   └── archive/              <-- 7 天以上日志归档
│
├── tmp/                      <-- 临时文件（1 天后自动清理）
│   └── rss_YYYY-MM-DD_*.md   <-- RSS 抓取中间结果
│
└── archived/                 <-- 已处理的 RSS 结果归档（30 天后清理）


三、每日任务计划
────────────────────────────────────────────────────────────────────────────────

活动任务:
  ┌────────┬─────────────────────────────┬──────────────────────┐
  │ 时间   │ 任务                        │ 脚本                 │
  ├────────┼─────────────────────────────┼──────────────────────┤
  │ 02:00  │ RSS 抓取 (第1次)            │ getrss.py            │
  │ 10:05  │ 爬取最新 daily              │ convert_daily.py     │
  │ 10:10  │ 爬取最新 blog               │ convert_blog.py      │
  │ 14:00  │ RSS 抓取 (第2次)            │ getrss.py            │
  │ 14:05  │ 合并去重翻译 RSS 结果       │ combine-gemini.py    │
  │ 15:00  │ Photos 自动同步             │ photos_update.py     │
  └────────┴─────────────────────────────┴──────────────────────┘

已启用任务 (v1.7):
  ┌────────┬─────────────────────────────┬──────────────────────────────────────────┐
  │ 时间   │ 任务                        │ 说明                                     │
  ├────────┼─────────────────────────────┼──────────────────────────────────────────┤
  │ 12:00  │ Unsplash 照片管理           │ 每 3 天运行, API Access Key / Bearer Token│
  └────────┴─────────────────────────────┴──────────────────────────────────────────┘
  注: 需要 .env 中配置 UNSPLASH_ACCESS_KEY, 首次使用需获取 Bearer Token
      运行: python unsplash_update.py auth <授权码>

未配置 Unsplash 时不影响其他任务运行。


四、版本感知任务完成追踪 (v1.3 新增)
────────────────────────────────────────────────────────────────────────────────

当 keepitrun 版本升级后重启时，可能遇到以下情况：
  - 某个任务今天已经被旧版本执行过
  - 新版本对该任务的逻辑进行了修改

如果简单地跳过"今天已完成"的任务，修改后的逻辑就不会生效。
版本感知追踪系统解决了这个问题。

4.1 工作原理
────────────
  1. 每个任务完成时，记录任务名 + 日期 + 当前版本号到 task_completion.json
  2. 任务触发前，检查该任务今天的完成记录
  3. 如果已完成版本 ≠ 当前版本，检查两个版本之间是否有变更影响该任务
  4. 如果受影响 → 重做任务；如果未受影响 → 跳过

4.2 版本变更映射
────────────────
  VERSION_TASK_CHANGES = {
      "1.1": {"rss", "combine"},     # v1.1 改了日志和文件路径
      "1.2": {"blog"},               # v1.2 重新启用blog，改用合集API
      "1.3": {"blog", "daily"},      # v1.3 重新启用daily，blog日志前缀变更
  }

4.3 任务完成记录格式 (logs/task_completion.json)
─────────────────────────────────────────────────
  {
      "rss_1": {"2026-06-11": "1.3"},
      "rss_2": {"2026-06-11": "1.3"},
      "combine": {"2026-06-11": "1.3"},
      "blog": {"2026-06-11": "1.3"},
      "daily": {"2026-06-11": "1.3"},
      "photos_update": {"2026-06-11": "1.3"}
  }

4.4 判断逻辑
────────────
  should_task_redo(task_name) 返回:
    - (True, "not_done_today")      → 任务今日未完成，需要执行
    - (True, "version_changed")     → 任务由受影响旧版本完成，需重做
    - (False, "already_done")       → 任务已由当前版本完成，跳过
    - (False, "already_done_unchanged") → 任务由未受影响版本完成，跳过


五、文件清理策略
────────────────────────────────────────────────────────────────────────────────

  目录            保留时间      处理方式
  ───────────    ──────────   ──────────────────────────────
  tmp/            1 天         超过 1 天 → 自动删除
  logs/           7 天         超过 7 天 → 移入 logs/archive/
  logs/archive/   30 天        超过 30 天 → 自动删除
  archived/       30 天        超过 30 天 → 自动删除

设计原则:
  - tmp/ 中的文件是中间结果，已被后续步骤消费，1 天后安全删除
  - logs/ 先归档再删除，7 天内的日志可随时查看，归档后仍保留 30 天
  - archived/ 中的 RSS 结果已被合并输出，30 天后安全删除
  - 最终输出的合并翻译文件 (YYYYMMDD-HHMMSS.md) 不会被自动清理
  - task_completion.json 不受自动清理影响（位于 logs/ 但非 .log 后缀）


六、各子脚本详解
────────────────────────────────────────────────────────────────────────────────

6.1 getrss.py — RSS 抓取与关键词过滤
────────────────────────────────────────
功能:
  - 从 rss_feeds.json 读取 39 个 RSS 订阅源
  - 从 keywords.json 读取 400+ 个关键词（公司/产品/人物/技术术语）
  - 抓取最近 24 小时内的条目，按关键词过滤
  - 去除相似/重复条目（SequenceMatcher 阈值 0.85）
  - 输出带 Markdown 超链接的结果到 tmp/ 目录

依赖: feedparser, beautifulsoup4
配置: rss_feeds.json, keywords.json (均在同目录)

6.2 combine-gemini.py — RSS 合并、去重、翻译
────────────────────────────────────────────────
功能:
  - 合并多次 RSS 抓取结果（通常 2 次），去除重复行
  - 使用 Gemini API 将英文标题翻译为中文
  - 按公司分类排序（NVIDIA → OpenAI → Google → ... → 其他）
  - 投资类新闻按金额排序置顶
  - 输出合并后的 Markdown 文件到主目录

依赖: google-generativeai
配置: 内置 API Key（可通过 -api 参数覆盖）

6.3 model-process.py — LLM 后处理（可选）
────────────────────────────────────────────
功能:
  - 对合并后的 RSS 结果进行二次过滤和分类
  - 分类: KEEP（核心科技新闻）/ REVIEW（待核查）/ IRRELEVANT（不相关）
  - 全局去重: 识别报道同一事件的重复新闻
  - 输出分层的 Markdown 文件

依赖: google-generativeai 或 zhipuai
注意: 本脚本为独立工具，不由 keepitrun 自动调用

6.4 convert_daily.py — 微信公众号 AIGC 早报 (v1.3 重新启用)
────────────────────────────────────────────────────────────
功能:
  - 从微信专辑遍历抓取 AIGC 早报文章
  - 自动生成 Markdown 和下载封面图
  - 推送到 GitHub 仓库 (lishuhang/daily + lishuhang/img)
  - 支持自动检测模式、日期范围模式、全量模式、差异对比模式

依赖: beautifulsoup4, requests
需要: .env 中的 GITHUB_TOKEN
状态: v1.3 重新启用，已从 disabled/ 移回主目录

6.5 convert_blog.py — 微信公众号长文/短篇 (v1.2 重新启用)
────────────────────────────────────────────────────────────
功能:
  - 使用微信公众号合集(Album) API获取文章列表（无需Cookie）
  - 自动识别长文/短篇，HTML → Markdown 转换
  - 下载原始最大尺寸图片，上传到 GitHub
  - 支持8个合集分类，自动分配categories和tags
  - 覆盖保护：已有文件先备份为 _bak

依赖: beautifulsoup4, requests, pypinyin
需要: .env 中的 GITHUB_TOKEN
状态: v1.2 重新启用，使用合集API无需Cookie


七、配置说明
────────────────────────────────────────────────────────────────────────────────

7.1 环境变量 (.env)
───────────────────
  GITHUB_TOKEN=ghp_xxxxxxxx    # GitHub Personal Access Token (需 repo 权限)

7.2 keywords.json
─────────────────
  JSON 格式，包含 4 个分类:
    - "公司": NVIDIA, OpenAI, Google, ...
    - "产品/模型": ChatGPT, Claude, Gemini, ...
    - "人物": Sam Altman, 黄仁勋, ...
    - "技术术语": AI, LLM, Agent, ...

7.3 rss_feeds.json
──────────────────
  JSON 格式，包含 RSS 订阅源列表:
    - 英文源: TechCrunch, Ars Technica, The Verge, ...
    - 中文源: 36kr, IT之家, 虎嗅, 少数派, ...
    - 聚合源: Techmeme, Hacker News, ...

7.4 keepitrun.py 中的可配置项
─────────────────────────────
  CHECK_INTERVAL = 30          # 时间检查间隔（秒）
  TMP_RETENTION_DAYS = 1       # tmp/ 文件保留天数
  LOG_ARCHIVE_DAYS = 7         # 日志归档天数
  LOG_DELETE_DAYS = 30         # 日志删除天数
  ARCHIVED_RETENTION_DAYS = 30 # 归档文件保留天数
  PHOTOS_UPDATE_SCRIPT = ...   # Photos 同步脚本路径（自动搜索）


八、从零开始的安装与运行指南
────────────────────────────────────────────────────────────────────────────────

8.1 环境要求
────────────
  - Python 3.9+
  - pip (Python 包管理器)
  - Git (用于 GitHub 仓库操作)
  - 网络连接 (访问 RSS 源和 GitHub API)

8.2 安装步骤
────────────
  1. 解压 keepitrun-v1.3.zip 到目标位置
     (文件夹名将从 rss-reader 改为 keepitrun)

  2. 安装 Python 依赖:
     pip install feedparser beautifulsoup4 google-generativeai zhipuai pypinyin requests

  3. 配置 .env 文件:
     在 keepitrun/ 目录下编辑 .env，填入你的 GitHub Token:
     GITHUB_TOKEN=ghp_你的token

  4. (可选) 配置 Photos 同步:
     将 photos_update.py 放入以下任一位置:
     - keepitrun/ 同目录下 (推荐)
     - 同级 photos_update/ 文件夹中
     - 或修改 keepitrun.py 中的路径

  5. 启动主脚本:
     python keepitrun.py

  6. (推荐) 设置为开机自启:
     - Windows: 任务计划程序 → 创建基本任务 → 触发器: 计算机启动时
     - 或将快捷方式放入启动文件夹

8.3 验证运行
────────────
  启动后应看到如下输出:
    keepitrun v1.3 启动
    脚本目录: /path/to/keepitrun
    日志目录: /path/to/keepitrun/logs
    ...

  首次启动会立即执行全部任务，之后进入定时调度模式。


九、Agent Debug 指南
────────────────────────────────────────────────────────────────────────────────

本节面向 AI Agent 或开发者，帮助快速定位和修复问题。

9.1 日志位置
────────────
  - 主日志: logs/YYYYMMDD.log (每日一个文件)
  - RSS 抓取日志: logs/getrss_YYYYMMDD_HHMMSS.log
  - AIGC早报日志: logs/daily_YYYYMMDD_HHMMSS.log
  - 微信文章日志: logs/blog_YYYYMMDD_HHMMSS.log
  - 任务完成记录: logs/task_completion.json
  - 旧日志归档: logs/archive/

  查看今日日志:
    cat logs/$(date +%Y%m%d).log

  查看最近的错误:
    grep -i "error\|failed\|失败" logs/*.log | tail -20

9.2 常见问题与排查
──────────────────

  问题: RSS 抓取结果为空
  排查:
    1. 检查网络连接: curl -I https://techcrunch.com/feed/
    2. 检查 rss_feeds.json 中的 URL 是否有效
    3. 查看 getrss 日志中的超时/错误信息
    4. 确认 keywords.json 中的关键词是否过于狭窄

  问题: 合并翻译失败
  排查:
    1. 检查 Gemini API Key 是否有效
    2. 确认 tmp/ 中有 rss_*.md 文件
    3. 查看日志中的 "Translation count mismatch" 错误
    4. 尝试手动运行: python combine-gemini.py tmp/rss_xxx.md tmp/rss_yyy.md

  问题: Photos 同步未触发
  排查:
    1. 确认 photos_update.py 文件存在于搜索路径
    2. 查看 keepitrun 启动日志中的 "Photos 同步脚本未找到" 提示
    3. 手动运行 photos_update.py 测试是否正常
    4. 检查 .env 中的 GITHUB_TOKEN 是否有 lishuhang/photos 仓库权限

  问题: 日志/临时文件占用过多磁盘
  排查:
    1. 检查 tmp/, logs/, archived/ 目录大小
    2. 确认 keepitrun 是否正常运行（清理在每日凌晨执行）
    3. 手动触发清理: 修改 DAILY_BOOT_FLAG 日期后重启

  问题: convert_daily / convert_blog 脚本报错
  排查:
    1. 确认脚本在主目录下（非 disabled/）
    2. GITHUB_TOKEN 可能权限不足
    3. 微信 API 可能有反爬限制
    4. 查看对应的 daily_*.log / blog_*.log 日志

  问题: 版本升级后任务没有重做
  排查:
    1. 检查 logs/task_completion.json 中的版本记录
    2. 确认 VERSION_TASK_CHANGES 中是否包含对应的版本和任务
    3. 查看 keepitrun 日志中的 "需要重做" / "今天已完成" 消息

9.3 文件引用关系图
──────────────────

  keepitrun.py 引用:
    ├── getrss.py           (RSS_SCRIPT)
    ├── combine-gemini.py   (COMBINE_SCRIPT)
    ├── convert_daily.py    (DAILY_SCRIPT)
    ├── convert_blog.py     (BLOG_SCRIPT)
    ├── photos_update.py    (PHOTOS_UPDATE_SCRIPT, 可选)
    ├── keywords.json       (被 getrss.py 读取)
    ├── rss_feeds.json      (被 getrss.py 读取)
    └── .env                (被 convert_daily/blog 读取)

  getrss.py 读取:
    ├── rss_feeds.json
    └── keywords.json
  getrss.py 写入:
    └── tmp/rss_YYYY-MM-DD_HH-MM-SS.md

  combine-gemini.py 读取:
    └── tmp/rss_YYYY-MM-DD_HH-MM-SS.md
  combine-gemini.py 写入:
    └── YYYYMMDD-HHMMSS.md (最终输出)

  model-process.py 读取:
    └── YYYYMMDD-HHMMSS.md (combine 输出)
  model-process.py 写入:
    └── YYYYMMDD-HHMMSS_processed.md

  convert_daily.py 读取:
    ├── .env
    └── 微信专辑 API
  convert_daily.py 写入:
    ├── images/YYYY/MM/MMDD-d.jpg
    ├── _posts/YYYY-MM-DD-daily.md
    └── GitHub 仓库 (lishuhang/daily, lishuhang/img)

  convert_blog.py 读取:
    ├── .env
    └── 微信公众号合集(Album) API
  convert_blog.py 写入:
    ├── GitHub 仓库 (lishuhang/lishuhang.github.io, lishuhang/img)
    └── last_blog_crawl.txt

9.4 关键变量速查
────────────────
  SCRIPT_DIR    = 脚本所在目录（所有路径的根）
  TMP_DIR       = SCRIPT_DIR/tmp/
  LOG_DIR       = SCRIPT_DIR/logs/
  LOG_ARCHIVE_DIR = SCRIPT_DIR/logs/archive/
  ARCHIVED_DIR  = SCRIPT_DIR/archived/
  TASK_COMPLETION_FILE = SCRIPT_DIR/logs/task_completion.json

9.5 安全注意事项
────────────────
  - .env 中包含 GITHUB_TOKEN 和 Unsplash 凭证，不要提交到公开仓库
  - combine-gemini.py 中内置了 API Key，建议通过 -api 参数传入
  - model-process.py 中内置了智谱 API Key
  - 所有 API Key 和 Cookie 信息仅存储在本地
  - task_completion.json 中仅含版本号，无敏感信息


十、Changelog
────────────────────────────────────────────────────────────────────────────────

v1.7 (2026-06-13)
─────────────────
  新增:
    - 重新启用 Unsplash 照片管理任务 (12:00, 每 3 天)
    - 新增 unsplash_update.py 脚本
      · 使用官方 API 认证: Client-ID (Access Key) 公开读取 + Bearer Token 用户操作
      · 无需 Cookie
      · 内置 Demo 等级速率限制 (50 请求/小时，脚本预留 40 次/小时)
      · 支持: 照片上传/状态查询/收藏集管理
      · 首次使用需获取 Bearer Token: python unsplash_update.py auth <授权码>
    - .env.example 新增 Unsplash 相关字段
      · UNSPLASH_ACCESS_KEY, UNSPLASH_SECRET_KEY, UNSPLASH_BEARER_TOKEN, UNSPLASH_REDIRECT_URI

  注意:
    - Unsplash 官方 API 未公开上传端点，上传功能可能受限
    - 如果 API 不支持上传，需通过网页 https://unsplash.com/submit 手动上传

v1.6 (2026-06-13)
─────────────────
  新增:
    - blog/daily 文章归档机制：GitHub 同步成功后自动将本地 .md 和 images/ 移入 archived/

  修复:
    - 打包包含 .env 导致用户解压覆盖后 GitHub Token 丢失
      · 发行包不再包含 .env，改为 .env.example 模板

v1.5 (2026-06-12)
─────────────────
  修复:
    - photos_update.py 401 认证失败时原始 traceback 崩溃，改为友好提示
    - blog 首次启动默认 album:diff 导致 8 合集全量遍历超时 600s

v1.4 (2026-06-12)
─────────────────
  修复:
    - 所有子脚本添加 Windows 控制台 UTF-8 编码修复
      · 解决 emoji 输出导致的 UnicodeEncodeError: 'charmap' codec can't encode character
      · 受影响脚本: photos_update.py, convert_blog.py, convert_daily.py, getrss.py, keepitrun.py
      · 已有修复的脚本: combine-gemini.py, model-process.py (确认无问题)
    - photos_update.py 纳入 keepitrun 发行包 (之前为外部脚本)

  变更:
    - VERSION_TASK_CHANGES 新增 "1.4": {"photos_update"}
    - 版本号升级至 1.4

v1.3 (2026-06-11)
─────────────────
  新增:
    - 版本感知任务完成追踪系统 (task_completion.json)
      · 版本升级后自动识别受影响的已完成任务并重做
      · VERSION_TASK_CHANGES 映射版本变更与受影响任务
    - convert_daily.py 重新启用 (从 disabled/ 移回主目录)
    - 10:05 定时爬取微信公众号 AIGC 早报

  变更:
    - convert_daily.py 日志路径从 disabled/ 上级目录改为同目录 logs/
    - should_run() 整合版本感知判断，支持任务重做
    - 首次启动任务从 3 步扩展为 5 步（增加 daily + blog）

v1.2 (2026-06-11)
─────────────────
  新增:
    - 重新启用微信公众号文章抓取 (10:10)
    - 使用合集API替代公众平台后台Cookie登录 (convert_blog.py v3.0)
    - 无需Cookie即可抓取文章列表

v1.1 (2026-06-10)
─────────────────
  新增:
    - 分级文件清理策略 (tmp 1天, logs 7天归档/30天删除, archived 30天)
    - tmp/ 目录用于存放 RSS 抓取中间结果
    - logs/archive/ 子目录用于日志归档
    - Photos 同步脚本多路径搜索（同目录 > 同级文件夹 > Windows 常见路径）
    - 本 readme.py 产品文档

  修复:
    - 子脚本日志统一输出到 logs/ 目录（不再散落在根目录）
    - getrss.py 中间结果输出到 tmp/（不再与最终输出混在根目录）
    - combine-gemini.py 从 tmp/ 读取中间结果
    - 归档文件重名时自动添加时间戳后缀（避免覆盖）
    - Photos 同步路径自动解析（修复外部脚本路径不生效的问题）

  变更:
    - 所有 Python 脚本去除文件名中的时间戳（版本通过 zip 包区分）
      · keepitrun-260424.py → keepitrun.py
      · 260310-getrss.py → getrss.py
      · 260310-combine-gemini.py → combine-gemini.py
      · convert_daily_2.py → convert_daily.py (已禁用)
      · convert_blog_2.py → convert_blog.py (已禁用)
    - 工作文件夹从 rss-reader 改名为 keepitrun
    - Unsplash 上传任务标记为已禁用（外部脚本暂不可用）
    → v1.7 重新启用: 使用官方 API 认证 (Access Key + Bearer Token)

  已禁用:
    - convert_daily.py (微信公众号 AIGC 早报) → 移至 disabled/
    - convert_blog.py (微信公众号长文/短篇) → 移至 disabled/
    - Unsplash 自动上传任务 → keepitrun.py 中已注释
    → v1.7 已重新启用

  移除:
    - keepitrun.py 中的 autoconfirm 机制（仅用于被禁用的 WeChat 脚本）

v1.0 (2026-04-20)
─────────────────
  初始正式版本 (keepitrun-260424.py)
    - 24 小时常驻定时调度
    - RSS 抓取 (每日 2 次) + 合并去重翻译
    - 微信公众号 AIGC 早报自动爬取 (convert_daily_2.py)
    - 微信公众号长文/短篇爬取 (convert_blog_2.py)
    - Photos 自动同步
    - Unsplash 自动上传 (每 3 天)
    - 首次启动立即执行全部任务
    - 日志保留 60 天自动清理
    - 防重复执行机制

v0.x (2024-2025)
─────────────────
  早期版本，存档于 keepitrun-v0.x.zip
    - 240610: 最初版本，中间层架构 (step1/2/3)
    - 240812/240827: 单文件 RSS 处理
    - 241014: 改进版本
    - 250207/250410: keepitrun 雏形
    - 251222: getrss + combine-gemini 分离
    - 260310: 当前子脚本的直接前身
    - 260420: v1.0 的前置版本


十一、版本打包规范
────────────────────────────────────────────────────────────────────────────────

  版本号格式: keepitrun-vX.Y.zip

  v1.4 打包内容:
    - 必须包含: keepitrun.py, getrss.py, combine-gemini.py, convert_daily.py,
      convert_blog.py, model-process.py, photos_update.py, .env, keywords.json,
      rss_feeds.json, last_blog_crawl.txt, readme.py, readme.md
    - 必须排除: logs/、tmp/、archived/、images/、_posts/、*.log、*.md
      (RSS 中间结果和最终输出)、.boot_flag、task_completion.json
    - photos_update.py 现已包含在发行包中 (v1.4)

  启用新版本:
    1. 解压对应 zip
    2. 将旧版的 logs/、archived/、tmp/ 复制到新版目录（如需保留）
    3. 运行 python keepitrun.py
    4. 版本感知系统会自动处理需要重做的任务

================================================================================
  文档结束 | keepitrun v1.4 | 2026-06-12
================================================================================
"""

import sys

def main():
    if "--full" in sys.argv:
        print(DOC)
    else:
        # 输出摘要
        lines = DOC.strip().split("\n")
        in_changelog = False
        changelog_lines = []
        for line in lines:
            if "Changelog" in line and "十、" in line:
                in_changelog = True
            if in_changelog:
                changelog_lines.append(line)
            if in_changelog and line.startswith("十一、"):
                break

        # 输出前几行摘要
        print("keepitrun v1.4 - 全天候定时任务调度系统")
        print("=" * 50)
        print()
        print("运行 'python readme.py --full' 查看完整文档")
        print()
        print("快速启动:")
        print("  1. pip install feedparser beautifulsoup4 google-generativeai")
        print("  2. 编辑 .env 填入 GITHUB_TOKEN")
        print("  3. python keepitrun.py")
        print()
        print("--- Changelog 摘要 ---")
        # 输出 changelog 中 v1.3 的部分
        in_v14 = False
        for line in changelog_lines:
            if "v1.4" in line and "2026-06-12" in line:
                in_v14 = True
            if in_v14:
                print(line)
            if in_v14 and "v1.3" in line and "2026-06-11" in line:
                break

if __name__ == "__main__":
    main()
