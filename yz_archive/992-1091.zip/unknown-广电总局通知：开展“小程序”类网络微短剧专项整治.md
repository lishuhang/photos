# 广电总局通知：开展“小程序”类网络微短剧专项整治

> 公众号: 娱乐资本论
> 发布时间: 
> 原文链接: https://mp.weixin.qq.com/s/BrJdD5gi8TPyl3gMWYUblA

---

![图片](http://mmbiz.qpic.cn/mmbiz_gif/Thf7MtZSy5JALgfBqcOgJ3oEboY0tjWTJ3Ea71eT33B6f0YH4h8icWumyxn16rmMHwDPeyxZCqPHlNUE0lxvs4A/640?wx_fmt=gif&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)**作者｜兔棉花**

12月27日，广播电视总局发布网络微短剧治理措施的最新通知，提出新兴的“小程序”类网络微短剧利用技术手段脱离监管，发展快、势头猛、不规范、问题多，形成对主流作品“劣币驱逐良币”的挤出效应，对网络传播秩序造成冲击。

为引导网络微短剧规范有序发展，进一步加强网络微短剧管理、实施微短剧创作提升计划，广电总局本着党管媒体的原则就“开展专项整治”和“加强规范管理”两方面提出对应措施。

![图片](http://mmbiz.qpic.cn/mmbiz_png/Thf7MtZSy5K5Tkyf8b8hrP3NfnsviakYylWrEpAL1w0oqvpENOT5kHsXicqRYQRJibNZ6Upseib0Zib5f3MegZ9zDbQ/640?wx_fmt=png&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=1)**广电总局：开展小程序微短剧专项整治**

针对“小程序”类网络微短剧，广电总局指出要严肃、扎实开展“小程序”类网络微短剧专项整治。

聚焦色情低俗、血腥暴力、格调低下、审美恶俗等内容的“小程序”类网络微短剧，开展专项整治。各省级广电管理部门要全面深入排查，摸清底数，分类施策，督导辖区内“小程序”接入和分发的重点网络视听平台自查自纠、立行立改，并及时健全加强管理的制度机制。对存在问题的网络微短剧，采取责令整改或下线处理；对传播违规网络微短剧的“小程序”及其开办主体，视情节轻重，采取断链、下线、下架、注销备案、停止接入服务、吊销相关许可、联合惩戒等相应措施；对内部管理制度缺失或松懈、安全隐患较大、问题整治不到位的“小程序”接入和分发平台，依法依规进行重点整改、严肃处置。

在加强规范管理，实施创作提升计划方面，通知明确10项措施，包括：依法依规纳入管理，加强创作规划引导，加强重点剧片跟踪指导，加大精品扶持力度，强化内容审核，突出结构管理，严格许可证发放，坚守管理底线，压实平台主体责任，积极推动行业自律和业务指导等。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)**小程序短剧：泡沫还是新风口？**

自2020年末国家广电总局在备案系统新增“网络微短剧”板块至今，网络微短剧经过短暂的发育期便迅速占领了平台内容池，各类微短剧层出不穷。近期，一类“小程序短剧”成为流行。这种“小程序短剧”一般为单集1分钟左右、单部几十甚至上百集的竖屏短剧。它通过抖音、快手等平台投流带来精准流量，吸引用户跳转微信等小程序平台观看，前几集免费，后面的内容需要付费解锁，单集价格通常在1元以内。就这样，小程序短剧实现了点击广告按钮-拉起小程序付费-解锁剧集-成功观看变现闭环。

小程序短剧的繁荣，具有鲜明的阶段化特征，虽然很好地服务了下沉市场的网络受众，但“以量换质”“低质内卷”现象严重。快节奏、碎片化的呈现方式要求它必须快速抓住受众眼球，生产商们基于内容的爽感，“沉迷”用霸道总裁、屌丝逆袭、穿越重生等夸张剧情吸引消费者。加之广电总局发布整治通知前，市场中并未有明确、有力的规定来规范小程序短剧，这都使得小程序短剧向着不规范的方向发展，被打上“低级”“色情”“博眼球”的标签。

小程序短剧仍然属于发展初期，尚未将流量变现运用到极致。虽然行业规范的不断健全能为其长远发展奠定重要基础，但如何避免小程序短剧成为昙花一现的伪风口，让保持不断成长和可持续发展，仍需要投资人和内容创作者的潜心挖掘，不止在进一步开拓新的变现场景方面，更是在探索高质量剧情方面。一部制作精良、养眼养心的网络微短剧，无论在增强话题度、聚合粉丝粘性，还是达人变现上都更为有利。诚恳的创作终将在观众口碑方面有所回报。

>>>推荐阅读：[小程序短剧：一门虽“土”但“豪”的流量生意](https://mp.weixin.qq.com/s?__biz=MzUyNjk4NDc3Ng==&mid=2247500328&idx=1&sn=5d6d6e75ed2c4ac1e8125a5151b20377&scene=21#wechat_redirect)

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**更多文娱产业背后的经济逻辑，来关注↓↓↓**