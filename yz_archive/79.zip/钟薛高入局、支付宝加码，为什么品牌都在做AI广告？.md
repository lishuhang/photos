# 钟薛高入局、支付宝加码，为什么品牌都在做AI广告？

> 公众号: 娱乐资本论
> 发布时间: ref: <Node>
> 原文链接: https://mp.weixin.qq.com/s/iV36u8meLy1No-yP89iJug

---

![图片](http://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd4fKWlKlzjvwfctC7IvQ5VlAA5mzIKiapaCSn773PKUauQTnQic0EF3ibGotFWK70ic3tFlAKPBfep8yw/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1#imgIndex=0)

**作者 | 茶小白**

关于AI的讨论再次站到了十字路口，这一次轮到了内容创作与营销领域。

两周前，钟薛高在上海的年度新品发布会上推出了新品系列“Sa Sa”，比3.5元低价更惹人注目的是，它蹭上AI的热度。早在3月20日，钟薛高就官宣与百度文心一言合作，据品牌宣称，这次新品从起名、包装到口味、设计，均由AI主导。

无独有偶，近期可口可乐也发布了最新创意广告短片，由一瓶可口可乐作为媒介的形式，串联主人公身处博物馆与名画之间的互动。虽然可口可乐对于网友“可口可乐使用AI做广告”的猜测并未正式承认，但画风中stable diffusion的残留痕迹已经足够说明问题。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

（来源：可口可乐广告片  疑似AI创作）

同时，独立设计品牌LABELHOOD蕾虎以“春风抒阔 Blowing in the Breeze”为主题，特邀创意人Macci Leung 共同推出的首个AI创意主题视觉；今年愚人节，支付宝联合Gurulab创始人、广告导演、艺术家赵伯祚发布了一支营销短片，也吸引了不少关注。

对于AI技术理性的判断，曾贯穿了人类对其过去、现在以及未来的所有讨论，而这些最新的营销案例却令人们看到了AI与艺术平衡且科学的可能——

它们恰恰分别代表了AI在创意内容三个维度的实现，即产品设计、动态呈现以及平面视觉，意味着艺术性与商业性可以并存。换句话说，人们质疑AI是否能真正替代人的感性思考，但却无法忽视ChatGPT等语言模型以及Stable Diffusion、Midjourney等AI绘画产品，的确赋予了营销生产更广阔的想象力。

并且更现实的是，不论对AI应用价值的争议如何，这些快人一步的品牌的的确确已经吃下了第一波“流量红利”：钟薛高冲上热搜，可口可乐和蕾虎成为了人们一轮又一轮探讨的经典案例。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

（来源：钟薛高  AI创作）

这将刺激其他企业和个人产生的思考是，如何利用AI在营销领域先发制人？未来的内容生产会是什么样的？以及由此延伸到最底层的恐惧——AI会不会让我失业？

但现在众多大咖的经历已经证明，让人失业的从不是AI，而是那个不愿意接纳新事物的“我”。[【泛内容领域，最大的一次入局机会，欢迎来戳】](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247575387&idx=1&sn=8efba9141704cb0cef6a1f50dab08132&chksm=c058b280f72f3b96710bb715ff1742b200c326af294c1a6fec04eee7b12781b6546e39f9d97f&scene=21#wechat_redirect)

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**AI 创作的一百万种可能**

今年愚人节，支付宝联合广告导演同时也是AI特训营的导师赵伯祚，发布了一支营销短片。这支短片以《支付往事》为主题，讲述了中国支付从钱包、互联网，到二维码的手机，再到展望未来万物互联，用拐杖支付的历史轨迹，其中所有的视觉呈现全部由AI完成。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

（来源：支付宝广告片 AI创作）

其发布节点略有巧思，赵伯祚解释道，“之所以选择在愚人节发布，是为了规避一些风险，因为我们还不知道大家对AI创作的接受程度。”

事实上，这样的担忧放在当今语境下或许过于谦逊——无论接受与否，AI创作已经是历史不可逆之洪流，正在迅速开创营销领域过去所不能达到的可能。

赵伯祚在营销领域及艺术创作领域极具经验，合作着可口可乐中国、阿里等众多大型企业，他的直观感受是，近期越来越多的企业，开始有AI相关的创作和营销需求。“企业是对AI应用最为敏感的群体，他们都愿意去尝试一下用AI来做一些东西。”

目前大多数企业对AI营销的关注出于两个方面，一是流量价值，如同过去几年大热的数字人、元宇宙，“AI创作”作为最新的概念替代品，确实能吸引到一些关注。

但又与数字人、元宇宙概念不同的是，针对平面设计、广告创意以及视觉呈现等领域，AI确实可以参与到生产流程中，并且在多个方面具有极强的生产优势。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

（来源：小红书@娜娜 AI广告视频截图）

**这些优势主要体现在三个方面。一是提高效率，这是AI创作的本质。**比如在文案创作部分，ChatGPT可以根据营销诉求和营销场景，迅速生成大量文本，供企业选择，在相对0人工成本的基础上，至少提升了约七成的时间成本。对于图片部分来说，AI可以利用图库素材积累和分类，迅速响应生产需求。

高效率的进一步延伸，意味着创作者能够运用极少的成本获知结果，从而大大降低后续修改试错的成本。“在商业广告里面，一个很重要的流程就是找很多reference、很多参考，告诉客户最后出来什么样子，这样做下去可能会更有保障一点。AI加速了这个部分，就是原来你需要去模拟、去脑补的部分”，赵伯祚解释道。

**二是AI创作可以拓展想象力，辅助叙事。**还是以支付宝的那支广告片为例，它的主要内容是讲历史的，所以品牌希望能够尽可能放在报道的语境下真实地呈现。“在整个的发展过程中，有很多是发生在九十年代或者是10年、15 年的，里面这些案件本身都是一些真实的新闻事件，但是没有图片，因此我们就想到了能不能通过用 AI 的方式，来复原这样的图片”。也就是说，利用AI可以创作出人类无法实现的、适应自己的需求的更多创意可能。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

（来源：支付宝广告片 AI创作）

**三是规避版权问题等方面。**版权问题是营销过程中的重点。通过 AI 的方式重新去生成，既能让它迎合品牌的叙事需求，也能让它成为有独立的图片版权、独一无二的作品。

并且，就目前的营销生态来看，AI不但覆盖了平面广告、视频广告等营销领域，在游戏物料、剧本等众多创意内容生产领域也均具有广泛的应用。

比如在手游买量的宣传物料方面，最大的特点是以视频、图片为主，且时效性都偏低，新素材更新需求速度快，如今AI已经提供了一个解决方案。在刚刚过去的4月5日，Meta CTO 安德鲁·博斯沃思接受采访时曾透露，Meta筹划在12月之前推出AI生成广告商业化服务，并与谷歌一起探索该技术的实际应用。此次Meta AI生成广告图的技术，将进一步降低游戏领域宣传物料的制作成本。

当AI创作广告素材覆盖各个领域，营销及内容生产必将进一步突破工业化。在此前提下，接受AI的效率提升便是大势所趋，换句话说，当其他企业效率提升了，只有你没有提升，那是否接受AI，**便将是一个生存问题。**

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

**从“创作者”到“工程师”，普通人会被替代吗？**

隐患与突破同在，问题与答案并存，是任何一种新兴科技的解说词，AI创作不会是例外。

长久以来，关于AI是否真正替代人类的恐惧一直存在。**所以，企业与普通创作者应该如何适应AI化带来的冲击？**

要探讨这个问题，首先要明白一个前提是，消弭恐惧最好的方式，是要理性了解AI到底替代了人类生产的哪个部分。

实际上，营销是科学和艺术的结合是大众共识，仅靠技术无法解决人类社会的高层次的需求问题，人依旧是创作核心。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

用赵伯祚的话来说，如今的AI，更像是“智能一点的搜索软件”，即一种高效工具，能够很好弥补人类知识上的缺陷，“一个程序员可能不会做设计，一个设计师可能不会代码，但是AI文理不偏科，他都会”。

既然是工具，如同PS一样，“理解”与“使用”便是掌握主导权的关键。

这看似是一个很容易的过程。今年3份，赵伯祚在光明发表了题为《人工智能技术影响摄影史进⼊“想照片Think Photo”阶段》的文章，将“想照片Think Photo”阶段理解为是摄影史AI推动下，进入了继“拍照片”和“做照片”之后的全新阶段。

**这一阶段的典型特征是，降低了创作的“阈值”，更多非专业摄影师可以轻易使用人工智能技术生成自己的作品。**在微信朋友圈、小红书、微博等媒体上，精美的、堪称大师级的作品数量一路飙升。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

（木雕电吉他，由赵伯祚运用AI创作）

然而事实上，想要真正运用于实际，**“这个过程其实并没有那么简单。”**

运用ChatGPT、Stable Diffusion、Midjourneystable diffusion，需要依次选择合适的描述词及参数，使最终合成的内容看起来和谐，而对于如今的AI技术来说，这是一个漫长且需要技巧的驯化过程。

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

艺术家Macci Leung在为蕾虎创作AI广告片后，在小红书发表了自己的感想，表示“由于随机性太大，一个指令通常还需要测试大量图片之后才能训练出它的风格指向，这个沟通比跟人沟通还困难。”

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

（来源：艺术家Macci Leung小红书）

想要真正高效率地提高这种沟通的精准性，最直接的方式，便是进行大量交流与学习，既是与AI，也是与更多比如赵伯祚等同领域的实操者。

毕竟，他们在长期的创作中，积累了很多驯化描述词的经验。那支“新闻图片”的支付宝广告便是成果之一——AI作图的典型特征是出来图都太美，团队一直在探索如何让它更写实一点。

“我们要理解新闻图片或者是历史图片的画面本质，其实是它们在构图上往往并不完美。因此在描述词的选择上，就需要我们不特别强调图片结构的秩序性，而是跟AI讲，要有一定的抖动或者倾斜，没有黄金构图的等。”

同时不容忽视的是，除了学习其他人的经验，运用AI也对创作者的知识储备提出了更高的要求，**“真正懂艺术的人和不懂艺术的人，运用AI创作的呈现结果还是不一样”。**

![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)

  美梦，本图为AI制作，创意by娱乐资本论

这很好理解，比如写剧本。创作者对剧本的一些剧作结构、基础要素的理解，其实才决定他会怎么去用AI。如果不是编剧，可能会用“一个爱情故事”等很笼统地表述，但对于具有剧作经验的人，他可能会描述“我想要‘救猫咪’的剧作结构”等一些非常专业性的术语。

这意味着，**像摄影师、编剧这种职位也不会被替代，而是更倾向于在身份上经过了一个从“创作者”到“工程师”的转变。**“如果你是一个非常懂艺术史的人，你完成创作的时候，可以当一个‘导演’，把创作变成一个组合的过程，即统领数据库中的那些大师，去创造一个新的可能。”

**话题互动：**

**你怎么看待AI在营销方面的价值？**

**推荐阅读**

[![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247576661&idx=1&sn=c5e1cd7a2d55dd00b0a3a7f8b7695d74&chksm=c058b98ef72f30986e45c7932400cbbcd43a15204558b92d0ff65b433d4cd1ef7021b5c6fdc5&scene=21#wechat_redirect)

[![图片](data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='1px' height='1px' viewBox='0 0 1 1' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3E%3C/title%3E%3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' fill-opacity='0'%3E%3Cg transform='translate(-249.000000, -126.000000)' fill='%23FFFFFF'%3E%3Crect x='249' y='126' width='1' height='1'%3E%3C/rect%3E%3C/g%3E%3C/g%3E%3C/svg%3E)](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247575720&idx=1&sn=eac427aac2668c9bd12586a81774ae08&chksm=c058bd73f72f3465bd164f59294ee9f5f0ae7815c59d4f3744c39d5c4ae475c737acad0989b2&scene=21#wechat_redirect)

**选秀节目消亡后，秀人和公司如何求生？**

**点击观看**

**↓↓↓**

**如需商务合作后台回复【商务】**

**如有转载需求后台回复【转载】**

**更多文娱产业背后的经济逻辑，来关注↓↓↓**