# 布瑞吉Bridge的“潮牌梦”和韩啸的嘻哈文化版图｜对话PUK
> 公众号: 娱乐资本论
> 发布时间: 2023年11月04日 14:15
> 原文链接: https://mp.weixin.qq.com/s/iDuspXCTFKJ-SEnE9pM4qA
---

![](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd71F2dibV90gDJazSOF6hDZdqEQGBQTy1JRSYwOQvmWcuVZkMaPeG9ywx72F3xekLzIwvUrDZUtVOw/640?wx_fmt=jpeg)

**作者｜豆芽**

当嘻哈歌手布瑞吉Bridge决定做一个属于自己的潮牌时，国潮赛道早已是一片红海。

**上百家明星潮牌涌现，整个消费市场更是经历着一场规模性的“消费降级”。**一个典型的现象是——线上销售的潮牌T恤，绝大多数都在百元价格带。

嘻哈文化对布瑞吉Bridge的影响，不仅是一个“rapper梦”，还有一个“潮牌梦”。他把自己的品牌命名为PUK，意思是“和平团结乐园”。

令人意外的是，成立一年半以来，PUK已经跑到了众多同类型品牌的前列——淘宝官方旗舰店多次进入“明星店主服饰店铺榜”的TOP10；第一年入驻得物就成了得物的重要战略合作伙伴。

![](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd71F2dibV90gDJazSOF6hDZdmAPibzUEaYHeyLGgKhjHn0Be2xaJAFuNpNTSBWpoCiavvcNNFy5opFtg/640?wx_fmt=jpeg)

今年是音乐演出爆发年，布瑞吉Bridge的行程排的满满当当，几乎每周都有演出。奔波于不同舞台之间的布瑞吉Bridge，还是会把大量的精力放在PUK上。

一周前，在高铁上碰到一个女生穿着PUK的产品。布瑞吉Bridge上前打招呼“你的衣服很好看”，对方满脸疑惑，显然是不认识自己。布瑞吉Bridge反而更开心了，他还把这件事分享到了PUK团队群。

**不过消费降级背景下，服装赛道空前内卷，即便是艺人的品牌也难以置身事外。**

PUK创立之初，布瑞吉Bridge与合伙人、也是种梦音乐创始人韩啸曾就定价问题产生了分歧：布瑞吉Bridge坚持低价带，认为“很多学生、上班族没钱”，但韩啸希望“立标杆”，并表示“现在太多品牌在卷价格，而不是卷产品本身。”最终，PUK大部分产品的价格定在了99-499之间，非常亲民。

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/HKEDX7MqXK01Jalpnx7A2NWL6iccBuqe4LddtPod2GlsM6RU7wObeycSFxm7OhIXOZtbRZs0ke3fddJvMTXMqxg/640?wx_fmt=jpeg)

但如何通过强曝光、高概念旗舰店、以及引领时代的潮流风格将品牌带到一个新的高度，布瑞吉Bridge还在不断尝试。

而韩啸希望谋划一个更大的未来——**以嘻哈音乐为根基、多种消费品为载体，打造一个“潮流文化”的商业版图**。

“美国嘻哈歌手的成功，不仅仅是音乐上的成功，常被人忽视的是他们的卡带销售火爆，底层逻辑是有很多人听他的音乐为他的音乐买单，所以他的音乐才是成功的”，韩啸告诉我们。

他还提及beats耳机的故事，由嘻哈歌手Dr. Dre和音乐制作人Jimmy Lovine创立的beats耳机品牌，打出知名度之后，在2014年被苹果公司以32亿美元的价格收购，此项收购也是苹果有史以来规模最大的一次交易。

“嘻哈音乐从诞生的第一天开始，就跟潮流消费、商业密不可分。”韩啸说。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK01Jalpnx7A2NWL6iccBuqe4P5NDzKWWqh0RDXiabOqSJf8Dkz3bFP1nJlCL4LJarEVfVrS11INRGwA/640?wx_fmt=png)

![](https://mmbiz.qpic.cn/mmbiz_png/jNZszpkibXx8r0eeusveAtyj98pKeBEz7tMuAmiadsyvAk4l30TZvmgP03RGX0iaosuL5yVawsdblYqeWUcOTHYoQ/640?wx_fmt=png)

**PUK的诞生：一门从说唱衍生出的生意**

一个品牌的创立，往往是创始人的理想化表达与商业布局的双重驱动。

说起为何创立PUK这个品牌，布瑞吉Bridge谈到了自己最初接触嘻哈的那些年。“我是受美国南部嘻哈文化的影响比较深，当时虽然不能完全感知歌词意义，但不论是专辑封面还是MV里的造型，嘻哈文化中的视觉冲击力，潜移默化地影响了我。”

在布瑞吉Bridge的认知中，音乐只是嘻哈文化的一部分，完整的嘻哈文化还包括了视觉、潮流、审美。做一个属于自己的潮流品牌，一直是他音乐之外的另一个梦想。

**2022年5月，PUK正式上线了。**布瑞吉Bridge负责产品设计与品牌调性，种梦音乐创始人韩啸主导大的商业决策和资源整合。俩人分工明确，配合默契。

![](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd71F2dibV90gDJazSOF6hDZdxrZXJhdxqeXkWp66CYLToK84fMnbiczsX5qyJvhIJ4jiaOnAPw7byrtw/640?wx_fmt=jpeg)

**从音乐本身到视觉呈现，嘻哈文化及南部嘻哈风格对布瑞吉Bridge的影响成为PUK诞生的源头，也决定了PUK的品牌理念。**

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/HKEDX7MqXK01Jalpnx7A2NWL6iccBuqe4qia9dXTMtiaNaDHmZJQB0IuH1qdIRewicl8XrWgHiccN1sYN8jZ5rWicQvQ/640?wx_fmt=jpeg)

相比“赚快钱”，韩啸更看重这件事的长远价值。在他看来：“作为国内的头部嘻哈公司，我们必须要有这个战略布局。”

**PUK入局时，明星潮牌赛道已经处于“供大于求”的内卷状态。**不论是薛之谦、白敬亭等主流艺人，还是黄子韬、王鹤棣等偶像明星，很多艺人都推出了个人品牌。尤其是近几年逐渐走进大众视野中的说唱歌手，做潮牌的比例更高，马思唯、KNOWKNOW等rapper都在经营各自的服装品牌，而且很多明星的个人品牌价格在99～499之间。

有些品牌逐渐站稳脚跟，但大多数品牌还没走上正轨，就被迫关门。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK01Jalpnx7A2NWL6iccBuqe46WDnGZDXyReUJ3vsPqsmeaSV9bEExM3C51LBn7ySlcFch0k46TBzjA/640?wx_fmt=png)

**明星扎堆做品牌的背后，是“艺人光环”带来的商业红利。**依赖于明星个人的影响力与粉丝基础，起步阶段能够很好地为品牌赋能。例如，在PUK的淘宝店铺中，明星同款的销量表现都很好。

而且很多艺人自带潮流、文化的背书，更容易阐述品牌故事，其实大多数明星品牌都强关联着一种态度理念。例如薛之谦的DSP通过“危险人物”的形象主张对“和平、纯净世界的向往”，在其出演的各个综艺中，薛之谦也在反复强调“世界和平”。

但优势的反面也意味着更大的争议，**不少明星的潮牌都因为价格、质量、售后服务等问题被认为是割韭菜，甚至还会反噬艺人本身的口碑**。之前欧阳娜娜推出的个人品牌nabi，就被质疑价格太高、与质量不符合。但即便没有高溢价，很多明星的个人品牌在推出之即也会被贴上了“割韭菜”、“质量堪忧”等标签。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK01Jalpnx7A2NWL6iccBuqe4uTmbP5gO6icuVDSv4C5lDy07r63jseWfuTy6IWSXIULiboeRRRB0CRTw/640?wx_fmt=png)

**虽然定价区间避开了“割韭菜”的争议，但从rapper跨界到品牌，布瑞吉Bridge还面临着很多决策难题。**

“可以这么说，现在卖的好的都是我想否掉的产品”，布瑞吉Bridge坦言。在产品设计上，团队与布瑞吉Bridge会产生分歧，“如果把PUK的品牌理念表达到极致，一定是个性非常鲜明的产品，但可能并不符合市场的大众需求。”

不过，前期布瑞吉Bridge想否掉的这些设计不仅没有被停掉，反而顺利上线、成了热卖款。而且布瑞吉Bridge也非常坦然接受，他表示“其实这也是团队的磨合与相信，大家都有各自的从业经历，有自己的审美和数据支撑。而且PUK在做好设计、品质之外，我更在意如何传达好品牌精神。”

除了布瑞吉Bridge主动“妥协一些执念”，这也是团队运作的结果。PUK团队已经将工作拆解成各个细分步骤，例如在定款上，作为品牌核心创意人，布瑞吉Bridge会先提出大概念，然后团队基于这个概念进行提案，最后定款、定设计。“每个步骤都是我们确认过的，跑偏的部分都会在过程中磨合掉。”

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK01Jalpnx7A2NWL6iccBuqe4GWb91SKtqQVL0YN9ulWXOTiaC1jiaGD1Bu3Xdo9kfibibbLBfX9LXqATmg/640?wx_fmt=png)

**在谈到做品牌的目的和期望时，韩啸和布瑞吉Bridge也给出了不一样的答案。**

“对我来说，还是希望得到除了演出费之外的更多价格和价值”，布瑞吉Bridge坦言。而韩啸相对更轻松一些，“现阶段我对财务上没有那么大的奢求、压力，不指望用这件事来赚钱养公司，所以在打法上会更轻松，可以随机应变。”

虽然有分歧、有争议，但在论及PUK的创立和发展时，**“团队配合”是布瑞吉Bridge和韩啸反复提及的一个词**。

据布瑞吉Bridge介绍，PUK的团队目前有20人左右，包括主设计师、品牌运营、销售等岗位，“就是一个正常服装公司的配置”。不一样的是，PUK团队的平均年龄在23~25之间，且都是喜欢嘻哈文化的人，“大多数都是这条路上遇到的伙伴，比如有些有设计才能、有些特别了解潮流，把这些有创意的人聚起来，我们还是一个年轻敢冲的团队。”

![](https://mmbiz.qpic.cn/mmbiz_png/jNZszpkibXx8r0eeusveAtyj98pKeBEz7ejDSZf97dAE3mMYqSpwDp0blV0YsOONibSOjLz8EycRV8uxj7xc8QIg/640?wx_fmt=png)

**强曝光、快转型、可复制：****PUK能否成为潮流文化商业化的模型？**

与大多数明星潮牌一样，**PUK的出圈离不开明星效应带来的正反馈——强曝光**。

**一方面是通过明星同款、超级主播合作，让产品快速吸引第一波消费者。**其中明星同款是低成本、且最容易出效果的方式，在PUK的淘宝旗舰店中，标有“布瑞吉Bridge同款”、“王鹤棣同款”、“蔡文静同款”、“赵小棠同款”等标签的产品，销量都在前位。而超级主播也让产品进一步拓圈，触达更多消费者。PUK此前与李佳琦、车澈等主播都有合作。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK01Jalpnx7A2NWL6iccBuqe4SH67mCmEkrS6Sm7A5TwWrA74gNx2JkicKibqFNeBBiaTibTiabic0yCTKEyw/640?wx_fmt=png)

**另一方面，是在综艺、音乐节等场景反复曝光，持续加深消费者对品牌的印象。**比如之前在《中国说唱巅峰对决》的节目中，就通过品牌元素、周边公仔道具打造了一个PUK专属舞台。

今年，音乐节成为品牌营销的重要场景，种梦音乐本身就有自己的音乐节IP。8月19日在青岛举办的大蘑菇音乐节中，PUK也在现场搭建了品牌快闪店。音乐节不仅可以精准曝光，也能带动一定的销量。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/HKEDX7MqXK01Jalpnx7A2NWL6iccBuqe4mb4gjicr15o1qm5M1SLSmg4D2DwJvaAMaTChy4ianNV8HzzV19HHic9fQ/640?wx_fmt=png)

**此外，时装周也是服装品牌重要的出圈渠道。**不久前，PUK亮相了深圳时装周，呈现了2023秋冬系列时装秀。在时装周上，品牌不仅可以与更多同行同台竞技，也是彰显品牌理念的最佳场景，在深圳时装周上，PUK呈现了一组设计更大胆、色彩更丰富产品。目前，这些产品也已经进入线上电商渠道。

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/HKEDX7MqXK01Jalpnx7A2NWL6iccBuqe4qAfvejlJBK0PKmbCdL8Dc4uvcE9hgB2LEcQkvNgneMmAUpwXvvGic8Q/640?wx_fmt=jpeg)

强曝光是品牌出圈的第一步，**如何快速调整战术，以应对多变的市场，是品牌能否长期发展的关键要素**。成立到现在不到2年的时间，PUK其实已经经历了三个阶段的变化。

**第一阶段，也就是创立之处PUK主要做线上电商**，入驻了淘宝、得物等平台。随着抖音直播电商的兴起，PUK开启了**第二阶段——尝试做抖音直播**。但很快，韩啸就意识到了只做电商生意的弊端，“大家都卷价格，利润做不上去，而且无法提升品牌力。”

“前期品牌确实需要打好基础，跑出声量，但跑出来之后需要解决的问题是，怎么真正去增加收入、提升利润、品牌升级”，韩啸表示，在多因素促使下，**PUK开始了第三阶段的转型——布局线下、做实体店**。

今年上半年，PUK的首家实体店落地重庆。9月份，重庆线下店也与盛宇的品牌BIPOLAR合作，升级为联合旗舰店。“接下来，会陆续在北京、上海、深圳这些重点城市布局。”

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/HKEDX7MqXK01Jalpnx7A2NWL6iccBuqe4ZvNAjU9rIqkL7pYrjxl8p6meR5ddDLgicGSIvMy5Y6uzHWWa1LHNTJg/640?wx_fmt=jpeg)

值得注意的是，**PUK选择在今年布局线下店，也是抓住了新的趋势和机遇**。今年文旅市场非常火热，很多地方政府都在想办法拉动当地的文旅产业。因此，不少地方政府和商业地产也在加大力度去支持一些年轻人喜欢的潮流、国潮品牌。

PUK在重庆开线下店，也是借到了这一趋势的东风。据韩啸介绍，PUK实体店在落地时，凭借品牌自身的曝光量和认知度，在租金和流量方面拿到了很多额外的资源，大大降低了运营成本。“我们接下来布局线下店，也会是和商业地产合作的方式。”

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/HKEDX7MqXK01Jalpnx7A2NWL6iccBuqe4aFrJM1AaEM7rpl3Te8e8sZcfJGbiaaB8jiaOWOMgvTMriaoR2NDM9iaSMw/640?wx_fmt=jpeg)

**复盘PUK的发展路径，还有个非常关键的特质——可复制。**

更大维度来看，说唱歌手做潮牌，落点在于潮流文化的商业化。正如韩啸所说，创立PUK只是大战略布局下的一个动作。但背后所透露出的，是其对潮流文化的生意路径思考。韩啸表示，种梦音乐下一阶段的定位，也不再是嘻哈音乐公司，而是青年潮流文化公司。

“不仅潮牌，我们也在陆续尝试餐饮和咖啡等，未来还会去尝试推出各种各样的东西，比如潮流家居等。但这些都只是表现形式，我们做这些事情的初衷，一定是把嘻哈音乐以及嘻哈文化，去输出到各种消费品里面，从更广义的维度上去变现”，韩啸表示。

![](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd71F2dibV90gDJazSOF6hDZd8QibjdIsIib2ymf3QDQMTtWG0pricjL7lnJD10zibicaruibhJrRKtHHuywQ/640?wx_fmt=jpeg)AI制图，by娱乐资本论

而在具体路径上，都会采用**PUK模式，即种梦音乐与艺人合作推出不同类目的品牌，艺人以主理人的身份去运营品牌**。“我们接下来就会陆续官宣一些项目”，但被问到具体是什么项目时，韩啸留了一些悬念给我们，“目前在秘密筹备中，现在还没办法说太多。”

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/HKEDX7MqXK01Jalpnx7A2NWL6iccBuqe4zXdLEYxLvuYiajXBQgjRXBlH0JzfUtVaxmDrynXdnx0a7V0iaMwNSiaTA/640?wx_fmt=jpeg)

**虽然模式可复制，但结果可不可复制，还需要持续观望。**毕竟做潮流文化的生意，意味着更加多变的消费群体，以及更加不确定的市场。

但韩啸相对于乐观，“现阶段，我们在低成本运营的状态下把团队磨合出来了。在这么内卷的环境下，PUK能活下来且良性运转，首先我们的团队经历了一个很重要的初创阶段。”。

“PUK占据我的精力大概在30%到40%，但一切才刚刚开始。”布瑞吉Bridge感叹：“现在回头想想，其实做品牌和玩说唱是一样的，比如刚踏入说唱领域时，我就必须花三年的时间去搞清楚说唱是怎么回事。PUK成立到现在才一年半的时间，包括供应链在内，很多地方还在不断精进。”

但从PUK的成长路径来看，我们还是可以从中窥见一个明星潮牌如何一步步出圈，并成长为独立品牌的过程。也确实可以看到，潮流文化这门生意还有非常大的空间与市场。

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/HKEDX7MqXK01Jalpnx7A2NWL6iccBuqe4BBUkz1KlnQFfk8c8gUn5pnPIvDwwG0YFAoWF7icH4GHcFviawXku8Opg/640?wx_fmt=jpeg)

**话题互动：**

****你最喜欢的潮牌是？****

**推荐阅读**

[**![](https://mmbiz.qpic.cn/sz_mmbiz_png/UgtzVuzhFd6BrKwAcFWz5x8DW5gTskbPnf9K0KjtgKHS341ShQRsYLACqhzIhvrkcqka73VkN9xhFSbh5nujPg/640?wx_fmt=png&wxfrom=5&wx_lazy=1&wx_co=1)**](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247608880&idx=1&sn=1d02caeba88d8ff422eb29d1653eb598&chksm=c0583febf72fb6fd649cd4c5f3b9412af6f68364871881aa4bffbf6bab9102be8a1447612d2a&scene=21#wechat_redirect)

[**![](https://mmbiz.qpic.cn/mmbiz_png/UgtzVuzhFd6BrKwAcFWz5x8DW5gTskbPia9rQoo5w2VtscYYUacibyZzVbJIwuksC3No2A2NNAfjjTibsibibggF5SQ/640?wx_fmt=png&wxfrom=5&wx_lazy=1&wx_co=1)**](http://mp.weixin.qq.com/s?__biz=Mzg5ODkwOTM2NA==&mid=2247608721&idx=1&sn=359aac53224e793758dfcb84251eba6f&chksm=c0583c4af72fb55ca04134b3c1a19bc278d515969371f06428c54dfe044bf7103d220eb322cb&scene=21#wechat_redirect)

******打骨折卖10亿******

******辛巴牵手慕思动了谁的蛋糕？******

****点击观看****

**↓↓↓**

**如需商务合作后台回复【商务】**

**如有转载需求后台回复【转载】**

**更多文娱产业背后的经济逻辑，来关注↓↓↓**

**![](https://mmbiz.qpic.cn/mmbiz_jpg/UgtzVuzhFd6RbduWQ1AIryUvalfYznTBHJZwVW6G1gosXoTsfeSLolMHPIiasAATwylyPf9tSLBqM6lliaVkwukQ/640?wx_fmt=jpeg&wxfrom=5&wx_lazy=1&wx_co=1)**